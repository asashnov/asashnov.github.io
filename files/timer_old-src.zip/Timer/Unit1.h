//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CSPIN.h"
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TMain : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TButton *StartButton;
        TButton *StopButton;
        TCSpinEdit *MinuteEdit;
        TCSpinEdit *HourEdit;
        TLabel *Label1;
        TLabel *Label2;
        TProgressBar *ProgressBar1;
        TTimer *Timer2;
        TTimer *Timer3;
        TTimer *Timer4;
    TLabel *Label3;
    TLabel *Label4;
        void __fastcall MinuteEditChange(TObject *Sender);
        void __fastcall StartButtonClick(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall StopButtonClick(TObject *Sender);
        void __fastcall Timer3Timer(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Timer4Timer(TObject *Sender);
private:	// User declarations
        int TimeSec;
        BOOL bSec;
        void PaintTime();
public:		// User declarations
        __fastcall TMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMain *Main;
//---------------------------------------------------------------------------
#endif
