//---------------------------------------------------------------------------
#ifndef EditObjectH
#define EditObjectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include "cspin.h"
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TEditObjectForm : public TForm
{
__published:	// IDE-managed Components
    TStaticText *StaticText1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    TBitBtn *BitBtn3;
    TLabel *Label4;
    TEdit *BmpEdit;
    TCSpinEdit *TypeEdit;
    TCSpinEdit *WidthEdit;
    TCSpinEdit *HeightEdit;
    TCheckBox *CheckBox;
    TCSpinEdit *ParamEdit;
    TLabel *Label5;
    TComboBox *NameEdit;
    void __fastcall BitBtn1Click(TObject *Sender);
    
    void __fastcall BmpEditChange(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall NameEditChange(TObject *Sender);
    
private:	// User declarations
    int Cur_index;  // ����� �������� ������� � EditName
public:		// User declarations
    __fastcall TEditObjectForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEditObjectForm *EditObjectForm;
//---------------------------------------------------------------------------
#endif
