//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Prop.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cspin"
#pragma link "CSPIN"
#pragma resource "*.dfm"
TObjectProp *ObjectProp;
union
{
int param1;
struct {
WORD param21,param22;
};
struct
{
unsigned char param41,param42,param43,param44;
};
}WParam;

//---------------------------------------------------------------------------
__fastcall TObjectProp::TObjectProp(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TObjectProp::FormShow(TObject *Sender)
{
LEVFILEOBJECT* lo=(LEVFILEOBJECT*)LevObjList->Items[objnom];
    WParam.param1=lo->param;

    TypeEdit->Value=lo->type;
    PosxEdit->Value=lo->posx;
    PosyEdit->Value=lo->posy;
    //���������� ���������� ParamEdit'��
    Edit1->Value=WParam.param1;

    Edit21->Value=WParam.param21;
    Edit22->Value=WParam.param22;

    Edit41->Value=WParam.param41;
    Edit42->Value=WParam.param42;
    Edit43->Value=WParam.param43;
    Edit44->Value=WParam.param44;

}
//---------------------------------------------------------------------------
void __fastcall TObjectProp::BitBtn1Click(TObject *Sender)
{
LEVFILEOBJECT* lo=(LEVFILEOBJECT*)LevObjList->Items[objnom];

    lo->type=TypeEdit->Value;
    lo->posx=PosxEdit->Value;
    lo->posy=PosyEdit->Value;

    //���������� ���������� �� ParamEdit'��
    if(RadioButton1->Checked)
    {
    WParam.param1=Edit1->Value;
    }
    if(RadioButton2->Checked)
    {
    WParam.param21=Edit21->Value;
    WParam.param22=Edit22->Value;
    }
    if(RadioButton4->Checked)
    {
    WParam.param41=Edit41->Value;
    WParam.param42=Edit42->Value;
    WParam.param43=Edit43->Value;
    WParam.param44=Edit44->Value;
    }

    lo->param=WParam.param1;
}
//---------------------------------------------------------------------------
