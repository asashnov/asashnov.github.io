//---------------------------------------------------------------------------
#ifndef OptionsFormH
#define OptionsFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cspin.h"
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include <Buttons.hpp>
#include "defines.h"
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TOptions : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *ItemGroupBox;
    TStaticText *StaticText1;
    TStaticText *StaticText2;
    TCSpinEdit *ItemHgtEdit;
    TCSpinEdit *ItemLenEdit;
    TStaticText *StaticText3;
    TStaticText *StaticText4;
    TCSpinEdit *HorisItemsEdit;
    TEdit *BitmapEdit;
    TButton *ItemBrowseButton;
    TGroupBox *ObjectGroupBox;
    TLabel *Label1;
    TEdit *ObjectEdit;
    TButton *ObjBrowseButton;
    TOpenDialog *OpenDialog2;
    TGroupBox *LevelGroupBox;
    TCheckBox *HeightCheckBox;
    TCheckBox *WidhtCheckBox;
    TCSpinEdit *HeightLimitEdit;
    TCSpinEdit *WidhtLimitEdit;
    TOpenPictureDialog *OpenPictureDialog1;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    TBitBtn *BitBtn3;
    TSaveDialog *SaveObjectAsDialog;
    void __fastcall ItemBrowseButtonClick(TObject *Sender);
    void __fastcall ObjBrowseButtonClick(TObject *Sender);
    
    void __fastcall HeightCheckBoxClick(TObject *Sender);
    void __fastcall WidhtCheckBoxClick(TObject *Sender);
    void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TOptions(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOptions *Options;
//---------------------------------------------------------------------------
#endif
