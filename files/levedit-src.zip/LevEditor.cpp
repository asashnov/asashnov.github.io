//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("LevEditor.res");
USEFORM("Main.cpp", MainForm);
USEFORM("AboutForm.cpp", About);
USEFORM("TestForm.cpp", TestLevelForm);
USEFORM("OptionsForm.cpp", Options);
USEFORM("Edit.cpp", EditObjectForm);
USEFORM("Prop.cpp", ObjectProp);
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->HelpFile = "LEVEDIT.hlp";
         Application->Title = "Level Editor";
         Application->CreateForm(__classid(TMainForm), &MainForm);
        Application->CreateForm(__classid(TAbout), &About);
        Application->CreateForm(__classid(TTestLevelForm), &TestLevelForm);
        Application->CreateForm(__classid(TOptions), &Options);
        Application->CreateForm(__classid(TEditObjectForm), &EditObjectForm);
        Application->CreateForm(__classid(TObjectProp), &ObjectProp);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
