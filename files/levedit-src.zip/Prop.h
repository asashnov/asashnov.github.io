//---------------------------------------------------------------------------
#ifndef PropH
#define PropH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cspin.h"
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "defines.h"
#include "CSPIN.h"
//---------------------------------------------------------------------------

class TObjectProp : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TRadioGroup *RadioGroup1;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TCSpinEdit *TypeEdit;
    TCSpinEdit *PosxEdit;
    TCSpinEdit *PosyEdit;
    TCSpinEdit *Edit1;
    TCSpinEdit *Edit21;
    TCSpinEdit *Edit22;
    TRadioButton *RadioButton4;
    TCSpinEdit *Edit41;
    TCSpinEdit *Edit42;
    TCSpinEdit *Edit43;
    TCSpinEdit *Edit44;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    TBitBtn *BitBtn3;
    TStaticText *StaticText1;
    TStaticText *StaticText2;
    TStaticText *StaticText3;
    TStaticText *StaticText4;
    TStaticText *StaticText5;
    TStaticText *StaticText6;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall BitBtn1Click(TObject *Sender);
    
private:	// User declarations
public:		// User declarations
    __fastcall TObjectProp(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TObjectProp *ObjectProp;
//---------------------------------------------------------------------------
#endif
