//---------------------------------------------------------------------------
#ifndef TestFormH
#define TestFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTestLevelForm : public TForm
{
__published:	// IDE-managed Components
    TStaticText *StaticText1;
    TButton *Button1;
    TOpenDialog *OpenTestDialog;
    TBitBtn *okbutton;
    TBitBtn *BitBtn2;
    TEdit *ParamsEdit;
    TLabel *Label1;
    TComboBox *ExeEdit;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall okbuttonClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormDestroy(TObject *Sender);
    
    
private:	// User declarations
public:		// User declarations
    __fastcall TTestLevelForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestLevelForm *TestLevelForm;
//---------------------------------------------------------------------------
#endif
