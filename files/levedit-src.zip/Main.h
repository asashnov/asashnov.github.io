//---------------------------------------------------------------------------
#include <Buttons.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
#include <ToolWin.hpp>
#include <ExtDlgs.hpp>
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>

#include <stdio.h>
#include <Buttons.hpp>
#include "defines.h"
//---------------------------------------------------------------------------

#define PS_NONE         0
#define PS_PUTITEM      1
#define PS_PUTOBJECT    2
#define PS_DELETEOBJECT 3


#define MAXTILES_X 1024
#define MAXTILES_Y 1024

class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TMainMenu *MainMenu;
    TBevel *Bevel1;
    TPanel *Panel;
    TMenuItem *File;
    TMenuItem *Exit1;
    TMenuItem *N1;
    TMenuItem *N2;
    TMenuItem *FileSaveAs;
    TMenuItem *FileSave;
    TMenuItem *FileOpen;
    TMenuItem *FileNew;
    TMenuItem *FileSaveObjectsAs;
    TMenuItem *View;
    TMenuItem *ViewLevelObject;
    TMenuItem *EditOptions;
    TStatusBar *StatusBar;
    TScrollBar *BottomScrollBar;
    TScrollBar *RightScrollBar;
    TPaintBox *PaintBox;
    TComboBox *ObjectBox;
    TScrollBar *ItemScrollBar;
    TPaintBox *ItemBox;
    TOpenDialog *OpenDialog;
    TSaveDialog *SaveDialog;
    TMenuItem *FileTestLevel;
    TMenuItem *ViewGrid;
    TSpeedButton *DeleteObjectButton;
    TMenuItem *Edit;
    TMenuItem *VerticalAlignObjects1;
    TMenuItem *HorisontalAlignObject1;
    TMenuItem *VNone;
    TMenuItem *VTop;
    TMenuItem *VBottom;
    TMenuItem *HNone;
    TMenuItem *HLeft;
    TMenuItem *HRight;
    TSpeedButton *AddObjectSpeedButton;
    TSaveDialog *SaveObjectAsDialog;
    TCoolBar *CoolBar1;
    TSpeedButton *SpeedButton1;
    TSpeedButton *SpeedButton2;
    TSpeedButton *SpeedButton3;
    TSpeedButton *SpeedButton4;
    TCoolBar *CoolBar2;
    TSpeedButton *SpeedButton5;
    TSpeedButton *SpeedButton6;
    TSpeedButton *SpeedButton7;
    TSpeedButton *SpeedButton8;
    TSpeedButton *SpeedButton9;
    TSpeedButton *SpeedButton10;
    TSpeedButton *SpeedButton11;
    TSpeedButton *SpeedButton12;
    TMenuItem *EditAddObject;
    TMenuItem *EditDeleteObject;
    TMenuItem *Help1;
    TMenuItem *About1;
    TMenuItem *SearchforHelpOn1;
    TMenuItem *Contents1;
    TMenuItem *Index1;
    void __fastcall HelpAboutClick(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);

    void __fastcall FileTestLevelClick(TObject *Sender);
    void __fastcall FileNewClick(TObject *Sender);
    void __fastcall ItemBoxPaint(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall ItemBoxMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall ItemBoxClick(TObject *Sender);
    void __fastcall PaintBoxMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall PaintBoxClick(TObject *Sender);
    void __fastcall PaintBoxPaint(TObject *Sender);

    void __fastcall FileSaveClick(TObject *Sender);
    void __fastcall EditOptionsClick(TObject *Sender);
    void __fastcall FileSaveAsClick(TObject *Sender);
    void __fastcall FormPaint(TObject *Sender);
    void __fastcall ViewLevelObjectClick(TObject *Sender);
    void __fastcall ViewGridClick(TObject *Sender);

    void __fastcall FileOpenClick(TObject *Sender);
    void __fastcall DeleteObjectButtonClick(TObject *Sender);
    void __fastcall DeleteObjectButtonDblClick(TObject *Sender);
    void __fastcall FormDestroy(TObject *Sender);
    void __fastcall VNoneClick(TObject *Sender);
    void __fastcall VTopClick(TObject *Sender);
    void __fastcall VBottomClick(TObject *Sender);
    void __fastcall HNoneClick(TObject *Sender);
    void __fastcall HLeftClick(TObject *Sender);
    void __fastcall HRightClick(TObject *Sender);
    void __fastcall ObjectBoxChange(TObject *Sender);
    void __fastcall AddObjectSpeedButtonClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    
    void __fastcall SpeedButton1Click(TObject *Sender);
    void __fastcall SpeedButton2Click(TObject *Sender);
    void __fastcall SpeedButton3Click(TObject *Sender);
    void __fastcall SpeedButton4Click(TObject *Sender);
    void __fastcall FileSaveObjectsAsClick(TObject *Sender);
    void __fastcall PaintBoxMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
    
    void __fastcall PaintBoxMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
    
    void __fastcall PaintBoxDblClick(TObject *Sender);
    void __fastcall FormResize(TObject *Sender);
    void __fastcall Contents1Click(TObject *Sender);
    void __fastcall SearchforHelpOn1Click(TObject *Sender);
    void __fastcall Index1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations

// ��� ��������� ������
    int Levposx, Levposy;
    BOOL bLevelModified;
    int CurItem, ItemPaintFirst,MouseItem;
    int curObjtype, curObjlen, curObjhgt,curObjparam;   //��������� ������
    int MouseItemX,MouseItemY;
    int MouseX, MouseY;     //����� ���� � PaintBox
    char* Levdat;
    Graphics::TBitmap *ItemBmp;
    Graphics::TBitmap *GridBitmap;  //��� ������� ������������ �����
    LEVELFILEHEADER LH;
    TFileStream* LevFile;
    String ItemFile;
    BOOL bMouseDown;

    __fastcall TMainForm(TComponent* Owner);
    void __fastcall OnHint(TObject* Sender);
    void AlignObject();

    BOOL CheckLen(int);
    BOOL CheckHgt(int);
    int GetTile(int x,int y);
    void SaveLevel();
    void CreateGridBitmap();    //��������� ����� �� GridBitmap

};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
