//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Midi.cpp: implementation of the NDX_Midi class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Midi::NDX_Midi()
{
	IsReady=false;
	IsFromWAD=false;
}

NDX_Midi::~NDX_Midi()
{
	Stop();
	IsReady=false;
	if(IsFromWAD)
	{
		IsFromWAD=false;
		unlink(TFileName);
	}
	free(TFileName);
}

void NDX_Midi::Create(HWND hwnd)
{
	Hwnd=hwnd;
}

NDXERR NDX_Midi::Load(LPSTR Name, NF_FileBuffer FileBuffer)
{
	char Path[MAX_PATH*2];
	FILE * Dest;
	GetTempPath(MAX_PATH*2,Path);
	strcat(Path,"\\");
	strcat(Path,Name);
	TFileName=(LPSTR)malloc(((strlen(Path)+1))*sizeof(char));
	strcpy(TFileName,Path);
	Dest=fopen(TFileName,"wb");
	if(Dest==NULL)return NDXERR_CREATEFILE;
	fwrite(FileBuffer.FileBuffer,FileBuffer.Size,1,Dest);
	IsFromWAD=true;
	fclose(Dest);
	IsReady=true;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Load(LPSTR Name, FILE * fh, long size)
{
	char Path[MAX_PATH*2];
	FILE * Dest;
	char temp;
	GetTempPath(MAX_PATH*2,Path);
	strcat(Path,"\\");
	strcat(Path,Name);
	TFileName=(LPSTR)malloc(((strlen(Path)+1))*sizeof(char));
	strcpy(TFileName,Path);
	Dest=fopen(TFileName,"wb");
	if(Dest==NULL)return NDXERR_CREATEFILE;
	for (int c=0;c<size;c++)
	{
		fread(&temp,sizeof(char),1,fh);
		fwrite(&temp,sizeof(char),1,Dest);
	}
	IsFromWAD=true;
	fclose(Dest);
	IsReady=true;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Load(LPSTR FileName)
{
	FILE * fh;
	TFileName=(LPSTR)malloc((strlen(FileName))*sizeof(char));
	strcpy(TFileName,FileName);
	fh=fopen(TFileName,"rb");
	if(fh==NULL)
	{
		IsReady=false;
		return NDXERR_BADFILE;
	}
	IsReady=true;
	fclose(fh);
	return NDXERR_OK;
}

NDXERR NDX_Midi::Play()
{
	char buffer[256];
	sprintf(buffer, "open %s type sequencer alias MUSIC", TFileName);
	if(mciSendString("close all",NULL,0,NULL)!=0)return NDXERR_MIDICLOSEFAILED;
	if(mciSendString(buffer,NULL,0,NULL)!=0)return NDXERR_MIDIOPENFAILED;
	if(mciSendString("play MUSIC from 0 notify",NULL,0,Hwnd)!=0)return NDXERR_MIDIPLAYFAILED;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Stop()
{
	if(mciSendString("close all",NULL,0,NULL)!=0)return NDXERR_MIDICLOSEFAILED;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Pause()
{
	if(mciSendString("stop MUSIC",NULL,0,NULL)!=0)return NDXERR_MIDISTOPFAILED;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Resume()
{
	if(mciSendString("play MUSIC notify",NULL,0,Hwnd)!=0)return NDXERR_MIDIRESUMEFAILED;
	return NDXERR_OK;
}

NDXERR NDX_Midi::Restart()
{
	if(mciSendString("play MUSIC from 0 notify",NULL,0,Hwnd)!=0)return NDXERR_MIDIRESTARTFAILED;
	return NDXERR_OK;
}

//
///EOF
