//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

NDX_ERRORCB ErrorCallBack=NULL;

NDXERR CHECKERROR(NDXERR Error)
{
	if(Error==NDXERR_OK)return NDXERR_OK;
	if(ErrorCallBack!=NULL)ErrorCallBack(Error);
	return Error;
}

LPSTR NDX_ErrorToStr(NDXERR Error)
{
	switch(Error)
	{
		case NDXERR_OK:
			return "OK - No error";
		case NDXERR_CREATEDDRAW:
			return "Error creating directdraw";
		case NDXERR_SETDISPMODE:
			return "Error setting displaymode";
		case NDXERR_SETCOORPLEVEL:
			return "Error setting cooperative level";
		case NDXERR_PRIMSURFACE:
			return "Error creating primary surface";
		case NDXERR_BACKSURFACE:
			return "Error creating back surface";
		case NDXERR_CREATESURFACE:
			return "Error creating surface";
		case NDXERR_LOCK:
			return "Error locking surface";
		case NDXERR_UNLOCK:
			return "Error unlocking surface";
		case NDXERR_LOCKDC:
			return "Error locking surface DC";
		case NDXERR_UNLOCKDC:
			return "Error unlocking surface DC";
		case NDXERR_BADDISPMODE:
			return "Bad display mode";
		case NDXERR_BADFILE:
			return "File not found / Bad file";
		case NDXERR_OUTOFMEM:
			return "Could not allocate memory";
		case NDXERR_LOADWAV:
			return "Error loading WAV file";
		case NDXERR_BADWAV:
			return "Not a valid WAV file";
		case NDXERR_DSOUNDCREATE:
			return "Error creating DirectSound";
		case NDXERR_DSOUNDSETCOOP:
			return "Error setting coorp. level for DirectSound";
		case NDXERR_SAMPLEUNP:
			return "Error unpacking wave-format";
		case NDXERR_CREATESB:
			return "Error creating DirectSoundBuffer";
		case NDXERR_NOAVAILBUF:
			return "No available soundbuffer";
		case NDXERR_SETVOLUME:
			return "Can't set volume";
		case NDXERR_CANTPLAY:
			return "Can't play sound";
		case NDXERR_WRITEWAVDATA:
			return "Can't write Wave data to DirectSoundBuffer";
		case NDXERR_BADBMP:
			return "Not a valid BMP file";
		case NDXERR_BLTFAIL:
			return "Could not compleate blit";
		case NDXERR_FLIPERR:
			return "Error flipping surface";
		case NDXERR_EVENT:
			return "Can't set timer event";
		case NDXERR_BADNUKFILE:
			return "Bad nuke file";
		case NDXERR_SURFACENC:
			return "Surface not created";
		case NDXERR_ALPHANC:
			return "AlphaChannel not created";
		case NDXERR_CCLIP:
			return "Error creating clipper";
		case NDXERR_NOTPSD:
			return "Not a valid PSD file";
		case NDXERR_NOTRGBPSD:
			return "Not a RGB PSD image";
		case NDXERR_CPAL:
			return "Error creating palette";
		case NDXERR_SETPAL:
			return "Could not set palette";
		case NDXERR_DICREATEFAILED:
			return "Error creating DirectInput";
		case NDXERR_DIMOUSEAQFAILED:
			return "Could not aquire Mouse";
		case NDXERR_DIKEYSAQUFAILED:
			return "Could not aquire Keyboard";
		case NDXERR_DIENUMF:
			return "DirectInput Enumeration error";
		case NDXERR_DIQUERYFAILED:
			return "DirectInput Query-Joystick-Interface failed";
		case NDXERR_DISETJOYRANGE:
			return "Joystick setrange error";
		case NDXERR_DIJOYAQFAILED:
			return "Could not aquire JoyStick";
		case NDXERR_MIDICLOSEFAILED:
			return "Could not close midi";
		case NDXERR_MIDIOPENFAILED:
			return "Could not open midi";
		case NDXERR_MIDIPLAYFAILED:
			return "Error playing midi";
		case NDXERR_MIDISTOPFAILED:
			return "Could not stop midi";
		case NDXERR_MIDIRESUMEFAILED:
			return "Could not resume midi";
		case NDXERR_MIDIRESTARTFAILED:
			return "Could not restart midi";
		case NDXERR_CREATEFILE:
			return "Error creating file";
		case NDXERR_NOBACK:
			return "Can't flip because there's no back-surface";
		case NDXERR_DDSOUNDNC:
			return "DirectSound Object not Created";
		case NDXERR_NCPAL:
			return "Palette not created";
	}
	return "Unknown error";
}


//
///EOF
