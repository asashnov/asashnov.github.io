//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_SurfaceList.cpp: implementation of the NDX_SurfaceList class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_SurfaceList::NDX_SurfaceList()
{
	NumElements=0;
	First=NULL;
	Last=NULL;
}

NDX_SurfaceList::~NDX_SurfaceList()
{
	RemoveAll();
}

void NDX_SurfaceList::AddSurface(NDX_Surface * Surface)
{
	if(NumElements==0)
	{
		Last=new Element;
		Last->Surface=Surface;
		Last->Last=NULL;
		Last->Next=NULL;
		First=Last;
	}else
	{
		Element *NewOne=new Element;
		NewOne->Surface=Surface;
		NewOne->Last=Last;
		NewOne->Next=NULL;
		Last->Next=NewOne;
		Last=NewOne;
	}
	NumElements++;
}

void NDX_SurfaceList::RemoveSurface(NDX_Surface * Surface)
{
	Element *ThisOne=First;
	do
	{
		if(ThisOne!=NULL)
		{
			if(ThisOne->Surface==Surface)
			{
				Element *Temp=ThisOne;
				if(ThisOne==Last)Last=ThisOne->Last;
				if(ThisOne==First)First=ThisOne->Next;
				if(ThisOne->Last!=NULL)ThisOne->Last->Next=Temp->Next;
				if(ThisOne->Next!=NULL)ThisOne->Next->Last=Temp->Last;
				ThisOne=Temp->Next;
				delete Temp;
				NumElements--;
			}else ThisOne=ThisOne->Next;
		}
	}while(ThisOne!=NULL);
}

void NDX_SurfaceList::RestoreAll()
{
	Element *ThisOne=First;
	if(First!=NULL)
	{
		do
		{
			if(ThisOne!=NULL)
			{
				ThisOne->Surface->Restore();
				ThisOne=ThisOne->Next;
			}
		}while(ThisOne!=NULL);
	}
}

void NDX_SurfaceList::ReleaseAll()
{
	Element *ThisOne=First;
	if(First!=NULL)
	{
		do
		{
			if(ThisOne!=NULL)
			{
				ThisOne->Surface->Screen=NULL;
				ThisOne->Surface->Release();
				ThisOne=ThisOne->Next;
			}
		}while(ThisOne!=NULL);
	}
	RemoveAll();
}

NDX_Surface * NDX_SurfaceList::GetFirst()
{
	Next=First->Next;
	return First->Surface;
}

NDX_Surface * NDX_SurfaceList::GetNext()
{
	if(Next!=NULL)
	{
		NDX_Surface *ThisSurface=Next->Surface;
		Next=Next->Next;
		return ThisSurface;
	}else
	{
		return NULL;
	}
}

void NDX_SurfaceList::RemoveAll()
{
	Element *ThisOne=First;
	do
	{
		if(ThisOne!=NULL)
		{
			Element *Temp=ThisOne;
			ThisOne=ThisOne->Next;
			delete Temp;
		}
	}while(ThisOne!=NULL);
	First=NULL;
	Last=NULL;
}

//
///EOF