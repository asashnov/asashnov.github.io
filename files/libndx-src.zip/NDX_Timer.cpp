//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Timer.cpp: implementation of the NDX_Timer class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Timer::NDX_Timer()
{
	QueryPerformanceFrequency((LARGE_INTEGER*)&Freq);
}

NDX_Timer::~NDX_Timer()
{

}

double NDX_Timer::GetDelta(double TimeUnit) // TimeUnit = ticks pr. sek
{
	double Now=GetTime();
	double dt=double((Now-LastTime)*TimeUnit);
	LastTime=Now;
	return dt;
}

void NDX_Timer::StartNow()
{
	LastTime=GetTime();
}

double NDX_Timer::GetDelta(double TimeUnit, double MinDelta)
{
	double dt;
	double Now;
	do
	{
		Now=GetTime();
		dt=double((Now-LastTime)*TimeUnit);
	}while(dt<MinDelta);
	LastTime=Now;
	return dt;
}
//
///EOF
