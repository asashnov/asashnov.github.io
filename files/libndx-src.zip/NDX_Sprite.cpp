//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Sprite.cpp: implementation of the NDX_Sprite class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Sprite::NDX_Sprite()
{
}

NDX_Sprite::~NDX_Sprite()
{
}

void NDX_Sprite::Draw()
{
}

void NDX_Sprite::Move(double delta)
{
}

void NDX_Sprite::Message(void * lpData)
{
}

void NDX_Sprite::CreateDirtyRect()
{
}

//
///EOF
