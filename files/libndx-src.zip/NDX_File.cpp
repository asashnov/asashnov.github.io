// NDX_File.cpp: implementation of the NDX_File class.
//
//////////////////////////////////////////////////////////////////////

#include <NukeDX.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_File::NDX_File()
{
	Dir=NULL;
	FileOpen=false;
}

NDX_File::~NDX_File()
{
	Close();
}

NDXERR NDX_File::Open(LPSTR FileName)
{
	Close();
	__int64 TempDirPos;
 	char HdrBuff[8];
 	fh=fopen(FileName,"rb");
	StartPos=0;
	if(fh==NULL)return NDXERR_BADFILE;
 	fread(HdrBuff,sizeof(char),8,fh);
	if(strcmpi(HdrBuff,"NUKHEAD")!=0)
	{
		fclose(fh);
		return NDXERR_BADNUKFILE;
	}
	fseek(fh,-8,SEEK_END); 
	fread(&TempDirPos,8,1,fh);
	fseek(fh,(int)TempDirPos,SEEK_SET);
	fread(HdrBuff,sizeof(char),7,fh);
	if(strcmpi(HdrBuff,"NUKDIR")!=0)
	{
		fclose(fh);
		return NDXERR_BADNUKFILE;
	}
	fread(&NumFiles,sizeof(int),1,fh);
	DirOffset=ftell(fh);
	Dir=(DirEntry*)malloc(NumFiles*sizeof(DirEntry));
	if(Dir==NULL)
	{
		fclose(fh);
		return NDXERR_OUTOFMEM;
	}
	fseek(fh,(int)DirOffset,SEEK_SET); 
	for(int i=0;i<NumFiles;i++)
	{
		fread(&Dir[i],sizeof(DirEntry),1,fh); 
	}
	FileOpen=true;
	OwnFile=true;
	return NDXERR_OK;
}

NDXERR NDX_File::Open(FILE * FileHandle,int FileSize)
{
	Close();
	__int64 TempDirPos;
 	char HdrBuff[8];
 	fh=FileHandle;
	if(fh==NULL)return NDXERR_BADFILE;
	StartPos=ftell(fh);
 	fread(&HdrBuff,sizeof(char),8,fh);
	if(strcmpi(HdrBuff,"NUKHEAD")!=0)
	{
		return NDXERR_BADNUKFILE;
	}
	fseek(fh,StartPos+FileSize-8,SEEK_SET); 
	fread(&TempDirPos,8,1,fh);
	fseek(fh,StartPos+(int)TempDirPos,SEEK_SET);
	fread(&HdrBuff,sizeof(char),7,fh);
	if(strcmpi(HdrBuff,"NUKDIR")!=0)
	{
		return NDXERR_BADNUKFILE;
	}
	fread(&NumFiles,sizeof(int),1,fh);
	DirOffset=ftell(fh);
	Dir=(DirEntry*)malloc(NumFiles*sizeof(DirEntry));
	if(Dir==NULL)
	{
		return NDXERR_OUTOFMEM;
	}
	fseek(fh,(int)DirOffset,SEEK_SET); 
	for(int i=0;i<NumFiles;i++)
	{
		fread(&Dir[i],sizeof(DirEntry),1,fh); 
	}
	FileOpen=true;
	OwnFile=false;
	return NDXERR_OK;
}

NDXERR NDX_File::Close()
{
	FREE(Dir);
	if(FileOpen&&OwnFile)fclose(fh);
	FileOpen=false;
	return NDXERR_OK;
}

FILE * NDX_File::Seek(LPSTR IndexName)
{
	if(!FileOpen)return NULL;
	for(int n=0;n<NumFiles;n++)
	{
		if(strcmpi(Dir[n].Name,IndexName)==0)
		{
			fseek(fh,(int)Dir[n].Offset+StartPos,SEEK_SET);
			return fh;
		}
	}
	return NULL;
}

FILE * NDX_File::Seek(int Number)
{
	if(!FileOpen)return NULL;
	if(Number>=0&&Number<NumFiles)
	{
		fseek(fh,(int)Dir[Number].Offset+StartPos,SEEK_SET);
		return fh;
	}
	return NULL;
}

int NDX_File::GetSize(LPSTR IndexName)
{
	if(!FileOpen)return -1;
	for(int n=0;n<NumFiles;n++)
	{
		if(strcmpi(Dir[n].Name,IndexName)==0)
		{
			return Dir[n].Size;
		}
	}
	return -1;
}

int NDX_File::GetSize(int Number)
{
	if(!FileOpen)return -1;
	if(Number>=0&&Number<NumFiles)
	{
		return Dir[Number].Size;
	}
	return -1;
}
