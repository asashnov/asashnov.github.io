//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
// File          : NukeDX.H
// Description   : NukeDX Main header for NukeDX.lib
// Programming   : Lasse Skyum (skyum@post5.tele.dk)
//
// Misc Stuff    : Feral Trobar (Feral@FireTop.Com)
//
//////////////////////////////////////////////////////////////////////////
#ifndef macHeader_NukeDX_h
#define macHeader_NukeDX_h
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
//////////////////////////////////////////////////////////////////////////
//  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //
//////////////////////////////////////////////////////////////////////////

// Disable some anoying warnings!
#pragma warning( disable : 4514 )
#pragma warning( disable : 4201 )

#define NUKEDX_VERSION "v1.7b2"
#pragma message ( "** Using NukeDX version "NUKEDX_VERSION)

// Get the version string of the .lib.
// Use it like so:
//    // Just to be sure when you are developing, check that your NukeDX.lib
//    //  and NukeDX.H versions are synchronized.
//    if ( strcmp ( NDX_GetVersion(), NUKEDX_VERSION ) !=0 )
//    {
//        // ERROR! You have mismatched lib and .h!!!
//        char caBuffer[255];
//        sprintf(caBuffer, "NukeDX.Lib: %s\nNukeDX.H: %s", NDX_GetVersion(), NUKEDX_VERSION);
//        MessageBox ( g_hwnd, caBuffer, "ERROR!! Mismatched versions for NukeDX.Lib and NukeDX.H!", (MB_OK) );
//        return FALSE;
//    }                                   // EO: if
const char *NDX_GetVersion ( void );

// You can "#define NDX_INC_LIBS" before you include NukeDX.h and you will not
// have to worry about what .libs you need to link with. Of course there are
// probably a few I missed, and this will only work as long as your compiler
// can manage `#pragma comment (lib, "ddraw.lib" )`... Tested with VC5 (Better
// work with VC6! (: )
#ifdef  NDX_INC_LIBS

#pragma message ( "**Including for link: nukedx.lib" )
#pragma comment ( lib, "nukedx.lib" )
#pragma message ( "**Including for link: ddraw.lib" )
#pragma comment ( lib, "ddraw.lib" )
#pragma comment ( lib, "dxextra.lib" )
#pragma message ( "**Including for link: dsound.lib" )
#pragma comment ( lib, "dsound.lib" )
#pragma message ( "**Including for link: dinput.lib" )
#pragma comment ( lib, "dinput.lib" )
#endif

#ifndef STRICT
#define STRICT
#endif

// Include needed headers
//#include <vcl.h>
#include <mmsystem.h>
#include <stdio.h>
#include <ddraw.h>
#include <dplay.h>
#include <dplobby.h>
#include <dinput.h>
#include <dsound.h>
#include <math.h>
#include <amstream.h>
#include <ddstream.h>

// ** Macros
#define RELEASE(x) if(x!=NULL){x->Release();x=NULL;}
#define DEL(x) if(x!=NULL){delete x;x=NULL;}
#define DELOBJ(x) if(x!=NULL){DeleteObject(x);x=NULL;}
#define FREE(x) if(x!=NULL){free(x);x=NULL;}

// ** Surface types
#define NDXST_BESTFIT		0x0001 // Try videomemory first, if no free videomemory - use systemmemory.
#define NDXST_VIDMEM		0x0002 // Use videomemory, if any.
#define NDXST_SYSMEM		0x0003 // Use systemmemory.
#define NDXST_TEXTURE		0x0004 // This surface is a texture for Direct3D.
#define NDXST_TEXTUREMANAGE	0x0005 // This surface is a texture for Direct3D, and use Texture management.
#define NDXST_D3D			0x0100 // This surface can be used for Direct3D rendering.

// ** Pixelformats
#define NDXPF_UNKNOWN		0 // Not a known pixelformat - NukeDX will use the pixelmasks for any color-convertions
// 16bit
#define NDXPF_555			1 // Pixelformat is 555 - Some functions are hardcoded for this, to gain speed.
#define NDXPF_565			2 // Pixelformat is 565 - Some functions are hardcoded for this, to gain speed.
// 24/32 bit (Not supported yet)
#define NDXPF_RGB			3 // 24 or 32 bit with [R8:G8:B8]

// ** Flip Flags
#define NDXFF_STRETCH		1

// ** Displayflags

// Don't create backbuffer for pageflipping
#define NDXDF_NOBACK		DWORD(1)

// Create BackSurface in systemmemory. (NDX_Screen::Flip() will copy from back to primary)
#define NDXDF_SYSMEMBACK	DWORD(1<<1)

// Enable Direct3D rendering on primary and back surface.
#define NDXDF_D3D			DWORD(1<<2)

// Enabling Control-Alt-Delete from fullscreen-mode.
#define NDXDF_ALLOWREBOOT	DWORD(1<<3)

// ** Errorcodes
#define NDXERR DWORD
#define NDXERR_OK					0
#define NDXERR_CREATEDDRAW			1
#define NDXERR_SETDISPMODE			2
#define NDXERR_SETCOORPLEVEL		3
#define NDXERR_PRIMSURFACE			4
#define NDXERR_BACKSURFACE			5
#define NDXERR_CREATESURFACE		6
#define NDXERR_LOCK					7
#define NDXERR_UNLOCK				8
#define NDXERR_LOCKDC				9
#define NDXERR_UNLOCKDC				10
#define NDXERR_BADDISPMODE			11
#define NDXERR_BADFILE				12
#define NDXERR_OUTOFMEM				13
#define NDXERR_LOADWAV				14
#define NDXERR_BADWAV				15
#define NDXERR_DSOUNDCREATE			16
#define NDXERR_DSOUNDSETCOOP		17
#define NDXERR_SAMPLEUNP			18
#define NDXERR_CREATESB				19
#define NDXERR_NOAVAILBUF			20
#define NDXERR_SETVOLUME			21
#define NDXERR_CANTPLAY				22
#define NDXERR_WRITEWAVDATA			23
#define NDXERR_BADBMP				24
#define NDXERR_BLTFAIL				25
#define NDXERR_FLIPERR				26
#define NDXERR_NOTRGBPSD			27
#define NDXERR_EVENT				28
#define NDXERR_BADNUKFILE			29
#define NDXERR_SURFACENC			30
#define NDXERR_ALPHANC				31
#define NDXERR_CCLIP				32
#define NDXERR_NOTPSD				33
#define NDXERR_CPAL					34
#define NDXERR_SETPAL				35
#define	NDXERR_DICREATEFAILED		36
#define NDXERR_DIMOUSEAQFAILED		37
#define NDXERR_DIKEYSAQUFAILED		38
#define NDXERR_DIENUMF				39
#define NDXERR_DIQUERYFAILED		40
#define NDXERR_DISETJOYRANGE		41
#define NDXERR_DIJOYAQFAILED		42
#define NDXERR_MIDICLOSEFAILED		43
#define NDXERR_MIDIOPENFAILED		44
#define NDXERR_MIDIPLAYFAILED		45
#define NDXERR_MIDISTOPFAILED		46
#define NDXERR_MIDIRESUMEFAILED		47
#define NDXERR_MIDIRESTARTFAILED	48
#define NDXERR_CREATEFILE			49
#define NDXERR_NOBACK				50
#define NDXERR_DDSOUNDNC			51
#define NDXERR_NCPAL				52

// ** Forward referances
class NDX_Surface;
class NDX_Sound;
class NDX_SurfaceList;
class NDX_Timer;
class NDX_Video;
class NDX_Screen;
class NDX_Sample;
class NDX_RLESurface;
class NDX_PixelFormat;
class NDX_Palette;
class NDX_Midi;
class NDX_Input;
class NDX_DirtyRect;
class NDX_Connect;
class NDX_CDMusic;
class NDX_AlphaMask;
class NDX_Sprite;
class NDX_SpriteControl;
class NDX_Log;
class NDX_FrameList;

// ** Stand alone functions
int NDX_FileSize(FILE *fh);
RECT NDX_RECT(int left,int top,int right,int bottom);
RECT NDX_SizeRECT(int left,int top,int width,int height);
void NDX_GetTextSize(HDC hdc,LPSTR String,int *Width,int *Height);
HFONT NDX_MakeFont(const char* FontName, int Width, int Height);
void NDX_DeleteFont(HFONT Font);
void memsetw(void *dest,unsigned short x,int count);
void memsetd(void *dest,int x,int count);

// Types
typedef void (*NDX_SURFACERESTORECB)(NDX_Surface*,void*);
typedef void (*NDX_ERRORCB)(NDXERR Error);

// Error checking
LPSTR NDX_ErrorToStr(NDXERR Error); // Convert an errorcode to a string.

// For compatibility with CNukeFile, without having to include NukeFile.h
#ifndef NF_FILEBUF_DEFINED
#define NF_FILEBUF_DEFINED
struct NF_FileBuffer
{
	unsigned char *FileBuffer;
	int Size;
};
#endif


//////////////////////////////////////////////////////////////////////////
// Class: NDX_DirtyRect
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_DirtyRect
{
public:
	// Set the border to fit a Surface.
	// ect.: SetBorder(Screen->Primary);
	void SetBorder(NDX_Surface *s);

	// Set the border. Default is {0,0,0,0}
	// ect.: SetBorder(NDX_RECT(0,0,640,480));
	void SetBorder(RECT area);

	// Add a rectangle, by passing a RECT struct
	void AddRect(RECT area);

	// Add a rectangle, by passing top-left and right-bottom coordinates.
	void AddRect(int x1,int y1,int x2,int y2){ AddRect( Rect(x1,y1,x2,y2) ); }

	// Trash all other rectangles, and add the whole screen.
	void AddWholeScreen();

	// Select what rectangle-number 'ClipRect' should describe.
	void SelectRect(int n);

	// Assign a NDX_Surface::ClipRect to use the rectangle selected by SelectRect.
	// Does the same as: Surface->ClipRect=&DirtyRect->ClipRect;
	void AssignSurface(NDX_Surface *Surface);

	// Merge rectangles that overlab more than 1/32 of their total area.
	void Merge();

	// Flush all rectangles. Used before beginning a new screen-update.
	void Reset();

	// Amount of rectangles.
	// ect.: for(int n=0;n<ClipRect->NumRects;n++){ SelectRect(n); 'do your blitting here' }
	int NumRects;

	// RECT structure that contains coordinates for the selected rectangle.
	RECT ClipRect;

	NDX_DirtyRect();
	virtual ~NDX_DirtyRect();

private:
	RECT Border;
	void DeleteRect(int n);
	bool WholeScreen;
	int OverlapArea(RECT &a1,RECT &a2);
	int MaxRects;
	LPRECT DirtyRects;

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Midi
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Midi
{
public:
	// Initialize this Midi object.
	void Create(HWND hwnd);

	// Load from a CNukeFile.
	// ect. Load("Intro_Music",NF.GetFile("Intro.mid"));
	NDXERR Load(LPSTR Name, NF_FileBuffer FileBuffer);

	// Load from a filehandle.
	NDXERR Load(LPSTR Name, FILE * fh, long size);

	// Load from a file.
	NDXERR Load(LPSTR FileName);

	// Play music.
	NDXERR Play();

	// Stop music.
	NDXERR Stop();

	// Pause music.
	NDXERR Pause();

	// Resume music.
	NDXERR Resume();

	// Restart music.
	NDXERR Restart();

	NDX_Midi();
	~NDX_Midi();

private:
	HWND Hwnd;
	BOOL IsFromWAD;
	BOOL IsReady;
	LPSTR TFileName;
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_CDMusic
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_CDMusic
{
public:
	void Resume();
	void Pause();
	bool DeviceOpen;
	bool CheckID(MCIDEVICEID wDeviceID);
	bool Close();
	bool Open();
	bool Playing;
	short NumTracks;
	short *TrackLength;
	short DevID;
	MCI_OPEN_PARMS MCIOpen;
	short ReadTOC();
	void SetNumTracks(short Tracks){NumTracks=Tracks;}
	short GetTrackLen(short Track);
	void SetTrackLen(short Track, short NewLen);
	short GetTotalLen(void);
	void Play(short Track, bool Continue);
	void PlayNotify(HWND hwnd,short Track, bool Continue);
	void Stop();
	NDX_CDMusic();
	virtual ~NDX_CDMusic();
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Video
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Video
{
public:
	void Stop();
	void Start();
	bool IsPlaying(){return Playing;}
	void StreamMedia(NDX_Surface *dest,FILE *fh,RECT destarea,int size);
	void StreamMedia(NDX_Surface *dest,LPSTR filename,RECT dstarea);
	void DrawMedia(NDX_Surface *dest,RECT destarea);
	void UpdateMedia();
	void CloseMedia();
	void OpenMedia(NDX_Screen *ParentScreen,LPSTR filename);
	bool OpenMMStream(const char * pszFileName, IDirectDraw *pDD, IMultiMediaStream **ppMMStream);
	NDX_Video();
	virtual ~NDX_Video();

protected:
	bool Playing;
	bool MediaOpen;
	LPDIRECTDRAW lpDD;
	IMultiMediaStream *pMMStream;
	IMediaStream *pPrimaryVidStream;
	IDirectDrawMediaStream *pDDStream;
	IDirectDrawStreamSample *pSample;
	IDirectDrawSurface *pSurface;
	IDirectDrawSurface4 *pSurface4;
	RECT rect;

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_RLESurface
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_RLESurface
{
public:
	// Select the clipping rectangle.
	// Default is NDX_Screen::ClipRect
	NDXERR SetClip(LPRECT area);

	// Use theese Load functions to create the RLESurface from an 8bit BMP-RLE image.
	NDXERR Load(NDX_Screen *ParentScreen,LPSTR filename,bool Remap);
	NDXERR Load(NDX_Screen *ParentScreen,FILE *fh,int FileSize,bool Remap);
	NDXERR Load(NDX_Screen *ParentScreen,NF_FileBuffer FileBuffer,bool Remap);

	// Draw the RLESurface, by decoding the RLE image.
	NDXERR Draw(NDX_Surface *dest,int Xpos,int Ypos);

	// Turn On/Off transparency.
	NDXERR SetTransP(bool OnOff);

	// Select transparent color. (NOTE: It's the index-color, not the RGB color)
	NDXERR SetColorKey(DWORD Color);

	// Select what palette to use. If you load with Remap as true, it
	// will be remapped for the selected palette. The default palette is
	// assigned to the NDX_Screen::Palette.
	NDXERR SetPalette(NDX_Palette *Pal);

	bool TransP;
	DWORD ColorKey;
	LPRECT ClipRect;
	int Height;
	int Width;
	NDX_Palette *Palette;
	NDX_Screen *Screen;
	NDX_RLESurface();
	virtual ~NDX_RLESurface();

private:
	unsigned char * Surface;
	int DataSize;
	NDXERR Load(FILE *fh,int FileSize,bool Remap);
	NDXERR Create(NDX_Screen *ParentScreen);
	NDXERR Load(LPSTR filename,bool Remap);
	NDXERR Load(NF_FileBuffer,bool Remap);
	NDXERR Draw_8(NDX_Surface *dest,int Xpos,int Ypos);
	NDXERR Draw_16(NDX_Surface *dest,int Xpos,int Ypos);
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Input
// About:
//  Handles DirectInput.
//////////////////////////////////////////////////////////////////////////
class NDX_Input
{
public:
	// Set position of mouse.

	void SetMousePos(int x,int y);
    // Create the DirectInput objects.
    NDXERR Create(HINSTANCE inst, HWND hwnd);

    // Set the area the the mouse coordinates is limited to.
    void SetMouseLimit(NDX_Screen *Screen);
    void SetMouseLimit(int x1,int y1,int x2,int y2);

    // The name of a keynumber. The Name is written in Name.
    NDXERR GetKeyName(int KeyNumber,LPSTR Name);


    // Returns true if the MouseXPos and MouseYPos are inside _rectArea
    bool IsMouseInside(RECT _rectArea);

    // Screen Edge Detection
    // The Border is the Mouse Limit border. Use SetMouseLimit to change.
    bool IsMouseInsideLEdgeBorder ( int _iBorderWidth );  // Left Edge
    bool IsMouseInsideTEdgeBorder ( int _iBorderWidth );  // Top Edge
    bool IsMouseInsideREdgeBorder ( int _iBorderWidth );  // Right Edge
    bool IsMouseInsideBEdgeBorder ( int _iBorderWidth );  // Bottom Edge

    // How much has the mouse been moved.
    int MouseX;
    int MouseY;

    // What's the current coordinates of the mouse.
    int MouseXPos;
    int MouseYPos;

    // Joystick coordianes.
    int JoyX;
    int JoyY;

    // Joystick button states.
    bool JoyB1, JoyB2;

    // Mouse button states.
    bool MouseLB, MouseMB, MouseRB;

    // Was the mouse clicked.
    bool MouseLBClick, MouseMBClick, MouseRBClick;

    // Double click detection, many thanks to Seth, aka Deadline!
    // Was the mouse double clicked.
    bool MouseLBDblClick, MouseMBDblClick, MouseRBDblClick;

    // Get and set the double click delay amount
    DWORD GetDoubleClickDelay ( void )  { return m_dwDoubleClickDelay; }
    void SetDoubleClickDelay ( DWORD _dwNew = 300 ) { m_dwDoubleClickDelay = _dwNew; }

    // Keyboard key-states.
    // ect.: if(Input->Keys[DIK_SPACE])...
    unsigned char Keys[256];

    // Is there a have a mouse.
    bool MouseActive;

    // Is there a keyboard.
    bool KeysActive;

    // Is there a joystick.
    bool JoyActive;

    // Get new information from the input-devices. (Must be called to get information!)
    void Refresh();

    void ReAcquire();
    void UnAcquire();
    void SetActiveDevices(bool Mouse, bool Keys, bool Joy);
    void RunMouseCPL(HWND hwnd=NULL);
    void RunJoyCPL(HWND hwnd=NULL);
    RECT MouseLimit;
    LPDIRECTINPUT lpDI;
    LPDIRECTINPUTDEVICE lpDIDKeys;
    LPDIRECTINPUTDEVICE lpDIDMouse;
    LPDIRECTINPUTDEVICE2 lpDIDJoy;
    LPDIRECTINPUTDEVICE lpDID;
    NDX_Input();
    virtual ~NDX_Input();

protected:
    // Double click detection, many thanks to Seth, aka Deadline!
    DWORD       m_dwDoubleClickTimeLB;
    DWORD       m_dwDoubleClickTimeMB;
    DWORD       m_dwDoubleClickTimeRB;
    DWORD       m_dwDoubleClickDelay;
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Connect
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Connect
{
public:
	DWORD GUARANTEED;
	void SetGuarenteed(bool OnOff);
	NDXERR RemoveGameScanEvent();
	NDXERR RemovePlayerScanEvent();
	MMRESULT PSEHandle;
	MMRESULT GSEHandle;
	NDXERR SetPlayerScanEvent(int MiliSec);
	NDXERR SetGameScanEvent(int MiliSec);
	struct NetMessage
	{
		DWORD dwType;
		void *Data;
		DWORD DataSize;
	};
	struct NetPlayer
	{
		char Name[255];
		DPID dpid;
	};
	struct NetGame
	{
		char Name[255];
		GUID guid;
	};
	struct NetConnection
	{
		void *data;
		char Name[255];
		GUID guid;
	};
	int GetMessageCount();
	bool Create(LPGUID g);
	bool Connect(int CNum);
	bool ConnectMODEM(char * Phone,char *Modem);
	bool ConnectIPX();
	bool ConnectTCPIP(char *IPAddress);
	bool ConnectSERIAL(DWORD ComPort,DWORD BaudRate);
	bool CloseConnection();
	int FindSPGUID(GUID spguid);
	int NumConnections;
	int NumPlayers;
	int NumGames;
	int PlayerStorage;
	int GameStorage;
	NetConnection *Connections;
	NetPlayer *Players;
	NetGame *Games;
	void* ConnectionData;
	int MaxPlrs;
	DWORD RBufferSize;
	LPGUID guid;
	bool Send(DPID To,LPVOID Data,DWORD DataSize);
	bool Send(DPID To,DWORD dwType);
	bool Send(DPID To,NetMessage *Message);
	bool Receive();
	bool Receive(void * Data,DWORD *DataSize);
	bool CreateGame(LPSTR Name,LPSTR PlayerName,int MaxPlayers);
	bool JoinGame(int GameNumber,LPSTR PlayerName);
	bool ScanForGames(int TimeOut,bool Async);
	bool ScanForPlayers();
	bool HideGame();
	bool CloseGame();
	LPDIRECTPLAY4A lpDP;
	DPID FromDPID;
	DPID ToDPID;
	DPID LocalDPID;
	void * RBuffer;
	DWORD MessageSize;
	NDX_Connect();
	virtual ~NDX_Connect();
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Timer
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Timer
{
public:
	// Start timer.
	void StartNow();

	// Get time since last call to eighter StartNow() or GetDalta().
	// TimeUnit = ticks pr. sek
	double GetDelta(double TimeUnit);
	double GetDelta(double TimeUnit,double MinDelta);

	// Get time in seconds.
	double GetTime()
	{
		__int64 ThisTick;
		QueryPerformanceCounter((LARGE_INTEGER*)&ThisTick);
		return double(ThisTick)/double(Freq);
	}
	double LastTime;
	__int64 Freq;
	NDX_Timer();
	virtual ~NDX_Timer();
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_SurfaceList
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_SurfaceList
{
	struct Element
	{
		Element* Last;
		Element* Next;
		NDX_Surface *Surface;
	};
public:
	void RemoveAll();
	NDX_Surface * GetNext();
	NDX_Surface * GetFirst();
	void ReleaseAll();
	void RestoreAll();
	void RemoveSurface(NDX_Surface *Surface);
	void AddSurface(NDX_Surface *Surface);
	Element *First;
	Element *Last;
	Element *Next;
	int NumElements;
	NDX_SurfaceList();
	virtual ~NDX_SurfaceList();
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Sample
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Sample
{
public:
	// Play the sample. Volume 0 is max value, The volume range is DSBVOLUME_MIN to DSBVOLUME_MAX.
	// ect.:
	// int SampleHandle;
	// Sample->Play(0,&SampleHandle);
	NDXERR Play(int Volume, int *Handle);

	// Play the sample. Volume 0 is max value, The volume range is DSBVOLUME_MIN to DSBVOLUME_MAX.
	// ect.:
	// Sample->Play_Finish(0);
	NDXERR Play_Finish(int Volume);

	// Same as play, but the sample keeps looping.
	// Use Stop to stop the sample again.
	NDXERR Loop(int Volume,int *Handle);

	// Is the sample still playing.
	bool IsPlaying(int Handle);

	// Stop the playing of a soundbuffer.
	// ect.: Sample->Stop(SampleHandle);
	NDXERR Stop(int Handle);

	// Stop all the soundbuffers.
	NDXERR StopAll();

	// Change the volume of a playing soundbuffer.
	// ect.: Sample->SetVolume(SampleHandle,-100);
	void SetVolume(int Handle,int Volume);

	// Create the sample from a WAV file.
	NDXERR LoadWAV(NDX_Sound *Parent, FILE *fh,int NumBuffers, int FileSize);
	NDXERR LoadWAV(NDX_Sound *Parent, NF_FileBuffer FileBuffer,int NumBuffers);
	NDXERR LoadWAV(NDX_Sound *Parent, LPSTR filename, int NumBuffers);

	NDX_Sample();
	virtual ~NDX_Sample();

private:
	int GetAvailBuf();
	bool WriteWAVData(LPDIRECTSOUNDBUFFER lpDSB);
	NDXERR LoadWAV(NDX_Sound *Parent, unsigned char *RawData, int NumBuffers, int FileSize);
	int	bufCount;
	DWORD dwWAVSize;
	LPBYTE lpWAVData;
	unsigned char *DataBuffer;
	LPWAVEFORMATEX lpwfmx;
	LPDIRECTSOUNDBUFFER *lpDSBuf;
	NDX_Sound *Sound;

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Sound
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Sound
{
public:
	// Create DirectSound object.
	NDXERR Create(HWND hwnd);
	LPDIRECTSOUND lpDS;
	NDX_Sound();
	virtual ~NDX_Sound();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_PixelFormat
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_PixelFormat
{
public:
	// Create pixelformat information, from a surface.
	void Create(NDX_Surface *Surface);

	// Transform RGB values into the pixelformat.
	// ect.: Screen->PixelFormat->Rgb(255,0,0); // Will return a red color, for the current pixelformat.
	DWORD Rgb(DWORD r,DWORD g,DWORD b){return (((r>>RedMissingBits)<<RedBase)|((g>>GreenMissingBits)<<GreenBase)|((b>>BlueMissingBits)<<BlueBase));}

	// Extract the red conponent of a color.
	DWORD GetRed(DWORD c){return (((c&RedMask)>>RedBase)<<RedMissingBits);}

	// Extract the green conponent of a color.
	DWORD GetGreen(DWORD c){return (((c&GreenMask)>>GreenBase)<<GreenMissingBits);}

	// Extract the blue conponent of a color.
	DWORD GetBlue(DWORD c){return (((c&BlueMask)>>BlueBase)<<BlueMissingBits);}

	int FindBase(DWORD Mask);
	int FindBitCount(DWORD Mask);
	DWORD RedMask;
	DWORD GreenMask;
	DWORD BlueMask;
	DWORD RedBase;
	DWORD GreenBase;
	DWORD BlueBase;
	DWORD RedMissingBits;
	DWORD GreenMissingBits;
	DWORD BlueMissingBits;
	DWORD BitCount;
	int PF;
	NDX_PixelFormat();
	virtual ~NDX_PixelFormat();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Palette
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Palette
{
public:
	NDXERR CreateLUT();
	NDXERR FadeOut(int Delay);
	NDXERR FadeIn(int Delay);
	NDXERR UpdateColors(int Intensity);
	NDXERR UpdateColors();
	DWORD *LookUp;
	DWORD Allow256;
	NDXERR CreateAlphaLookUp();
	unsigned short *ALU_ToRGB;
	unsigned char *ALU_ToIndex;
	void LoadPCXPalette(LPSTR filename);
	void LoadPCXPalette(FILE *fh,int FileSize);
	void LoadPCXPalette(NF_FileBuffer FileBuffer);
	void LoadBMPPalette(LPSTR filename);
	void LoadBMPPalette(FILE *fh);
	void LoadBMPPalette(NF_FileBuffer FileBuffer);
	void LoadACTPalette(LPSTR filename);
	void LoadACTPalette(FILE *fh);
	void LoadACTPalette(NF_FileBuffer FileBuffer);
	void LoadPaletteLookUp(LPSTR filename);
	void SavePaletteLookUp(LPSTR filename);
	int RGBToIndex(DWORD Red,DWORD Green,DWORD Blue);
	DWORD IndexToRGB(int Index);
	DWORD IndexToPixelFormat(int Index);
	int PixelFormatToIndex(DWORD Color);
	void SetColor(int Index, DWORD Red,DWORD Green,DWORD Blue);
	NDXERR SetPalette();
	NDXERR Init(NDX_Screen *ParentScreen, bool _Allow256);
	NDX_Screen *Screen;
	LPDIRECTDRAWPALETTE ddpal;
	HPALETTE hpal;
	LPPALETTEENTRY Palette;
	NDX_Palette();
	virtual ~NDX_Palette();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Screen
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Screen
{
public:
	struct TexMapTable
	{
		int x;
		int px;
		int py;
	};
	struct DDriver
	{
		LPGUID lpGuid;
		LPSTR Desc;
		LPSTR Name;
	};
	struct DisplayMode
	{
		int Width;
		int Height;
		int Depth;
		char Description[20];
	};
	TexMapTable *lefttable;
	TexMapTable *righttable;
	int TaxMapTableHeight;
	DDriver *Drivers;
	int NumDrivers;
	NDXERR Create(LPGUID guid);
	NDXERR SetHidden(DWORD Flags,HWND hwnd,int Depth);
	bool CheckDisplayMode(int Width,int Height,int Depth);
	DWORD DisplayFlags;
	NDXERR ChangeRes(int Width,int Height);
	bool SysmemBack;
	void WaitVBlank();
	RECT ClipRect;
	bool Windowed;
	HWND Hwnd;
	LPDIRECTDRAWCLIPPER Clipper;
	NDX_SurfaceList * Surfaces;
	DWORD FrameCount;
	DWORD LastShowFPS;
	double FPS;
	void ShowFPS(int Xpos,int Ypos){ShowFPS(Back,Xpos,Ypos);}
	void ShowFPS(NDX_Surface *dest,int Xpos,int Ypos);
	NDXERR Flip(){return Flip(0);}
	NDXERR Flip(DWORD Flags);
	NDXERR Flip(DWORD Flags,NDX_DirtyRect *Rects);
	void EnumDispModes();
	int NumDisplayModes;
	DisplayMode *DisplayModes;
	NDX_PixelFormat *PixelFormat;
	NDX_Surface *Back;
	NDX_Surface *Primary;
	NDX_Palette *Palette;
	LPDIRECTDRAW4 lpDD;
	NDXERR Create();
	NDXERR SetFullScreen(DWORD Flags,HWND hwnd,int Width,int Height,int Depth);
	NDXERR SetWindowed(DWORD Flags,HWND hwnd,int Width,int Height);
	NDX_Screen();
	virtual ~NDX_Screen();

private:
	void EnumDrivers();
};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Surface
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_Surface
{
	struct PSDInfo
	{
		struct Pixel
		{
			unsigned char Channel[4];
		};
		Pixel *Pixels;
		int Width;
		int Height;
		int ChannelCount;
		int Compression;
		unsigned char *DataPtr;
	};
protected:
	// New grfx loaders for use with CNukeFile.
	NDXERR UnpackPSD(PSDInfo *ImageInfo);
	NDXERR LoadPSD(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool UseAlpha);
	NDXERR LoadPSD(NDX_Screen *ParentScreen, int type, FILE *fh, int Xpos, int Ypos, bool UseAlpha,int FileSize);
	NDXERR DrawPSD_24_X(int Xpos,int Ypos,PSDInfo *ImageInfo);

	NDXERR LoadBMP(NDX_Screen * ParentScreen, int type, NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool Remap);
	NDXERR LoadBMP(NDX_Screen * ParentScreen, int type, LPSTR FileName, int Xpos, int Ypos, bool Remap);
	NDXERR LoadBMP(NDX_Screen * ParentScreen, int type, FILE *fh, int Xpos, int Ypos, bool Remap, int FileSize);
	NDXERR LoadBMP_LOADER(unsigned char* FileBuffer, BITMAPFILEHEADER * bfh, BITMAPINFOHEADER * bih, RGBQUAD *BMPPalette, int Xpos, int Ypos, bool Remap);
	NDXERR LoadBMP_HANDLER(NDX_Screen *ParentScreen,int type,unsigned char* FileBuffer,int Xpos,int Ypos,bool Remap);
	void LoadBMP_24_X(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih);
    void LoadBMP_8_16(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);
	void LoadBMP_RLE_16(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);
	void LoadBMP_8_8(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);
	void LoadBMP_8_8_Remap(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);
	void LoadBMP_RLE_8(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);
	void LoadBMP_RLE_8_Remap(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette);

	void DrawAlpha_8(NDX_Surface *dest,int xpos,int ypos,RECT area);
	void DrawAlpha_16(NDX_Surface * dest, int xpos, int ypos, RECT area);
	void DrawTranslucent_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha);
	void DrawTranslucent_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha);
	void DrawFadeToBlack_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha);
	void DrawFadeToBlack_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha);
	void DrawColorMix_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD Color,DWORD alpha);
	void DrawColorMix_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD Color,DWORD alpha);
	void Scanrightside(int x1,int x2,int ytop,int lineheight,char side,int TexWidth,int TexHeight);
	void Scanleftside(int x1,int x2,int ytop,int lineheight,char side,int TexWidth,int TexHeight);
	void TextureMap(NDX_Surface *dest, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, RECT area);
	void DrawPaste_8(NDX_Surface *dest,int xpos,int ypos,RECT area);
	void DrawPaste_16(NDX_Surface *dest,int xpos,int ypos,RECT area);
	DWORD PSD_Read32(PSDInfo *ImageInfo);
	unsigned short PSD_Read16(PSDInfo *ImageInfo);
public:
	// Write text to the surface using GDI. Also using the same format as printf.
	// ect.
	// FormattedText(100,100,RGB(255,255,255),NULL,"Mouse x position : %u",MouseX);
	NDXERR FormattedText(int Xpos,int Ypos,DWORD Color,HFONT Font,LPSTR format,...);
	NDXERR FormattedText(int Xpos,int Ypos,DWORD Color,DWORD BackColor,HFONT Font,LPSTR format,...);
	NDXERR FormattedText_OutLine(int Xpos,int Ypos,DWORD Color,DWORD OutLineColor,HFONT Font,LPSTR format,...);

	// Draw text to the surface using GDI. If Font==NULL the defualt Font is used.
	NDXERR Text(LPSTR txt,int Xpos,int Ypos,DWORD Color,HFONT Font);
	NDXERR Text(LPSTR txt,int Xpos,int Ypos,DWORD Color,DWORD BackColor,HFONT Font);
	NDXERR Text_OutLine(LPSTR txt, int Xpos, int Ypos, DWORD Color, DWORD OutLineColor,HFONT Font);

	// Load any 8/24 bit (also RLE) BMP image into the surface.
	NDXERR LoadBMP(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, bool Remap);
	NDXERR LoadBMP(NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool Remap);
	NDXERR LoadBMP(LPSTR filename, int Xpos, int Ypos, bool Remap);
	NDXERR LoadBMP(NDX_Screen *ParentScreen, int type, LPSTR filename, bool Remap);
	NDXERR LoadBMP(FILE *fh, int Xpos, int Ypos, bool Remap, int FileSize);
	NDXERR LoadBMP(NDX_Screen *ParentScreen, int type, FILE *fh, bool Remap, int FileSize);

	// Load a 24bit RGB PSD image into the surface.
	NDXERR LoadPSD(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, bool UseAlpha);
	NDXERR LoadPSD(NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool UseAlpha);
	NDXERR LoadPSD(LPSTR FileName, int Xpos, int Ypos, bool UseAlpha);
	NDXERR LoadPSD(NDX_Screen *ParentScreen, int type, LPSTR FileName, bool UseAlpha);
	NDXERR LoadPSD(FILE *fh, int Xpos, int Ypos, bool UseAlpha, int FileSize);
	NDXERR LoadPSD(NDX_Screen *ParentScreen, int type, FILE *fh, bool UseAlpha, int FileSize);

	// Create the surface.
	// ect.:
	// Surface->Create(Screen,NDXST_SYSMEM,100,100);
	// Look for "Surface types" for a list of Surface types.
	NDXERR Create(NDX_Screen *ParentScreen,int SurfaceType,int SurfaceWidth,int SurfaceHeight);

	// Draw this surface to 'dest' with an arbitary angle and scale-factor.
	// (The Surfaces must be locked)
	// ect.: Surface->DrawRotoZoom(Screen->Back,100,100,1.7,2.3);
	void DrawRotoZoom(NDX_Surface *dest, int midX, int midY,double angle,double scale,RECT area);
	void DrawRotoZoom(NDX_Surface *dest, int midX, int midY,double angle,double scale){DrawRotoZoom(dest,midX,midY,angle,scale,NDX_RECT(0,0,Width,Height));}

	// Select what alphachannel to use. (Normally NOT needed)
	// The selected alphachannel must have the same size as the surface.
	// NOTE: The selected alphamask will be deleted by the surface's destructor!
	//		 Call Surface->SelectAlpha(NULL) first, if you don't want that.
	void SelectAlpha(NDX_AlphaMask *a);

	// Create the alphachannel.
	NDXERR CreateAlpha();

	// Create the alphachannel, and load any 8bit BMP image, with the
	// same size as the surface, into it.
	NDXERR LoadAlpha(LPSTR filename,int Xpos,int Ypos);
	NDXERR LoadAlpha(FILE *fh, int Xpos,int Ypos, int FileSize);
	NDXERR LoadAlpha(NF_FileBuffer, int Xpos,int Ypos);

	// Draw this surface to dest.
	void Draw(NDX_Surface *dest,RECT SourceRect,RECT DestRect);
	void Draw(NDX_Surface *dest,int x,int y,RECT area);
	void Draw(NDX_Surface *dest,int x,int y){Draw(dest,x,y,NDX_RECT(0,0,Width,Height));}

	// The same as Draw, except the surface must be locked first.
	// If you got many small sprites, this function may speed up your game.
	void DrawPaste(NDX_Surface *dest,int x,int y,RECT area);
	void DrawPaste(NDX_Surface *dest,int x,int y){DrawPaste(dest,x,y,NDX_RECT(0,0,Width,Height));}

	// Select what palette to use. Default is the parent-screen's palette.
	NDXERR SetPalette(NDX_Palette *Pal);

	// Draw this surface to dest, using the alphachannel for alphablending.
	// (The Surfaces must be locked)
	void DrawAlpha(NDX_Surface *dest,int xpos,int ypos,RECT area);
	void DrawAlpha(NDX_Surface *dest,int xpos,int ypos){DrawAlpha(dest,xpos,ypos,NDX_RECT(0,0,Width,Height));}

	// Draw this surface to dest, but with translucency (alpha 0-256) (NOT 0-255)
	// (The Surfaces must be locked)
	void DrawTranslucent(NDX_Surface *dest,int xpos,int ypos,RECT area,DWORD alpha);
	void DrawTranslucent(NDX_Surface *dest,int xpos,int ypos,int alpha){DrawTranslucent(dest,xpos,ypos,NDX_RECT(0,0,Width,Height),alpha);}

	// Draw this surface to dest, but blending to black (alpha 0-256, 0=Black 256=Normal)
	// (The Surfaces must be locked)
	void DrawFadeToBlack(NDX_Surface *dest,int xpos,int ypos,RECT area,DWORD alpha);
	void DrawFadeToBlack(NDX_Surface *dest,int xpos,int ypos,int alpha){DrawFadeToBlack(dest,xpos,ypos,NDX_RECT(0,0,Width,Height),alpha);}

	// Like DrawFadeToBlack, but is able to blend to any color.
	// (The Surfaces must be locked)
	void DrawColorMix(NDX_Surface *dest,int xpos,int ypos,RECT area,DWORD Color,DWORD alpha);
	void DrawColorMix(NDX_Surface *dest,int xpos,int ypos,DWORD Color,int alpha){DrawColorMix(dest,xpos,ypos,NDX_RECT(0,0,Width,Height),Color,alpha);}

	// Draw a filled rectangle, with the color 'Color'.
	NDXERR FillRect(int x1,int y1,int x2,int y2,DWORD Color);

	// Clear the whole surface to the color 'Color'.
	NDXERR Clear(DWORD Color);

	// Specify a callback function, to be called when the contents of the surface needs
	// to be restored. NukeDX will restore the surface, but you must restore the contents.
	// Remember that this is only needet for surfaces in video-memory.
	void SetRestoreCallBack(NDX_SURFACERESTORECB RCB,void *AppData);

	// Turn On/Off transparency/colorkeying.
	void SetTransP(bool OnOff){TransP=OnOff;}

	// Select what colorkey to use.
	// NOTE: DrawTransparent/DrawColorMix/DrawFadeToBlack will only the
	// LowColor, if you specify a range of colors.
	void SetColorKey(DWORD LowColor,DWORD HiColor);
	void SetColorKey(DWORD Color);

	// Select clipping area, as default it is assigned to the parentscreens ClipRect.
	void SetClip(LPRECT Rect);

	// Lock/Unlock the DeviceContext for the surface. 'hdc' will be
	// valid when the DC is locked.
	NDXERR UnlockDC();
	NDXERR LockDC();

	// Lock/Unlock the surface. When the surface is locked 'ddsd' will be valid.
	NDXERR Unlock();
	NDXERR Lock();

	// Draw/Read pixels from the surface.
	// (The Surfaces must be locked)
	void PutPixel_8(int x,int y,BYTE Color){*(unsigned char*)((unsigned char*)lpSurface+y*lPitch+x)=Color;}
	BYTE GetPixel_8(int x,int y){return *(unsigned char*)((unsigned char*)lpSurface+y*lPitch+x);}
	void PutPixel_16(int x,int y,WORD Color){*(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+y*lPitch+x*2)=Color;}
	WORD GetPixel_16(int x,int y){return *(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+y*lPitch+x*2);}

	// Return a pointer a pixel-coordinate on the surface.
	// (The Surfaces must be locked)
	unsigned char *CalcOffset_8(int x,int y){return (unsigned char*)((unsigned char*)lpSurface+y*lPitch+x);}
	unsigned short *CalcOffset_16(int x,int y){return (unsigned short*)((unsigned char*)lpSurface+y*lPitch+x*2);}

	// Bytes pr. line in this surface. 
	// The Surface must be locked, for lPitch to be valid.
	DWORD lPitch;

	// Pointer to the top-left pixel in this surface.
	// The Surface must be locked, for lpSurface to be valid.
	void *lpSurface;

	// Width and Height of this surface.
	WORD Height;
	WORD Width;

	// Current selected colorkey.
	// If a colorkey-range is selected this is the lower color.
	DWORD ColorKey;
	
	NDX_SURFACERESTORECB RestoreCallBack;
	void *RestoreAppData;
	WORD Type;
	BYTE TransP:1,LockedDC:1,Locked:1;
	LPRECT ClipRect;
	HDC hdc;	
	LPDIRECTDRAWSURFACE4 Surface;
	NDX_Palette *Palette;
	NDX_Screen *Screen;
	NDX_AlphaMask *AlphaMask;
	void Restore();
	void Release();
	NDX_Surface();
	virtual ~NDX_Surface();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_AlphaMask
// About:
//////////////////////////////////////////////////////////////////////////
class NDX_AlphaMask
{
public:
	// Load any 8bit BMP image, with the same size as the surface, into it.
	// Alphachannel must be created first.
	bool LoadBMP(LPSTR filename, int Xpos,int Ypos);
	bool LoadBMP(FILE *fh, int Xpos,int Ypos,int FileSize);
	bool LoadBMP(NF_FileBuffer FileBuffer, int Xpos,int Ypos);

	// Generate alpha-value, from the intensity of the colors on the surface.
	NDXERR ColorIntensity(RECT area);
	NDXERR ColorIntensity(){return ColorIntensity(NDX_RECT(0,0,Surface->Width,Surface->Height));}

	// Generate alpha-value, and blur the edges to simulate antialias.
	NDXERR AntiAlias(RECT area,DWORD ColorKey);
	NDXERR AntiAlias(DWORD ColorKey){return AntiAlias(NDX_RECT(0,0,Surface->Width,Surface->Height),ColorKey);}

	// Blur the alphachannel.
	NDXERR Blur(RECT area);
	NDXERR Blur(){return Blur(NDX_RECT(0,0,Surface->Width,Surface->Height));}

	// Create the alphachannel, from the size of pSurface.
	void Create(NDX_Surface *pSurface);

	// Pointer to the alphavalues.
	unsigned char *Alpha;

	NDX_Surface *Surface;
	NDX_AlphaMask();
	virtual ~NDX_AlphaMask();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Sprite
// About:
// The point of this class is that you should make derived classes from it.
// I might make a Lib with derived classes, such as a cannon-balls or something.
//////////////////////////////////////////////////////////////////////////
class NDX_Sprite
{
public:
	// Use this function to create dirtyrectangles.
	virtual void CreateDirtyRect();

	// Send a message to this sprite.
	virtual void Message(void *lpData);

	// Move the sprite.
	virtual void Move(double delta);

	// Draw the sprite.
	virtual void Draw();

	// Used for z-sorting. Lowest number is drawn first.
	int Zpos;

	NDX_Sprite();
	virtual ~NDX_Sprite();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_SpriteControl
// About:
// Handles a list of sprites.
//////////////////////////////////////////////////////////////////////////
class NDX_SpriteControl
{
public:
	// Calls CreateDirtyRect for all the sprites.
	void CreateDirtyRects();

	// Depth sort all the sprites. (Using the Zpos member og NDX_Sprites)
	// If you use depth-sorting, call this every time you eighter add or remove sprites.
	void Sort();

	// Send a message to all the sprites.
	void Message(void *lpData);

	// Add a sprite.
	void AddSprite(NDX_Sprite *Sprite);

	// Remove a sprite.
	void RemoveSprite(NDX_Sprite *Sprite);

	// Draw all the sprites.
	void DrawAll();

	// Move all the sprites.
	void MoveAll(double delta);

	// Splits the delta-value into smaller "pieces", and call the above function.
	// The maximum size of each "piece" is max_delta.
	// Use this function if ect. a bullit and a spaceship should be able to collide
	// without the bullit "jumping" over the spaceship, because of ect. a HD-powerup.
	void MoveAll(double delta,double max_delta);

	int NumSprites;
	NDX_Sprite **Sprites;
	NDX_SpriteControl();
	virtual ~NDX_SpriteControl();

};


//////////////////////////////////////////////////////////////////////////
// Class: NDX_Log
// About:
//  A handy class that will allow you to more easily debug your games.
//  As the name implies, this allows you to easily write text to a ascii log
//  file.
//////////////////////////////////////////////////////////////////////////
class NDX_Log
{
public:
    void Close();
    // Enable/Diable buffering.
	// Examples:
    // Enable a 1000 byte buffer:	UseBuffer(true,1000);
    // Disable buffer:				UseBuffer(false,0);
    void UseBuffer(bool OnOff,int Size);

    // Write buffer to file.
    void FlushBuffer();

    // Write a string. If buffering is enabled this will be written to the
    // buffer. If buffering is disabled it will be written directly to the
    // log-file.
    void WriteString(char * format,...);

    // Write the time in the same format as strftime
    void WriteTime(char * format);

    // Create a Log file.
	// ect. Create("C:\\GameLog.txt");
	void Create(LPSTR fn);
    NDX_Log();
    virtual ~NDX_Log();

private:
    LPSTR FileName;
    LPSTR Buffer;
    int BufferSize;
    int BufferedText;
    bool bUseBuffer;
};

//////////////////////////////////////////////////////////////////////////
// Class: NDX_FrameList
// About:
// A handly class that will take source NDX_Surface that has a image that is
//  comprised of a bunch of images aranged in a grid (think graph paper). You 
//  may then Draw any `frame` simply by calling one of the Draw member functions.
//////////////////////////////////////////////////////////////////////////
class NDX_FrameList
{
public:
	struct Frame
	{
		NDX_Surface *Surface;
		RECT area;
	};

    // -------------------------------------------------------------------
    // Draw a frame to dest.
    // NDX_Surface *dest,               The destination surface to draw on.
    // int xpos,                        The destination x position on dest
    // int ypos,                        The destination y position on dest
    // int frame                        The frame index to draw.
	void Draw(NDX_Surface *dest,int xpos,int ypos,int frame);

    // -------------------------------------------------------------------
    // Draw a frame to dest, with an arbitary angle and scaling.
    // NDX_Surface *dest,               The destination surface to draw on.
    // int midX,                        The destination x position on dest
    // int midY,                        The destination y position on dest
    // int frame                        The frame index to draw.
    // double angle                     
	// double scale
	void DrawRotoZoom(NDX_Surface *dest,int midX, int midY,int frame,double angle,double scale);

    // -------------------------------------------------------------------
    // Draw a frame to dest, and mix the colors with an other color.
    // NDX_Surface *dest,               The destination surface to draw on.
    // int xpos,                        The destination x position on dest
    // int ypos,                        The destination y position on dest
    // int frame                        The frame index to draw.
	// DWORD Color						The color to mix with the surface pixels.
	// DWORD alpha						How much to mix the colors.
	void DrawColorMix(NDX_Surface * dest, int xpos, int ypos, int frame, DWORD Color,DWORD alpha);

    // -------------------------------------------------------------------
    // Draw a frame to dest, and fade the colors.
    // NDX_Surface *dest,               The destination surface to draw on.
    // int xpos,                        The destination x position on dest
    // int ypos,                        The destination y position on dest
    // int frame                        The frame index to draw.
	// DWORD alpha						How much to fade the colors.
	void DrawFadeToBlack(NDX_Surface * dest, int xpos, int ypos, int frame, DWORD alpha);

    // -------------------------------------------------------------------
    // Draw a frame to dest. 
    // NDX_Surface *dest,               The destination surface to draw on.
    // RECT DestRect                    The destination area. The frame is stretched to fit this area.
    // int frame                        The frame index to draw.
	void Draw(NDX_Surface *dest,RECT DestRect,int frame);

    // -------------------------------------------------------------------
    // Draw a frame to dest, using alphablending. (Surfaces must be locked)
    // NDX_Surface *dest,               The destination surface to draw on.
    // int xpos,                        The destination x position on dest
    // int ypos,                        The destination y position on dest
    // int frame                        The frame index to draw.
	void DrawAlpha(NDX_Surface *dest,int xpos,int ypos,int frame);

    // -------------------------------------------------------------------
    // Draw a frame to dest, using translucency. (Surfaces must be locked)
    // NDX_Surface *dest,               The destination surface to draw on.
    // int xpos,                        The destination x position on dest
    // int ypos,                        The destination y position on dest
    // int frame                        The frame index to draw.
	// DWORD alpha						Alphavalue. Range:0-256 (NOT 0-255)
	void DrawTrans(NDX_Surface *dest,int xpos,int ypos,int frame, DWORD alpha);

    // -------------------------------------------------------------------
    // Add a "grid" of frames.
    // NDX_Surface * s,                 The source surface
    // int xpos,                        The left corner to start at
    // int ypos,                        The top corner to start at
    // int FrameWidth,                  The width of the area (starting at xpos) to get the images from
    // int FrameHeight,                 The height of the area (starting at ypos) to get the images from
    // int AmountX,                     The number of `frames` across
    // int AmountY                      The number of `frames` down
	void AddFrames(NDX_Surface * s, int xpos, int ypos, int FrameWidth, int FrameHeight, int AmountX, int AmountY);

    // -------------------------------------------------------------------
    // Add a single frame at the end of the frame list.
    // NDX_Surface *s,                  The Source surface to get the image from
    // RECT a                           The RECT to get the image from *s.
	void AddFrame(NDX_Surface *s,RECT a);

    // -------------------------------------------------------------------
    // Add a single frame at the end of the frame list.
    // NDX_Surface *s,                  The Source surface to get the image from
	void AddFrame(NDX_Surface *s);

	// -------------------------------------------------------------------
	// Return a pointer to a NDX_FrameList::Frame describing the frame.
	// int frame						The frame number.
	Frame *GetFrame(int frame);

    // -------------------------------------------------------------------
    // Number or amount of frames in this list.
	int NumFrames;

	Frame *Frames;
	NDX_FrameList();
	virtual ~NDX_FrameList();

};


//////////////////////////////////////////////////////////////////////////
//  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //
//////////////////////////////////////////////////////////////////////////
#endif //#ifndef macHeader_NukeDX_h
//
///EOF

