//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_RLESurface.cpp: implementation of the NDX_RLESurface class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_RLESurface::NDX_RLESurface()
{
	Surface=NULL;
	Palette=NULL;
	TransP=false;
	ColorKey=0;
}

NDX_RLESurface::~NDX_RLESurface()
{
	FREE(Surface);
}

NDXERR NDX_RLESurface::Create(NDX_Screen * ParentScreen)
{
	Screen=ParentScreen;
	if(Palette==NULL)Palette=Screen->Palette;
	FREE(Surface);
	ClipRect=&Screen->ClipRect;
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::SetPalette(NDX_Palette * Pal)
{
	Palette=Pal;
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::Load(FILE * fh, int FileSize, bool Remap)
{
	if(fh==NULL)return NDXERR_BADBMP;
	FREE(Surface);
	BITMAPINFOHEADER bih;
	BITMAPFILEHEADER bfh;
	RGBQUAD BMPPalette[256];
	int fpos=ftell(fh);
	fread(&bfh,sizeof(bfh),1,fh);
	fread(&bih,sizeof(bih),1,fh);
	if(*(char*)((char*)&bfh.bfType)!='B'||*(char*)((char*)&bfh.bfType+1)!='M')return NDXERR_BADBMP;
	if(bih.biBitCount!=8||bih.biCompression!=1)return NDXERR_BADBMP;
	fread(&BMPPalette,sizeof(BMPPalette),1,fh);
	fseek(fh,fpos+bfh.bfOffBits,SEEK_SET);
	DataSize=FileSize-bfh.bfOffBits;
	Surface=(unsigned char*)malloc(DataSize);
	fread(Surface,DataSize,1,fh);
	Width=bih.biWidth;
	Height=bih.biHeight;

	if(Remap)
	{
		int LookUp[256];
		for(int n=0;n<256;n++)
		{
			LookUp[n]=Palette->RGBToIndex(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue);
		}
		int pos=0,a;
		bool done=false;
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				Surface[pos+1]=LookUp[Surface[pos+1]];
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					for(int i=0;i<a;i++)
					{
						Surface[pos+i]=LookUp[Surface[pos+i]];
					}
					pos+=a;
					pos+=pos&1;
				}
				else if(a==0)pos++;
				else if(a==2)pos+=3;
				else done=true;
			}
		}while(!done);
	}
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::Load(NF_FileBuffer FileBuffer, bool Remap)
{
	FREE(Surface);
	BITMAPFILEHEADER *bfh=(BITMAPFILEHEADER*)FileBuffer.FileBuffer;
	BITMAPINFOHEADER *bih=(BITMAPINFOHEADER*)(unsigned char*)((unsigned char*)FileBuffer.FileBuffer+sizeof(BITMAPFILEHEADER));
	RGBQUAD *BMPPalette=(RGBQUAD*)(unsigned char*)((unsigned char*)FileBuffer.FileBuffer+sizeof(BITMAPINFOHEADER)+sizeof(BITMAPFILEHEADER));
	if(*(unsigned char*)((unsigned char*)&bfh->bfType)!='B'||*(unsigned char*)((unsigned char*)&bfh->bfType+1)!='M')return NDXERR_BADBMP;
	if(bih->biBitCount!=8||bih->biCompression!=1)return NDXERR_BADBMP;
	DataSize=FileBuffer.Size-bfh->bfOffBits;
	Surface=(unsigned char*)malloc(DataSize);
	memcpy(Surface,FileBuffer.FileBuffer+bfh->bfOffBits,DataSize);
	Width=bih->biWidth;
	Height=bih->biHeight;

	if(Remap)
	{
		int LookUp[256];
		for(int n=0;n<256;n++)
		{
			LookUp[n]=Palette->RGBToIndex(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue);
		}
		int pos=0,a;
		bool done=false;
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				Surface[pos+1]=LookUp[Surface[pos+1]];
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					for(int i=0;i<a;i++)
					{
						Surface[pos+i]=LookUp[Surface[pos+i]];
					}
					pos+=a;
					pos+=pos&1;
				}
				else if(a==0)pos++;
				else if(a==2)pos+=3;
				else done=true;
			}
		}while(!done);
	}
	return NDXERR_OK;
}


NDXERR NDX_RLESurface::Load(NDX_Screen *ParentScreen, FILE * fh, int FileSize, bool Remap)
{
	NDXERR rval=Create(ParentScreen);
	if(rval!=NDXERR_OK)return rval;
	return Load(fh,FileSize,Remap);
}

NDXERR NDX_RLESurface::Load(LPSTR filename, bool Remap)
{
	FILE *fh=fopen(filename,"rb");
	NDXERR rval=Load(fh,NDX_FileSize(fh),Remap);
	fclose(fh);
	return rval;
}

NDXERR NDX_RLESurface::Load(NDX_Screen * ParentScreen, LPSTR filename, bool Remap)
{
	NDXERR rval=Create(ParentScreen);
	if(rval!=NDXERR_OK)return rval;
	return Load(filename,Remap);
}

NDXERR NDX_RLESurface::Load(NDX_Screen * ParentScreen, NF_FileBuffer FileBuffer, bool Remap)
{
	NDXERR rval=Create(ParentScreen);
	if(rval!=NDXERR_OK)return rval;
	return Load(FileBuffer,Remap);
}

NDXERR NDX_RLESurface::SetColorKey(DWORD Color)
{
	ColorKey=Color;
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::SetTransP(bool OnOff)
{
	TransP=OnOff;
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::Draw(NDX_Surface * dest, int Xpos, int Ypos)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			return Draw_8(dest,Xpos,Ypos);
		case 16:
			return Draw_16(dest,Xpos,Ypos);
	}
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::Draw_8(NDX_Surface * dest, int Xpos, int Ypos)
{
	if(Xpos>=ClipRect->right)return NDXERR_OK;
	if(Ypos>=ClipRect->bottom)return NDXERR_OK;
	if(Xpos+Width<=ClipRect->left)return NDXERR_OK;
	if(Ypos+Height<=ClipRect->top)return NDXERR_OK;

	int pos=0,a,x=Xpos,y=Height-1;
	bool LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
	unsigned char *LinePtr=(unsigned char*)dest->lpSurface+(Ypos+y)*dest->lPitch;
	bool done=false;
	if(TransP)
	{
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				unsigned char c=Surface[pos+1];
				if(LineOk&&c!=ColorKey)
				{
					int StartX=x;
					int Length=a;
					if(StartX<ClipRect->left)
					{
						Length-=ClipRect->left-StartX;
						StartX=ClipRect->left;
					}
					if(StartX+Length>=ClipRect->right)
					{
						Length-=StartX+Length-ClipRect->right;
					}
					if(Length>0)memset(LinePtr+StartX,c,Length);
				}
				x+=a;
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					if(LineOk)
					{
						int StartX=x;
						int Length=a;
						int TempPos=pos;
						if(StartX<ClipRect->left)
						{
							TempPos+=ClipRect->left-StartX;
							Length-=ClipRect->left-StartX;
							StartX=ClipRect->left;
						}
						if(StartX+Length>=ClipRect->right)
						{
							Length-=StartX+Length-ClipRect->right;
						}
						for(int i=StartX;i<StartX+Length;i++)
						{
							unsigned char c=Surface[TempPos];
							if(c!=ColorKey)LinePtr[i]=c;
							TempPos++;
						}
					}
					pos+=a;
					x+=a;
					pos+=pos&1;
				}else if(a==0)
				{
					pos++;
					y--;
					x=Xpos;
					LinePtr-=dest->lPitch;
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
				}else if(a==2)
				{
					x+=Surface[pos+1];
					y-=Surface[pos+2];
					LinePtr-=Surface[pos+2]*dest->lPitch;
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
					pos+=3;
				}else done=true;
			}
		}while(!done);
	}else
	{
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				unsigned char c=Surface[pos+1];
				if(LineOk)
				{
					int StartX=x;
					int Length=a;
					if(StartX<ClipRect->left)
					{
						Length-=ClipRect->left-StartX;
						StartX=ClipRect->left;
					}
					if(StartX+Length>=ClipRect->right)
					{
						Length-=StartX+Length-ClipRect->right;
					}
					if(Length>0)memset(LinePtr+StartX,c,Length);
				}
				x+=a;
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					if(LineOk)
					{
						int StartX=x;
						int Length=a;
						int TempPos=pos;
						if(StartX<ClipRect->left)
						{
							TempPos+=ClipRect->left-StartX;
							Length-=ClipRect->left-StartX;
							StartX=ClipRect->left;
						}
						if(StartX+Length>=ClipRect->right)
						{
							Length-=StartX+Length-ClipRect->right;
						}
						for(int i=StartX;i<StartX+Length;i++)
						{
							unsigned char c=Surface[TempPos];
							LinePtr[i]=c;
							TempPos++;
						}
					}
					pos+=a;
					x+=a;
					pos+=pos&1;
				}else if(a==0)
				{
					pos++;
					y--;
					x=Xpos;
					LinePtr-=dest->lPitch;
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
				}else if(a==2)
				{
					x+=Surface[pos+1];
					y-=Surface[pos+2];
					LinePtr-=Surface[pos+2]*dest->lPitch;
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
					pos+=3;
				}else done=true;
			}
		}while(!done);
	}
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::Draw_16(NDX_Surface * dest, int Xpos, int Ypos)
{
	if(Xpos>=ClipRect->right)return NDXERR_OK;
	if(Ypos>=ClipRect->bottom)return NDXERR_OK;
	if(Xpos+Width<=ClipRect->left)return NDXERR_OK;
	if(Ypos+Height<=ClipRect->top)return NDXERR_OK;

	int pos=0,a,x=Xpos,y=Height-1;
	bool LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
	unsigned short *LinePtr=(unsigned short*)(char*)((char*)dest->lpSurface+(Ypos+y)*dest->lPitch);
	bool done=false;
	if(TransP)
	{
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				unsigned char c=Surface[pos+1];
				if(LineOk&&c!=ColorKey)
				{
					int StartX=x;
					int Length=a;
					if(StartX<ClipRect->left)
					{
						Length-=ClipRect->left-StartX;
						StartX=ClipRect->left;
					}
					if(StartX+Length>=ClipRect->right)
					{
						Length-=StartX+Length-ClipRect->right;
					}
					if(Length>0)
					{
						memsetw(LinePtr+StartX,WORD(Palette->LookUp[c]),Length);
					}
				}
				x+=a;
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					if(LineOk)
					{
						int StartX=x;
						int Length=a;
						int TempPos=pos;
						if(StartX<ClipRect->left)
						{
							TempPos+=ClipRect->left-StartX;
							Length-=ClipRect->left-StartX;
							StartX=ClipRect->left;
						}
						if(StartX+Length>=ClipRect->right)
						{
							Length-=StartX+Length-ClipRect->right;
						}
						for(int i=StartX;i<StartX+Length;i++)
						{
							unsigned char c=Surface[TempPos];
							if(c!=ColorKey)LinePtr[i]=WORD(Palette->LookUp[c]);
							TempPos++;
						}
					}
					pos+=a;
					x+=a;
					pos+=pos&1;
				}else if(a==0)
				{
					pos++;
					y--;
					x=Xpos;
					LinePtr=(unsigned short*)(char*)((char*)LinePtr-dest->lPitch);
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
				}else if(a==2)
				{
					x+=Surface[pos+1];
					y-=Surface[pos+2];
					LinePtr=(unsigned short*)(char*)((char*)LinePtr-Surface[pos+2]*dest->lPitch);
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
					pos+=3;
				}else done=true;
			}
		}while(!done);
	}else
	{
		do
		{
			a=Surface[pos];
			if(a>0)
			{
				unsigned char c=Surface[pos+1];
				if(LineOk)
				{
					int StartX=x;
					int Length=a;
					if(StartX<ClipRect->left)
					{
						Length-=ClipRect->left-StartX;
						StartX=ClipRect->left;
					}
					if(StartX+Length>=ClipRect->right)
					{
						Length-=StartX+Length-ClipRect->right;
					}
					if(Length>0)memsetw(LinePtr+StartX,WORD(Palette->LookUp[c]),Length);
				}
				x+=a;
				pos+=2;
			}
			else
			{
				pos++;
				a=Surface[pos];
				if(a>2)
				{
					pos++;
					if(LineOk)
					{
						int StartX=x;
						int Length=a;
						int TempPos=pos;
						if(StartX<ClipRect->left)
						{
							TempPos+=ClipRect->left-StartX;
							Length-=ClipRect->left-StartX;
							StartX=ClipRect->left;
						}
						if(StartX+Length>=ClipRect->right)
						{
							Length-=StartX+Length-ClipRect->right;
						}
						for(int i=StartX;i<StartX+Length;i++)
						{
							unsigned char c=Surface[TempPos];
							LinePtr[i]=WORD(Palette->LookUp[c]);
							TempPos++;
						}
					}
					pos+=a;
					x+=a;
					pos+=pos&1;
				}else if(a==0)
				{
					pos++;
					y--;
					x=Xpos;
					LinePtr=(unsigned short*)(char*)((char*)LinePtr-dest->lPitch);
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
				}else if(a==2)
				{
					x+=Surface[pos+1];
					y-=Surface[pos+2];
					LinePtr=(unsigned short*)(char*)((char*)LinePtr-Surface[pos+2]*dest->lPitch);
					LineOk=((y+Ypos)>=ClipRect->top&&(y+Ypos)<ClipRect->bottom);
					pos+=3;
				}else done=true;
			}
		}while(!done);
	}
	return NDXERR_OK;
}

NDXERR NDX_RLESurface::SetClip(LPRECT area)
{
	if(area!=NULL)
	{
		ClipRect=area;
	}
	return NDXERR_OK;
}
//
///EOF
