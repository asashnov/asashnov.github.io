//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Connect.cpp: implementation of the NDX_Connect class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Connect::NDX_Connect()
{
	CoInitialize(NULL);
	lpDP=NULL;
	NumConnections=0;
	NumGames=0;
	NumPlayers=0;
	PlayerStorage=0;
	GameStorage=0;
	RBufferSize=0;
	MessageSize=0;
	RBuffer=NULL;
	ConnectionData=NULL;
	Connections=NULL;
	Players=NULL;
	Games=NULL;
	PSEHandle=0;
	GSEHandle=0;
	SetGuarenteed(false);
}

NDX_Connect::~NDX_Connect()
{
	RemoveGameScanEvent();
	RemovePlayerScanEvent();
	CloseConnection();
	CoUninitialize();
}

bool WINAPI EnumConnection_Count(LPCGUID lpguidSP,LPVOID lpConnection,DWORD dwConnectionSize,LPCDPNAME lpName,DWORD dwFlags,LPVOID lpContext)
{
	*(int*)((int*)lpContext)+=1;
	return true;
}

bool WINAPI EnumConnection(LPCGUID lpguidSP,LPVOID lpConnection,DWORD dwConnectionSize,LPCDPNAME lpName,DWORD dwFlags,LPVOID lpContext)
{
	NDX_Connect *TC=(NDX_Connect*)lpContext;
	LPDIRECTPLAY4 tlpDP;
	if(FAILED(CoCreateInstance(CLSID_DirectPlay,NULL,CLSCTX_ALL,IID_IDirectPlay4A,(LPVOID*)&tlpDP)))return false;
	if(FAILED(tlpDP->InitializeConnection(lpConnection,0)))
	{
		tlpDP->Release();
		return true;
	}
	tlpDP->Release();
	// Save connection name
	strcpy(TC->Connections[TC->NumConnections].Name,lpName->lpszShortNameA);

	// Save connection GUID
	TC->Connections[TC->NumConnections].guid=*lpguidSP;

	// Save connection data
	TC->Connections[TC->NumConnections].data=malloc(dwConnectionSize);
	memcpy(TC->Connections[TC->NumConnections].data,lpConnection,dwConnectionSize);

	// Increase connection amount
	TC->NumConnections++;
	return true;
}

bool WINAPI EnumSession_Count(LPDPSESSIONDESC2 lpDPGameDesc,LPDWORD lpdwTimeOut,DWORD dwFlags,LPVOID lpContext)
{
	if(dwFlags&DPESC_TIMEDOUT)return false;
	*(int*)((int*)lpContext)+=1;
	return true;
}

bool WINAPI EnumSession(LPDPSESSIONDESC2 lpDPGameDesc,LPDWORD lpdwTimeOut,DWORD dwFlags,LPVOID lpContext)
{
	NDX_Connect *TC=(NDX_Connect*)lpContext;
	if(dwFlags&DPESC_TIMEDOUT)return false;
	if(TC->NumGames<TC->GameStorage)
	{
		strcpy(TC->Games[TC->NumGames].Name,(LPSTR)lpDPGameDesc->lpszSessionNameA);
		TC->Games[TC->NumGames].guid=lpDPGameDesc->guidInstance;
		TC->NumGames++;
	}
	return true;
}

bool WINAPI EnumPlayers_Count(DPID pidID,DWORD dwPlayerType,LPCDPNAME lpName,DWORD dwFlags,LPVOID lpContext)
{
	*(int*)((int*)lpContext)+=1;
	return true;
}

bool WINAPI EnumPlayers(DPID pidID,DWORD dwPlayerType,LPCDPNAME lpName,DWORD dwFlags,LPVOID lpContext)
{
	NDX_Connect *TC=(NDX_Connect*)lpContext;
	if(TC->NumPlayers<TC->PlayerStorage)
	{
		strcpy(TC->Players[TC->NumPlayers].Name,lpName->lpszShortNameA);
		TC->Players[TC->NumPlayers].dpid=pidID;
		TC->NumPlayers++;
	}
	return true;
}

bool NDX_Connect::Create(LPGUID g)
{
	guid=g;
	if(lpDP!=NULL)CloseConnection();
	if(FAILED(CoCreateInstance( CLSID_DirectPlay,NULL,CLSCTX_ALL,IID_IDirectPlay4A,(LPVOID*)&lpDP)))return false;
	int Count=0;
	if(FAILED(lpDP->EnumConnections(guid,(LPDPENUMCONNECTIONSCALLBACK)EnumConnection_Count,&Count,0)))return false;
	NumConnections=0;
	Connections=(NetConnection*)malloc(sizeof(NetConnection)*Count);
	if(FAILED(lpDP->EnumConnections(guid,(LPDPENUMCONNECTIONSCALLBACK)EnumConnection,this,0)))return false;
	return true;
}

bool NDX_Connect::ScanForGames(int TimeOut,bool Async)
{
	DWORD ASYNC=Async?DPENUMSESSIONS_ASYNC:0;
	DPSESSIONDESC2 dpdesc;
	ZeroMemory(&dpdesc,sizeof(dpdesc));
	dpdesc.dwSize=sizeof(dpdesc);
	dpdesc.guidApplication=*guid;
	int Count=0;
	if(FAILED(lpDP->EnumSessions(&dpdesc,TimeOut,(LPDPENUMSESSIONSCALLBACK2)EnumSession_Count,&Count,ASYNC|DPENUMSESSIONS_AVAILABLE)))return false;
	if(Count!=NumGames)
	{
		FREE(Games);
		Games=(NetGame*)malloc(sizeof(NetGame)*Count);
		GameStorage=Count;
	}
	NumGames=0;
	if(FAILED(lpDP->EnumSessions(&dpdesc,TimeOut,(LPDPENUMSESSIONSCALLBACK2)EnumSession,this,ASYNC|DPENUMSESSIONS_AVAILABLE)))return false;
	return true;
}


bool NDX_Connect::JoinGame(int GameNumber,LPSTR PlayerName)
{
	DPSESSIONDESC2 dpdesc;
	DPNAME dpName;
	ZeroMemory(&dpdesc,sizeof(dpdesc));
	dpdesc.dwSize=sizeof(dpdesc);
	dpdesc.guidInstance=Games[GameNumber].guid;
	dpdesc.dwFlags=0;
	if(FAILED(lpDP->Open(&dpdesc,DPOPEN_JOIN)))return false;
	ZeroMemory(&dpName,sizeof(dpName));
	dpName.dwSize=sizeof(dpName);
	dpName.lpszShortNameA=PlayerName;
	if(FAILED(lpDP->CreatePlayer(&LocalDPID,&dpName,NULL,NULL,0,0)))return false;
	return true;
}

bool NDX_Connect::CreateGame(LPSTR Name,LPSTR PlayerName,int MaxPlayers)
{
	DPSESSIONDESC2 dpdesc;
	DPNAME dpName;
	ZeroMemory(&dpdesc,sizeof(dpdesc));
	dpdesc.dwSize=sizeof(dpdesc);
	dpdesc.guidApplication=*guid;
	dpdesc.dwFlags=DPSESSION_MIGRATEHOST|DPSESSION_KEEPALIVE;
	dpdesc.lpszSessionNameA=Name;
	dpdesc.dwMaxPlayers=MaxPlayers;
	if(FAILED(lpDP->Open(&dpdesc,DPOPEN_CREATE)))return false;
	ZeroMemory(&dpName,sizeof(dpName));
	dpName.dwSize=sizeof(dpName);
	dpName.lpszShortNameA=PlayerName;
	if(FAILED(lpDP->CreatePlayer(&LocalDPID,&dpName,NULL,NULL,0,DPPLAYER_SERVERPLAYER)))return false;
	MaxPlrs=MaxPlayers;
	return true;
}

bool NDX_Connect::Connect(int CNum)
{
	if(FAILED(lpDP->InitializeConnection(Connections[CNum].data,0)))return false;
	return true;
}

bool NDX_Connect::ScanForPlayers()
{
	int Count=0;
	if(FAILED(lpDP->EnumPlayers(NULL,(LPDPENUMPLAYERSCALLBACK2)EnumPlayers_Count,&Count,DPENUMPLAYERS_ALL)))return false;
	if(Count!=NumPlayers)
	{
		FREE(Players);
		Players=(NetPlayer*)malloc(sizeof(NetPlayer)*Count);
		PlayerStorage=Count;
	}
	NumPlayers=0;
	if(FAILED(lpDP->EnumPlayers(NULL,(LPDPENUMPLAYERSCALLBACK2)EnumPlayers,this,DPENUMPLAYERS_ALL)))return false;
	return true;
}

bool NDX_Connect::Send(DPID To,LPVOID Data,DWORD DataSize)
{
	if(lpDP->Send(LocalDPID,To,GUARANTEED,Data,DataSize)!=DP_OK)return false;
	return true;
}

bool NDX_Connect::Receive(void * Data,DWORD *DataSize)
{
	if(lpDP->Receive(&FromDPID,&ToDPID,DPRECEIVE_ALL,Data,DataSize)!=DP_OK)return false;
	return true;
}

bool NDX_Connect::CloseGame()
{
	if(FAILED(lpDP->DestroyPlayer(LocalDPID)))return false;
	if(FAILED(lpDP->Close()))return false;
	return true;
}

bool NDX_Connect::Receive()
{
	DWORD nBytes;
	HRESULT dprval;
	Again:;
	nBytes=RBufferSize;
	dprval=lpDP->Receive(&FromDPID,&ToDPID,DPRECEIVE_ALL,RBuffer,&nBytes);
	if(dprval==DPERR_BUFFERTOOSMALL)
	{
		if(RBuffer!=NULL)free(RBuffer);
		RBuffer=malloc(nBytes);
		RBufferSize=nBytes;
		goto Again;
	}
	MessageSize=nBytes;
	if(dprval!=DP_OK)return false;
	return true;
}

bool NDX_Connect::Send(DPID To,NetMessage *Message)
{
	void *data=malloc(Message->DataSize+4);
	if(data==NULL)return false;
	memcpy(data,&Message->dwType,4);
	if(Message->Data!=NULL)memcpy((DWORD*)data+1,Message->Data,Message->DataSize);
	if(lpDP->Send(LocalDPID,To,GUARANTEED,data,Message->DataSize+4)!=DP_OK)
	{
		free(data);
		return false;
	}
	free(data);
	return true;
}

bool NDX_Connect::Send(DPID To,DWORD dwType)
{
	if(lpDP->Send(LocalDPID,To,GUARANTEED,&dwType,4)!=DP_OK)return false;
	return true;
}

bool NDX_Connect::HideGame()
{
	DWORD DataSize;
	void *Data;
	DPSESSIONDESC2 dpdesc;
	ZeroMemory(&dpdesc,sizeof(dpdesc));
	lpDP->GetSessionDesc(NULL,&DataSize);
	Data=malloc(DataSize);
	lpDP->GetSessionDesc(Data,&DataSize);
	memcpy(&dpdesc,Data,sizeof(dpdesc));
	free(Data);
	dpdesc.dwSize=sizeof(dpdesc);
	dpdesc.dwFlags|=DPSESSION_JOINDISABLED;
	if(lpDP->SetSessionDesc(&dpdesc,0)!=DP_OK)return false;
	return true;
}

int NDX_Connect::FindSPGUID(GUID spguid)
{
	for(int n=0;n<NumConnections;n++)
	{
		if(Connections[n].guid==spguid)return n;
	}
	return -1;
}

bool NDX_Connect::ConnectIPX()
{
	LPDIRECTPLAYLOBBY3A lpDPL;
	DPCOMPOUNDADDRESSELEMENT CElement;
	DWORD AddressSize;
	if(FAILED(CoCreateInstance(CLSID_DirectPlayLobby,NULL,CLSCTX_ALL,IID_IDirectPlayLobby3A,(LPVOID*)&lpDPL)))return false;

	CElement.guidDataType=DPAID_ServiceProvider;
	CElement.dwDataSize=sizeof(GUID);
	CElement.lpData=(LPVOID)&DPSPGUID_IPX;

	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,1,NULL,&AddressSize);
	FREE(ConnectionData);
	ConnectionData=malloc(AddressSize);
	if(ConnectionData==NULL)
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,1,ConnectionData,&AddressSize);
	if(FAILED(lpDP->InitializeConnection(ConnectionData,0)))
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->Release();
	return true;
}

bool NDX_Connect::ConnectTCPIP(char * IPAddress)
{
	LPDIRECTPLAYLOBBY3A lpDPL;
	DPCOMPOUNDADDRESSELEMENT CElement[2];
	DWORD AddressSize;
	if(FAILED(CoCreateInstance(CLSID_DirectPlayLobby,NULL,CLSCTX_ALL,IID_IDirectPlayLobby3A,(LPVOID*)&lpDPL)))return false;

	CElement[0].guidDataType=DPAID_ServiceProvider;
	CElement[0].dwDataSize=sizeof(GUID);
	CElement[0].lpData=(LPVOID)&DPSPGUID_TCPIP;
	CElement[1].guidDataType=DPAID_INet;
	CElement[1].dwDataSize=strlen(IPAddress)+1;
	CElement[1].lpData=IPAddress;

	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,2,NULL,&AddressSize);
	FREE(ConnectionData);
	ConnectionData=malloc(AddressSize);
	if(ConnectionData==NULL)
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,2,ConnectionData,&AddressSize);
	if(FAILED(lpDP->InitializeConnection(ConnectionData,0)))
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->Release();
	return true;
}

bool NDX_Connect::ConnectMODEM(char * Phone,char * Modem)
{
	LPDIRECTPLAYLOBBY3A lpDPL;
	DPCOMPOUNDADDRESSELEMENT CElement[3];
	DWORD AddressSize;
	if(FAILED(CoCreateInstance(CLSID_DirectPlayLobby,NULL,CLSCTX_ALL,IID_IDirectPlayLobby3A,(LPVOID*)&lpDPL)))return false;

	CElement[0].guidDataType=DPAID_ServiceProvider;
	CElement[0].dwDataSize=sizeof(GUID);
	CElement[0].lpData=(LPVOID)&DPSPGUID_IPX;
	CElement[1].guidDataType=DPAID_Phone;
	CElement[1].dwDataSize=strlen(Phone)+1;
	CElement[1].lpData=Phone;
	CElement[2].guidDataType=DPAID_Modem;
	CElement[2].dwDataSize=strlen(Modem)+1;
	CElement[2].lpData=Modem;

	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,3,NULL,&AddressSize);
	ConnectionData=malloc(AddressSize);
	if(ConnectionData==NULL)
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,3,ConnectionData,&AddressSize);
	if(FAILED(lpDP->InitializeConnection(ConnectionData,0)))
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->Release();
	return true;
}

bool NDX_Connect::CloseConnection()
{
	for(int n=0;n<NumConnections;n++)
	{
		free(Connections[n].data);
	}
	FREE(Connections);
	FREE(Games);
	FREE(Players);
	FREE(ConnectionData);
	FREE(RBuffer);
	RELEASE(lpDP);
	return true;
}

bool NDX_Connect::ConnectSERIAL(DWORD ComPort,DWORD BaudRate)
{
	LPDIRECTPLAYLOBBY3A lpDPL;
	DPCOMPOUNDADDRESSELEMENT CElement[2];
	DPCOMPORTADDRESS ComPortAddress;
	DWORD AddressSize;
	if(FAILED(CoCreateInstance(CLSID_DirectPlayLobby,NULL,CLSCTX_ALL,IID_IDirectPlayLobby3A,(LPVOID*)&lpDPL)))return false;

	ComPortAddress.dwComPort=ComPort;
	ComPortAddress.dwBaudRate=BaudRate;
	ComPortAddress.dwStopBits=ONESTOPBIT;
	ComPortAddress.dwParity=NOPARITY;
	ComPortAddress.dwFlowControl=DPCPA_RTSFLOW;

	CElement[0].guidDataType=DPAID_ServiceProvider;
	CElement[0].dwDataSize=sizeof(GUID);
	CElement[0].lpData=(LPVOID)&DPSPGUID_SERIAL;
	CElement[1].guidDataType=DPAID_ComPort;
	CElement[1].dwDataSize=sizeof(ComPortAddress);
	CElement[1].lpData=&ComPortAddress;

	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,2,NULL,&AddressSize);
	ConnectionData=malloc(AddressSize);
	if(ConnectionData==NULL)
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->CreateCompoundAddress((DPCOMPOUNDADDRESSELEMENT*)&CElement,2,ConnectionData,&AddressSize);
	if(FAILED(lpDP->InitializeConnection(ConnectionData,0)))
	{
		lpDPL->Release();
		return false;
	}
	lpDPL->Release();
	return true;
}

int NDX_Connect::GetMessageCount()
{
	DWORD MessageCount;
	lpDP->GetMessageCount(LocalDPID,&MessageCount);
	return MessageCount;
}

void CALLBACK PlayerScanEvent(UINT uID,UINT uMsg,void *dwUser,DWORD dw1,DWORD dw2)
{
	NDX_Connect *TC=(NDX_Connect*)dwUser;
	TC->ScanForPlayers();
}

NDXERR NDX_Connect::SetPlayerScanEvent(int MiliSec)
{
	PSEHandle=timeSetEvent(MiliSec,0,(LPTIMECALLBACK)PlayerScanEvent,(DWORD)this,TIME_PERIODIC);
	if(PSEHandle)return NDXERR_OK;
	return NDXERR_EVENT;
}

void CALLBACK GameScanEvent(UINT uID,UINT uMsg,void *dwUser,DWORD dw1,DWORD dw2)
{
	NDX_Connect *TC=(NDX_Connect*)dwUser;
	TC->ScanForGames(0,true);
}

NDXERR NDX_Connect::SetGameScanEvent(int MiliSec)
{
	GSEHandle=timeSetEvent(MiliSec,0,(LPTIMECALLBACK)GameScanEvent,(DWORD)this,TIME_PERIODIC);
	if(GSEHandle)return NDXERR_OK;
	return NDXERR_EVENT;
}

NDXERR NDX_Connect::RemovePlayerScanEvent()
{
	if(PSEHandle)timeKillEvent(PSEHandle);
	PSEHandle=0;
	return NDXERR_OK;
}

NDXERR NDX_Connect::RemoveGameScanEvent()
{
	if(GSEHandle)timeKillEvent(GSEHandle);
	GSEHandle=0;
	return NDXERR_OK;
}

void NDX_Connect::SetGuarenteed(bool OnOff)
{
	if(OnOff)GUARANTEED=DPSEND_GUARANTEED;else GUARANTEED=0;
}

//
///EOF
