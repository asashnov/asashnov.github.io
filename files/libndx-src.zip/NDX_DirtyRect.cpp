//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_DirtyRect.cpp: implementation of the NDX_DirtyRect class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_DirtyRect::NDX_DirtyRect()
{
	Reset();
	MaxRects=0;
	DirtyRects=(LPRECT)malloc(sizeof(RECT)*MaxRects);
	SetBorder(NDX_RECT(0,0,0,0));
}

NDX_DirtyRect::~NDX_DirtyRect()
{
	FREE(DirtyRects);
}

void NDX_DirtyRect::AddRect(RECT area)
{
	if(WholeScreen)return;
	if(area.right<0)return;
	if(area.bottom<0)return;
	if(area.left>=Border.right)return;
	if(area.top>=Border.bottom)return;
	if(area.left<0)area.left=0;
	if(area.top<0)area.top=0;
	if(area.right>Border.right)area.right=Border.right;
	if(area.bottom>Border.bottom)area.bottom=Border.bottom;
	if(NumRects==MaxRects)
	{
		MaxRects++;
		DirtyRects=(LPRECT)realloc(DirtyRects,sizeof(RECT)*MaxRects);
	}
	DirtyRects[NumRects]=area;
	NumRects++;
}

void NDX_DirtyRect::Reset()
{
	NumRects=0;
	WholeScreen=false;
}

void NDX_DirtyRect::SelectRect(int n)
{
	ClipRect=DirtyRects[n];
}

void NDX_DirtyRect::AddWholeScreen()
{
	if(WholeScreen)return;
	WholeScreen=true;
	NumRects=1;
	DirtyRects[0]=Border;
}

void NDX_DirtyRect::Merge()
{
	int n;
	goAgain:
	for(n=0;n<NumRects;n++)
	for(int n2=0;n2<NumRects;n2++)
	{
		if(n!=n2)
		{
			RECT a1=DirtyRects[n];
			RECT a2=DirtyRects[n2];
			bool RectMod=false;
			if(a1.left>=a2.left&&a1.top>=a2.top&&a1.right<=a2.right&&a1.bottom<=a2.bottom)
			{
				DeleteRect(n);
				goto goAgain;
			}
			int oa=OverlapArea(a1,a2);
			if(oa>0&&oa>((a1.right-a1.left)*(a1.bottom-a1.top))>>5&&oa>((a2.right-a2.left)*(a2.bottom-a2.top))>>5)
			{
				RECT r;
				if(a1.left<a2.left)r.left=a1.left;else r.left=a2.left;
				if(a1.top<a2.top)r.top=a1.top;else r.top=a2.top;
				if(a1.right>a2.right)r.right=a1.right;else r.right=a2.right;
				if(a1.bottom>a2.bottom)r.bottom=a1.bottom;else r.bottom=a2.bottom;
				DirtyRects[n2]=r;
				DeleteRect(n);
				goto goAgain;
			}
			if(a1.top>=a2.top&&a1.bottom<=a2.bottom)
			{
				if(a1.left>a2.left&&a1.left<a2.right&&a1.right>a2.right)
				{
					a1.left=a2.right;
					RectMod=true;
				}
				if(a1.right>a2.left&&a1.right<a2.right&&a1.left<a2.left)
				{
					a1.right=a2.left;
					RectMod=true;
				}
			}
			if(a1.left>=a2.left&&a1.right<=a2.right)
			{
				if(a1.top>a2.top&&a1.top<a2.bottom&&a1.bottom>a2.bottom)
				{
					a1.top=a2.bottom;
					RectMod=true;
				}
				if(a1.bottom>a2.top&&a1.bottom<a2.bottom&&a1.top<a2.top)
				{
					a1.bottom=a2.top;
					RectMod=true;
				}
			}
			if(RectMod)
			{
				DirtyRects[n]=a1;
				goto goAgain;
			}
		}
	}
}

void NDX_DirtyRect::DeleteRect(int n)
{
	NumRects--;
	if(NumRects>0)DirtyRects[n]=DirtyRects[NumRects];
}

int NDX_DirtyRect::OverlapArea(RECT &a1, RECT &a2)
{
	RECT r;
	if(a1.left>a2.right||a1.right<a2.left||a1.top>a2.bottom||a1.bottom<a2.top)return 0;
	if(a1.left<a2.left)r.left=a2.left;else r.left=a1.left;
	if(a1.top<a2.top)r.top=a2.top;else r.top=a1.top;
	if(a1.right>a2.right)r.right=a2.right;else r.right=a1.right;
	if(a1.bottom>a2.bottom)r.bottom=a2.bottom;else r.bottom=a1.bottom;
	return (r.right-r.left)*(r.bottom-r.top);
}

void NDX_DirtyRect::SetBorder(RECT area)
{
	Border=area;
}

void NDX_DirtyRect::AssignSurface(NDX_Surface * Surface)
{
	Surface->ClipRect=&ClipRect;
}

void NDX_DirtyRect::SetBorder(NDX_Surface * s)
{
	SetBorder(NDX_RECT(0,0,s->Width,s->Height));
}

//
///EOF
