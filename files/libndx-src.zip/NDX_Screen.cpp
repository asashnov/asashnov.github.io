//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Screen.cpp: implementation of the NDX_Screen class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Screen::NDX_Screen()
{
	lpDD=NULL;
	Primary=NULL;
	Back=NULL;
	PixelFormat=NULL;
	Palette=NULL;
	Surfaces=NULL;
	Clipper=NULL;
	LastShowFPS=0;
	FrameCount=0;
	DisplayModes=NULL;
	NumDisplayModes=0;
	EnumDrivers();
	lefttable=NULL;
	righttable=NULL;
	TaxMapTableHeight=0;
}

NDX_Screen::~NDX_Screen()
{
	if(!SysmemBack&&Back!=NULL)Back->Surface=NULL;
	if(Surfaces!=NULL)
	{
		Surfaces->ReleaseAll();
		DEL(Surfaces);
	}
	DEL(Palette);
	DEL(PixelFormat);
	DEL(Primary);
	DEL(Back);
	FREE(DisplayModes);
	RELEASE(Clipper);
	RELEASE(lpDD);
	for(int n=0;n<NumDrivers;n++)
	{
		free(Drivers[n].Name);
		free(Drivers[n].Desc);
	}
	FREE(Drivers);
	FREE(lefttable);
	FREE(righttable);
}

NDXERR NDX_Screen::SetFullScreen(DWORD Flags,HWND hwnd,int Width,int Height,int Depth)
{
	DisplayFlags=Flags;
	if(!SysmemBack&&Back!=NULL)Back->Surface=NULL;
	if(Surfaces!=NULL)
	{
		Surfaces->ReleaseAll();
		DEL(Surfaces);
	}
	DEL(Palette);
	DEL(PixelFormat);
	DEL(Primary);
	DEL(Back);
	RELEASE(Clipper);

	Hwnd=hwnd;Windowed=false;
	Primary=new NDX_Surface;
	Back=new NDX_Surface;
	Palette=new NDX_Palette;
	PixelFormat=new NDX_PixelFormat;
	Surfaces=new NDX_SurfaceList;
	DDSURFACEDESC2 ddsd;
	DDSCAPS2 ddscaps;
	if(FAILED(lpDD->SetCooperativeLevel(hwnd,DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN|((Flags&NDXDF_ALLOWREBOOT)?DDSCL_ALLOWREBOOT:0))))return NDXERR_SETCOORPLEVEL;
	if(FAILED(lpDD->SetDisplayMode(Width,Height,Depth,0,0)))return NDXERR_SETDISPMODE;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);

	SysmemBack=false;
	if(Flags&NDXDF_NOBACK)
	{
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
	}else if(Flags&NDXDF_SYSMEMBACK)
	{
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
		if(Flags&NDXDF_D3D)Back->Create(this,NDXST_SYSMEM|NDXST_D3D,Width,Height);
		else Back->Create(this,NDXST_SYSMEM,Width,Height);
		Back->Clear(0);
		Surfaces->AddSurface(Back);
		SysmemBack=true;
	}else
	{
		ddsd.dwFlags=DDSD_CAPS|DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE|DDSCAPS_FLIP|DDSCAPS_COMPLEX;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		ddsd.dwBackBufferCount=1;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
		ddscaps.dwCaps=DDSCAPS_BACKBUFFER;
		if(Flags&NDXDF_D3D)ddscaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(Primary->Surface->GetAttachedSurface(&ddscaps,&Back->Surface)))return NDXERR_BACKSURFACE;
		Back->Width=Width;
		Back->Height=Height;
		Back->SetClip(&ClipRect);
		Back->Clear(0);
		Back->Screen=this;
		Surfaces->AddSurface(Back);
	}
	Primary->Width=Width;
	Primary->Height=Height;
	Primary->SetClip(&ClipRect);
	Primary->Clear(0);
	Primary->Screen=this;
	Surfaces->AddSurface(Primary);
	PixelFormat->Create(Primary);
	Back->Palette=Palette;
	Primary->Palette=Palette;
	ClipRect=NDX_RECT(0,0,Width,Height);
	return NDXERR_OK;
}

NDXERR NDX_Screen::SetWindowed(DWORD Flags,HWND hwnd,int Width,int Height)
{
	Hwnd=hwnd;Windowed=true;
	DDSURFACEDESC2 ddsd;
	Primary=new NDX_Surface;
	Back=new NDX_Surface;
	Surfaces=new NDX_SurfaceList;
	PixelFormat=new NDX_PixelFormat;
	if(FAILED(lpDD->SetCooperativeLevel(hwnd,DDSCL_NORMAL)))return NDXERR_SETCOORPLEVEL;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS;
	ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
	if(FAILED(lpDD->CreateSurface(&ddsd, &Primary->Surface, NULL)))return NDXERR_PRIMSURFACE;

	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	lpDD->GetDisplayMode(&ddsd);
	Primary->Width=WORD(ddsd.dwWidth);
	Primary->Height=WORD(ddsd.dwHeight);
	Primary->SetClip(&ClipRect);
	Primary->Screen=this;
	PixelFormat->Create(Primary);
	Palette=new NDX_Palette;
	Surfaces->AddSurface(Primary);
	ClipRect=NDX_RECT(0,0,Width,Height);

	DWORD SurfaceType=NDXST_BESTFIT;
	if(Flags&NDXDF_SYSMEMBACK)SurfaceType=NDXST_SYSMEM;
	Back->Create(this,SurfaceType,Width,Height);

	if(FAILED(lpDD->CreateClipper(0,&Clipper,NULL)))return NDXERR_CCLIP;
	if(FAILED(Clipper->SetHWnd(0,hwnd)))return NDXERR_CCLIP;
	if(FAILED(Primary->Surface->SetClipper(Clipper)))return NDXERR_CCLIP;
	return NDXERR_OK;
}

NDXERR NDX_Screen::Create()
{
	return Create(NULL);
}

NDXERR NDX_Screen::Create(LPGUID guid)
{
	LPDIRECTDRAW lpTempDD;
	if(FAILED(DirectDrawCreate(guid,&lpTempDD,NULL)))return NDXERR_CREATEDDRAW;
	if(FAILED(lpTempDD->QueryInterface(IID_IDirectDraw4,(void**)&lpDD)))return NDXERR_CREATEDDRAW;
	lpTempDD->Release();
	//EnumDispModes();
	return NDXERR_OK;
}

HRESULT WINAPI EnumModesCallback_Count(LPDDSURFACEDESC2 lpDDSurfaceDesc,LPVOID lpContext)
{
	NDX_Screen *Screen=(NDX_Screen*)lpContext;
	Screen->NumDisplayModes++;
	return DDENUMRET_OK;
}

HRESULT WINAPI EnumModesCallback(LPDDSURFACEDESC2 lpDDSurfaceDesc,LPVOID lpContext)
{
	NDX_Screen *Screen=(NDX_Screen*)lpContext;
	Screen->DisplayModes[Screen->NumDisplayModes].Width=lpDDSurfaceDesc->dwWidth;
	Screen->DisplayModes[Screen->NumDisplayModes].Height=lpDDSurfaceDesc->dwHeight;
	Screen->DisplayModes[Screen->NumDisplayModes].Depth=lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount;
	LPSTR String=(LPSTR)&Screen->DisplayModes[Screen->NumDisplayModes].Description;
	sprintf(String,"%i x %i x %i",lpDDSurfaceDesc->dwWidth,lpDDSurfaceDesc->dwHeight,lpDDSurfaceDesc->ddpfPixelFormat.dwRGBBitCount);
	Screen->NumDisplayModes++;
	return DDENUMRET_OK;
}

void NDX_Screen::EnumDispModes()
{
	NumDisplayModes=0;
	lpDD->EnumDisplayModes(DDEDM_STANDARDVGAMODES,NULL,this,EnumModesCallback_Count);
	FREE(DisplayModes);
	DisplayModes=(DisplayMode*)malloc(sizeof(DisplayMode)*NumDisplayModes);
	NumDisplayModes=0;
	lpDD->EnumDisplayModes(DDEDM_STANDARDVGAMODES,NULL,this,EnumModesCallback);
}

void NDX_Screen::ShowFPS(NDX_Surface * dest, int Xpos, int Ypos)
{
	char tmpStr[255];
	strcpy(tmpStr,"FPS=");
	char fpsStr[255];
	DWORD ThisTick=timeGetTime();
	if(ThisTick-LastShowFPS>1000)
	{
		FPS=(double)FrameCount*1000/(ThisTick-LastShowFPS);
		LastShowFPS=ThisTick;
		FrameCount=0;
	}
	_gcvt(FPS,4,fpsStr);
	strcat(tmpStr,fpsStr);
	dest->Text(tmpStr,Xpos,Ypos,RGB(255,255,255),RGB(0,0,0),NULL);
	FrameCount++;
}

void NDX_Screen::WaitVBlank()
{
	lpDD->WaitForVerticalBlank(DDWAITVB_BLOCKEND,0);
}

NDXERR NDX_Screen::ChangeRes(int Width, int Height)
{
	DWORD Flags=DisplayFlags;
	if(!SysmemBack&&Back!=NULL)Back->Surface=NULL;
	DEL(Primary);
	DEL(Back);
	Primary=new NDX_Surface;
	Back=new NDX_Surface;
	DDSURFACEDESC2 ddsd;
	DDSCAPS2 ddscaps;
	if(FAILED(lpDD->SetDisplayMode(Width,Height,PixelFormat->BitCount,0,0)))return NDXERR_SETDISPMODE;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);

	SysmemBack=false;
	if(Flags&NDXDF_NOBACK)
	{
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
	}else if(Flags&NDXDF_SYSMEMBACK)
	{
		ddsd.dwFlags=DDSD_CAPS;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
		if(Flags&NDXDF_D3D)Back->Create(this,NDXST_SYSMEM|NDXST_D3D,Width,Height);
		else Back->Create(this,NDXST_SYSMEM,Width,Height);
		Back->Clear(0);
		Surfaces->AddSurface(Back);
		SysmemBack=true;
	}else
	{
		ddsd.dwFlags=DDSD_CAPS|DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE|DDSCAPS_FLIP|DDSCAPS_COMPLEX;
		if(Flags&NDXDF_D3D)ddsd.ddsCaps.dwCaps|=DDSCAPS_3DDEVICE;
		ddsd.dwBackBufferCount=1;
		if(FAILED(lpDD->CreateSurface(&ddsd,&Primary->Surface,NULL)))return NDXERR_PRIMSURFACE;
		ddscaps.dwCaps=DDSCAPS_BACKBUFFER;
		if(Flags&NDXDF_D3D)ddscaps.dwCaps|=DDSCAPS_3DDEVICE;
		if(FAILED(Primary->Surface->GetAttachedSurface(&ddscaps,&Back->Surface)))return NDXERR_BACKSURFACE;
		Back->Width=Width;
		Back->Height=Height;
		Back->SetClip(&ClipRect);
		Back->Clear(0);
		Back->Screen=this;
		Surfaces->AddSurface(Back);
	}
	Primary->Width=Width;
	Primary->Height=Height;
	Primary->SetClip(&ClipRect);
	Primary->Clear(0);
	Primary->Screen=this;
	Surfaces->AddSurface(Primary);
	ClipRect=NDX_RECT(0,0,Width,Height);
	if(Palette->ddpal!=NULL)
	{
		Palette->UpdateColors();
		Palette->SetPalette();
	}
	return NDXERR_OK;
}

bool NDX_Screen::CheckDisplayMode(int Width, int Height, int Depth)
{
	if(NumDisplayModes==0)EnumDispModes();
	for(int n=0;n<NumDisplayModes;n++)
	{
		if(DisplayModes[n].Width==Width&&DisplayModes[n].Height==Height&&DisplayModes[n].Depth==Depth)return true;
	}
	return false;
}

NDXERR NDX_Screen::SetHidden(DWORD Flags,HWND hwnd,int Depth)
{
	DisplayFlags=Flags;
	if(!SysmemBack&&Back!=NULL)Back->Surface=NULL;
	if(Surfaces!=NULL)
	{
		Surfaces->ReleaseAll();
		DEL(Surfaces);
	}
	DEL(Palette);
	DEL(PixelFormat);
	DEL(Primary);
	DEL(Back);
	RELEASE(Clipper);

	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	lpDD->GetDisplayMode(&ddsd);
	int Width=ddsd.dwWidth;
	int Height=ddsd.dwHeight;

	Hwnd=hwnd;Windowed=false;
	Primary=new NDX_Surface;
	Back=new NDX_Surface;
	Palette=new NDX_Palette;
	PixelFormat=new NDX_PixelFormat;
	Surfaces=new NDX_SurfaceList;
	ClipRect=NDX_RECT(0,0,Width,Height);
	return NDXERR_OK;
}

BOOL WINAPI NDX_DDEnumCallback(GUID FAR *lpGUID,LPSTR lpDriverDescription,LPSTR lpDriverName,LPVOID lpContext)
{
	NDX_Screen *Scr=(NDX_Screen*)lpContext;
	Scr->Drivers=(NDX_Screen::DDriver*)realloc(Scr->Drivers,(Scr->NumDrivers+1)*sizeof(NDX_Screen::DDriver));
	Scr->Drivers[Scr->NumDrivers].lpGuid=lpGUID;
	Scr->Drivers[Scr->NumDrivers].Desc=(LPSTR)malloc(strlen(lpDriverDescription)+1);
	Scr->Drivers[Scr->NumDrivers].Name=(LPSTR)malloc(strlen(lpDriverName)+1);
	strcpy(Scr->Drivers[Scr->NumDrivers].Desc,lpDriverDescription);
	strcpy(Scr->Drivers[Scr->NumDrivers].Name,lpDriverName);
	Scr->NumDrivers++;
	return true;
}

void NDX_Screen::EnumDrivers()
{
	NumDrivers=0;
	Drivers=(DDriver*)malloc(0);
	DirectDrawEnumerate(NDX_DDEnumCallback,this);
}

NDXERR NDX_Screen::Flip(DWORD Flags)
{
	HRESULT rval;
	if(Back==NULL)return NDXERR_NOBACK;

	if(Windowed)
	{
		POINT WinPos;
		WinPos.x=0;
		WinPos.y=0;
		RECT DestArea;
		RECT SourceArea={0,0,Back->Width,Back->Height};
		if(Flags&NDXFF_STRETCH)
			GetClientRect(Hwnd, &DestArea);
		else
			DestArea=SourceArea;
		ClientToScreen(Hwnd, &WinPos);
		DestArea.left+=WinPos.x;
		DestArea.right+=WinPos.x;
		DestArea.top+=WinPos.y;
		DestArea.bottom+=WinPos.y;
		rval=Primary->Surface->Blt(&DestArea,Back->Surface,&SourceArea,DDBLT_WAIT,NULL);
		if(rval==DDERR_SURFACELOST)
		{
			Back->Restore();
			Primary->Restore();
			rval=Primary->Surface->Blt(&DestArea,Back->Surface,&SourceArea,DDBLT_WAIT,NULL);
		}
		if(FAILED(rval))return NDXERR_FLIPERR;
		return NDXERR_OK;
	}

	if(SysmemBack)
	{
		RECT area={0,0,Back->Width,Back->Height};
		rval=Primary->Surface->BltFast(0,0,Back->Surface,&area,DDBLTFAST_WAIT|DDBLTFAST_NOCOLORKEY);
		if(rval==DDERR_SURFACELOST)
		{
			Back->Restore();
			Primary->Restore();
			rval=Primary->Surface->BltFast(0,0,Back->Surface,&area,DDBLTFAST_WAIT|DDBLTFAST_NOCOLORKEY);
		}
		if(FAILED(rval))return NDXERR_FLIPERR;
		return NDXERR_OK;
	}else
	{
		rval=Primary->Surface->Flip(NULL,DDFLIP_WAIT);
		if(rval==DDERR_SURFACELOST)
		{
			Primary->Restore();
			rval=Primary->Surface->Flip(NULL,DDFLIP_WAIT);
		}
		if(FAILED(rval))return NDXERR_FLIPERR;
		return NDXERR_OK;
	}
}

NDXERR NDX_Screen::Flip(DWORD Flags, NDX_DirtyRect * Rects)
{
	if(Windowed)
	{
		if(Flags&NDXFF_STRETCH)
		{
			Flip(Flags);
		}else
		{
			for(int n=0;n<Rects->NumRects;n++)
			{
				Rects->SelectRect(n);
				if(Primary->Surface->Blt(&Rects->ClipRect,Back->Surface,&Rects->ClipRect,DDBLT_WAIT,NULL)==DDERR_SURFACELOST)
				{
					Back->Restore();
					Primary->Restore();
					Primary->Surface->Blt(&Rects->ClipRect,Back->Surface,&Rects->ClipRect,DDBLT_WAIT,NULL);
				}
			}
		}
	}else
	{
		for(int n=0;n<Rects->NumRects;n++)
		{
			Rects->SelectRect(n);
			if(Primary->Surface->BltFast(Rects->ClipRect.left,Rects->ClipRect.top,Back->Surface,&Rects->ClipRect,DDBLTFAST_WAIT)==DDERR_SURFACELOST)
			{
				Back->Restore();
				Primary->Restore();
				Primary->Surface->BltFast(Rects->ClipRect.left,Rects->ClipRect.top,Back->Surface,&Rects->ClipRect,DDBLTFAST_WAIT);
			}
		}
	}
	return NDXERR_OK;
}
