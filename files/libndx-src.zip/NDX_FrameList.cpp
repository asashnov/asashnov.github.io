//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////

// NDX_FrameList.cpp: implementation of the NDX_FrameList class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_FrameList::NDX_FrameList()
{
	NumFrames=0;
	Frames=(Frame*)malloc(0);
}

NDX_FrameList::~NDX_FrameList()
{
	FREE(Frames);
}

void NDX_FrameList::AddFrame(NDX_Surface * s, RECT a)
{
	Frames=(Frame*)realloc(Frames,sizeof(Frame)*(NumFrames+1));
	Frames[NumFrames].Surface=s;
	Frames[NumFrames].area=a;
	NumFrames++;
}

void NDX_FrameList::AddFrame(NDX_Surface * s)
{
	Frames=(Frame*)realloc(Frames,sizeof(Frame)*(NumFrames+1));
	Frames[NumFrames].Surface=s;
	Frames[NumFrames].area=NDX_RECT(0,0,s->Width,s->Height);
	NumFrames++;
}

void NDX_FrameList::AddFrames(NDX_Surface * s, int xpos, int ypos, int FrameWidth, int FrameHeight, int AmountX, int AmountY)
{	
	for(int y=0;y<AmountY;y++)
	{
		int xp=xpos;
		for(int x=0;x<AmountX;x++)
		{
			AddFrame(s,NDX_SizeRECT(xp,ypos,FrameWidth,FrameHeight));
			xp+=FrameWidth;
		}
		ypos+=FrameHeight;
	}
}

void NDX_FrameList::DrawRotoZoom(NDX_Surface *dest,int midX, int midY,int frame,double angle,double scale)
{
	Frames[frame].Surface->DrawRotoZoom(dest,midX,midY,angle,scale,Frames[frame].area);
}

void NDX_FrameList::DrawFadeToBlack(NDX_Surface * dest, int xpos, int ypos, int frame, DWORD alpha)
{
	Frames[frame].Surface->DrawFadeToBlack(dest,xpos,ypos,Frames[frame].area,alpha);
}

void NDX_FrameList::DrawColorMix(NDX_Surface * dest, int xpos, int ypos, int frame, DWORD Color,DWORD alpha)
{
	Frames[frame].Surface->DrawColorMix(dest,xpos,ypos,Frames[frame].area,Color,alpha);
}

void NDX_FrameList::Draw(NDX_Surface * dest, int xpos, int ypos, int frame)
{
	Frames[frame].Surface->Draw(dest,xpos,ypos,Frames[frame].area);
}

void NDX_FrameList::DrawAlpha(NDX_Surface * dest, int xpos, int ypos, int frame)
{
	Frames[frame].Surface->DrawAlpha(dest,xpos,ypos,Frames[frame].area);
}

void NDX_FrameList::DrawTrans(NDX_Surface * dest, int xpos, int ypos, int frame, DWORD alpha)
{
	Frames[frame].Surface->DrawTranslucent(dest,xpos,ypos,Frames[frame].area,alpha);
}

void NDX_FrameList::Draw(NDX_Surface * dest, RECT DestRect, int frame)
{
	Frames[frame].Surface->Draw(dest,Frames[frame].area,DestRect);
}

NDX_FrameList::Frame* NDX_FrameList::GetFrame(int frame)
{
	return &Frames[frame];
}



