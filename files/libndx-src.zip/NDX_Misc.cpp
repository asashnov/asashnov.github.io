//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

const char *NDX_GetVersion ( void )
{
    return (const char*)&NUKEDX_VERSION;
}

RECT NDX_RECT(int left,int top,int right,int bottom)
{
	RECT r={left,top,right,bottom};
	return r;
}

RECT NDX_SizeRECT(int left,int top,int width,int height)
{
	RECT r={left,top,left+width,top+height};
	return r;
}

int NDX_FileSize(FILE *fh)
{
  int Pos;
  int Size;
  Pos=ftell(fh);
  fseek(fh,0,SEEK_END);
  Size=ftell(fh);
  fseek(fh,Pos,SEEK_SET);
  return Size;
}

void memsetw(void *dest,unsigned short x,int count)
{
	unsigned short *sd=(unsigned short*)dest;
	while(count-->0)
	{
		*sd++=x;
	}
}

void memsetd(void *dest,int x,int count)
{
	__asm
	{
		mov edi,dest
		mov ecx,count
		mov eax,x
		rep stosd
	}
}

void NDX_GetTextSize(HDC hdc,LPSTR String,int *Width,int *Height)
{
	SIZE size;
	GetTextExtentPoint32(hdc,String,strlen(String),&size);
	*Width=size.cx;
	*Height=size.cy;
}

HFONT NDX_MakeFont(const char* FontName, int Width, int Height)
{
    HFONT Font;
	Font=CreateFont(Height, Width,
							0, 0,
							FW_NORMAL,
							FALSE,
							FALSE,
							FALSE,
							ANSI_CHARSET,
							OUT_DEFAULT_PRECIS,
							CLIP_DEFAULT_PRECIS,
							NONANTIALIASED_QUALITY,
							VARIABLE_PITCH,
							FontName);
   return Font;
}

void NDX_DeleteFont(HFONT Font)
{
	DeleteObject(Font);
}

//
///EOF
