//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Input.cpp: implementation of the NDX_Input class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BOOL WINAPI EnumJoystick(LPCDIDEVICEINSTANCE pdinst, LPVOID pvRef)
{
	NDX_Input *NI=(NDX_Input*)pvRef;
	if(NI->lpDI->CreateDevice(pdinst->guidInstance,&NI->lpDID,NULL)!=DI_OK)return DIENUM_CONTINUE;
	return DIENUM_STOP;
}

NDX_Input::NDX_Input()
{
	lpDI=NULL;
	lpDIDKeys=NULL;
	lpDIDMouse=NULL;
	lpDIDJoy=NULL;
	MouseActive=false;
	KeysActive=false;
	JoyActive=false;
	JoyX=0;
	JoyY=0;
	MouseX=0;
	MouseY=0;
	MouseXPos=0;
	MouseYPos=0;
	MouseLB=false;
	MouseMB=false;
	MouseRB=false;
	MouseLBClick=false;
	MouseMBClick=false;
	MouseRBClick=false;
	CoInitialize(NULL);
    m_dwDoubleClickTimeLB = 0;
    m_dwDoubleClickTimeMB = 0;
    m_dwDoubleClickTimeRB = 0;
    m_dwDoubleClickDelay = 300;
    MouseLBDblClick = false;
    MouseMBDblClick = false;
    MouseRBDblClick = false;
}

NDX_Input::~NDX_Input()
{
	RELEASE(lpDIDKeys);
	RELEASE(lpDIDMouse);
	RELEASE(lpDIDJoy);
	RELEASE(lpDI);
	CoUninitialize();
}

NDXERR NDX_Input::Create(HINSTANCE inst, HWND hwnd)
{
	MouseLimit.left=0;
	MouseLimit.top=0;
	MouseLimit.right=GetSystemMetrics(SM_CXSCREEN);
	MouseLimit.bottom=GetSystemMetrics(SM_CYSCREEN);
	if(DirectInputCreate(inst,DIRECTINPUT_VERSION,&lpDI,NULL)!=DI_OK)return NDXERR_DICREATEFAILED;

	// Create the mouse device
	if(lpDI->CreateDevice(GUID_SysMouse, &lpDIDMouse, NULL)==DI_OK)
	{
		MouseActive=true;
		lpDIDMouse->SetDataFormat(&c_dfDIMouse);
		lpDIDMouse->SetCooperativeLevel(hwnd,DISCL_NONEXCLUSIVE|DISCL_FOREGROUND);
		if(lpDIDMouse->Acquire()!=DI_OK)MouseActive=false;
	}else MouseActive=false;

	// Create the keyboard device
	if(lpDI->CreateDevice(GUID_SysKeyboard, &lpDIDKeys, NULL)==DI_OK)
	{
		KeysActive=true;
		lpDIDKeys->SetDataFormat(&c_dfDIKeyboard);
		lpDIDKeys->SetCooperativeLevel(hwnd,DISCL_NONEXCLUSIVE|DISCL_FOREGROUND);
		if(lpDIDKeys->Acquire()!=DI_OK)KeysActive=false;
	}else KeysActive=false;

	// Enumerate the joystick device
	lpDID=NULL;
	if(lpDI->EnumDevices(DIDEVTYPE_JOYSTICK,EnumJoystick,this,DIEDFL_ATTACHEDONLY)!=DI_OK)return NDXERR_DIENUMF;
	if(lpDID!=NULL)
	{
		if(lpDID->QueryInterface(IID_IDirectInputDevice2, (LPVOID *)&lpDIDJoy)!=DI_OK)return NDXERR_DIQUERYFAILED;
		RELEASE(lpDID);
		lpDIDJoy->SetDataFormat(&c_dfDIJoystick);
		lpDIDJoy->SetCooperativeLevel(hwnd,DISCL_NONEXCLUSIVE|DISCL_FOREGROUND);

		// Set the X-axis range (-1000 to +1000)
		DIPROPRANGE diprg;
		diprg.diph.dwSize = sizeof(diprg);
		diprg.diph.dwHeaderSize = sizeof(diprg.diph);
		diprg.diph.dwObj = DIJOFS_X;
		diprg.diph.dwHow = DIPH_BYOFFSET;
		diprg.lMin = -1000;
		diprg.lMax = +1000;

		if(lpDIDJoy->SetProperty(DIPROP_RANGE,&diprg.diph)!=DI_OK)return NDXERR_DISETJOYRANGE;

		// And again for Y-axis range
		diprg.diph.dwObj = DIJOFS_Y;
		if(lpDIDJoy->SetProperty(DIPROP_RANGE,&diprg.diph)!=DI_OK)return NDXERR_DISETJOYRANGE;

		// Set X axis dead zone to 10%
		DIPROPDWORD dipdw;
		dipdw.diph.dwSize=sizeof(dipdw);
		dipdw.diph.dwHeaderSize=sizeof(dipdw.diph);
		dipdw.diph.dwObj=DIJOFS_X;
		dipdw.diph.dwHow=DIPH_BYOFFSET;
		dipdw.dwData=1000;

		if(lpDIDJoy->SetProperty(DIPROP_DEADZONE,&dipdw.diph)!=DI_OK)return NDXERR_DISETJOYRANGE;

		// Set Y axis dead zone to 10%
		dipdw.diph.dwObj=DIJOFS_Y;
		if(lpDIDJoy->SetProperty(DIPROP_DEADZONE,&dipdw.diph)!=DI_OK)return NDXERR_DISETJOYRANGE;
		if(lpDIDJoy->Acquire()!=DI_OK)return NDXERR_DIJOYAQFAILED;
		JoyActive=true;
	}else JoyActive=false;

	return NDXERR_OK;
}

void NDX_Input::ReAcquire()
{
	if(MouseActive)lpDIDMouse->Acquire();
	if(KeysActive)lpDIDKeys->Acquire();
	if(JoyActive)lpDIDJoy->Acquire();
}

void NDX_Input::UnAcquire()
{
	if(MouseActive)lpDIDMouse->Unacquire();
	if(KeysActive)lpDIDKeys->Unacquire();
	if(JoyActive)lpDIDJoy->Unacquire();
}

void NDX_Input::Refresh()
{
	DIMOUSESTATE MouseState;
	DIJOYSTATE JoyState;

	if(MouseActive)
	{
		if(lpDIDMouse->GetDeviceState(sizeof(MouseState), &MouseState)==(DIERR_INPUTLOST|DIERR_NOTACQUIRED))lpDIDMouse->Acquire();
		MouseX=MouseState.lX;
		MouseY=MouseState.lY;
		MouseXPos+=MouseX;
		MouseYPos+=MouseY;
		if(MouseXPos<MouseLimit.left)MouseXPos=MouseLimit.left;
		if(MouseXPos>MouseLimit.right-1)MouseXPos=MouseLimit.right-1;
		if(MouseYPos<MouseLimit.top)MouseYPos=MouseLimit.top;
		if(MouseYPos>MouseLimit.bottom-1)MouseYPos=MouseLimit.bottom-1;
		MouseLBClick=!MouseLB&&MouseState.rgbButtons[0];
		MouseRBClick=!MouseRB&&MouseState.rgbButtons[1];
		MouseMBClick=!MouseMB&&MouseState.rgbButtons[2];
        MouseLB=(MouseState.rgbButtons[0])?true:false;
        MouseRB=(MouseState.rgbButtons[1])?true:false;
        MouseMB=(MouseState.rgbButtons[2])?true:false;
        MouseLBDblClick = false;
        MouseMBDblClick = false;
        MouseRBDblClick = false;
        if(MouseLBClick)
        {
            if( (GetTickCount() - m_dwDoubleClickTimeLB) < m_dwDoubleClickDelay)
            {
                MouseLBDblClick = true;
            }
            else
            {
                m_dwDoubleClickTimeLB = GetTickCount();
            }
        }

        if(MouseMBClick)
        {
            if( (GetTickCount() - m_dwDoubleClickTimeMB) < m_dwDoubleClickDelay)
            {
                MouseMBDblClick = true;
            }
            else
            {
                m_dwDoubleClickTimeMB = GetTickCount();
            }
        }

        if(MouseRBClick)
        {
            if( (GetTickCount() - m_dwDoubleClickTimeRB) < m_dwDoubleClickDelay)
            {
                MouseRBDblClick = true;
            }
            else
            {
                m_dwDoubleClickTimeRB = GetTickCount();
            }
        }
	}

	if(KeysActive)
	{
		if(lpDIDKeys->GetDeviceState(256,&Keys)==(DIERR_INPUTLOST|DIERR_NOTACQUIRED))lpDIDKeys->Acquire();
	}

	if(JoyActive)
	{
		lpDIDJoy->Poll();
		if(lpDIDJoy->GetDeviceState(sizeof(JoyState),&JoyState)==(DIERR_INPUTLOST|DIERR_NOTACQUIRED))lpDIDJoy->Acquire();
		JoyX = JoyState.lX;
		JoyY = JoyState.lY;
        JoyB1 = (JoyState.rgbButtons[0])?true:false;
        JoyB2 = (JoyState.rgbButtons[1])?true:false;
	}
}

void NDX_Input::SetActiveDevices(bool Mouse, bool Keyboard, bool Joystick)
{
	MouseActive=Mouse;
	KeysActive=Keyboard;
	JoyActive=Joystick;
}
/*
void SetMouseAbs();
void SetJoyAbs();

void NDX_Input::SetMouseAbs()
{
	DIPROPDWORD dipdw;
	dipdw.diph.dwSize=sizeof(DIPROPDWORD);
	dipdw.diph.dwHeaderSize=sizeof(DIPROPHEADER);
	dipdw.diph.dwObj=0;
	dipdw.diph.dwHow=DIPH_DEVICE;
	dipdw.dwData=DIPROPAXISMODE_ABS;
	lpDIDMouse->SetProperty(DIPROP_AXISMODE, &dipdw.diph);
}

void NDX_Input::SetJoyAbs()
{
	DIPROPDWORD dipdw;
	dipdw.diph.dwSize=sizeof(DIPROPDWORD);
	dipdw.diph.dwHeaderSize=sizeof(DIPROPHEADER);
	dipdw.diph.dwObj=0;
	dipdw.diph.dwHow=DIPH_DEVICE;
	dipdw.dwData=DIPROPAXISMODE_ABS;
	lpDIDJoy->SetProperty(DIPROP_AXISMODE, &dipdw.diph);
}
*/
void NDX_Input::RunMouseCPL(HWND hwnd)
{
	lpDIDMouse->RunControlPanel(hwnd,0);
}

void NDX_Input::RunJoyCPL(HWND hwnd)
{
	lpDIDJoy->RunControlPanel(hwnd,0);
}

NDXERR NDX_Input::GetKeyName(int KeyNumber, LPSTR Name)
{
	DIDEVICEOBJECTINSTANCE diInfo;
	diInfo.dwSize=sizeof(diInfo);
	lpDIDKeys->GetObjectInfo(&diInfo,KeyNumber,DIPH_BYOFFSET);
	strcpy(Name,diInfo.tszName);
	return NDXERR_OK;
}

void NDX_Input::SetMouseLimit(int x1, int y1, int x2, int y2)
{
	MouseLimit=NDX_RECT(x1,y1,x2,y2);
}

void NDX_Input::SetMouseLimit(NDX_Screen * Screen)
{
	SetMouseLimit(0,0,Screen->Primary->Width,Screen->Primary->Height);
}

bool NDX_Input::IsMouseInside(RECT _rectArea)
{
    // X checking first.
    if(MouseXPos<_rectArea.left||MouseXPos>_rectArea.right)return false;

    // Now Y checking.
    if(MouseYPos<_rectArea.top||MouseYPos>_rectArea.bottom)return false;
    return true;
}

// Screen Edge Detection
// Left Edge
bool NDX_Input::IsMouseInsideLEdgeBorder ( int _iBorderWidth )
{
    if ( MouseXPos <= MouseLimit.left + _iBorderWidth )
    {
        return true;
    }                                   // EO: if

    // Clean Up and Return
    return false;
}
// Top Edge
bool NDX_Input::IsMouseInsideTEdgeBorder ( int _iBorderWidth )
{
    if ( MouseYPos <= MouseLimit.top + _iBorderWidth )
    {
        return true;
    }                                   // EO: if

    // Clean Up and Return
    return false;
}
// Right Edge
bool NDX_Input::IsMouseInsideREdgeBorder ( int _iBorderWidth )
{
    if ( MouseXPos >= MouseLimit.right - _iBorderWidth )
    {
        return true;
    }                                   // EO: if

    // Clean Up and Return
    return false;
}
// Bottom Edge
bool NDX_Input::IsMouseInsideBEdgeBorder ( int _iBorderWidth )
{
    if ( MouseYPos >= MouseLimit.bottom - _iBorderWidth )
    {
        return true;
    }                                   // EO: if

    // Clean Up and Return
    return false;
}

//
///EOF
