//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_CDMusic.cpp: implementation of the NDX_CDMusic class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_CDMusic::NDX_CDMusic()
{
	MCIOpen.wDeviceID=0;
	NumTracks=0;
	TrackLength=NULL;
	DeviceOpen=false;
	ReadTOC();
	Open();
	Playing=false;
}

NDX_CDMusic::~NDX_CDMusic()
{
	Close();
	FREE(TrackLength);
}

short NDX_CDMusic::ReadTOC()
{
	bool dvo=DeviceOpen;
	if(dvo)Close();
	MCI_OPEN_PARMS tMCIOpen;
	MCI_STATUS_PARMS MCIStatus;
	int i;
	short nTrackLength;
	NumTracks=0;
	tMCIOpen.lpstrDeviceType=(LPCTSTR)MCI_DEVTYPE_CD_AUDIO;
	if(mciSendCommand(NULL, MCI_OPEN, MCI_OPEN_TYPE|MCI_OPEN_TYPE_ID, (DWORD)(LPVOID)&tMCIOpen))
	{
		return 0;
	}
	MCIStatus.dwItem = MCI_STATUS_NUMBER_OF_TRACKS;
	if(mciSendCommand(tMCIOpen.wDeviceID, MCI_STATUS, MCI_STATUS_ITEM|MCI_WAIT, (DWORD)(LPVOID)&MCIStatus))
	{
		mciSendCommand(tMCIOpen.wDeviceID, MCI_CLOSE, NULL, NULL);
		return 0;
	}
	NumTracks=(short)MCIStatus.dwReturn;
	MCIStatus.dwItem=MCI_STATUS_LENGTH;
	FREE(TrackLength);
	TrackLength=(short*)malloc(sizeof(short)*NumTracks);
	for(i=0;i<NumTracks;i++)
	{
		MCIStatus.dwTrack=i+1;
		mciSendCommand(tMCIOpen.wDeviceID, MCI_STATUS, MCI_TRACK|MCI_STATUS_ITEM|MCI_WAIT,     (DWORD)(LPVOID)&MCIStatus);
		nTrackLength=(short)(MCI_MSF_MINUTE(MCIStatus.dwReturn)*60 + MCI_MSF_SECOND(MCIStatus.dwReturn));
		TrackLength[i]=nTrackLength;
	}
	mciSendCommand(tMCIOpen.wDeviceID, MCI_CLOSE, NULL, NULL);
	if(dvo)Open();
	return NumTracks;
}

short NDX_CDMusic::GetTrackLen(short nTrack)
{
	if(nTrack>0&&nTrack<=NumTracks)return TrackLength[nTrack-1];
	else return 0;
}

void NDX_CDMusic::SetTrackLen(short nTrack, short nNewLength)
{
	if(nTrack>0&&nTrack<=NumTracks)TrackLength[nTrack-1]=nNewLength;
}

short NDX_CDMusic::GetTotalLen()
{
	short nTotalLength=0;
	short nTrack;
	for(nTrack=0;nTrack<NumTracks;nTrack++)
		nTotalLength=(short)(nTotalLength+TrackLength[nTrack]);
	return nTotalLength;
}

void NDX_CDMusic::Play(short Track, bool Continue)
{
	if(Track>NumTracks)return;
	MCI_PLAY_PARMS mciPlay;
	mciPlay.dwCallback=0;
	mciPlay.dwFrom=MCI_MAKE_TMSF(Track,0,0,0);
	if(Continue)
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_PLAY,MCI_FROM,(DWORD)&mciPlay);
	}else
	{
		mciPlay.dwTo=MCI_MAKE_TMSF(Track,TrackLength[Track-1]/60,TrackLength[Track-1]%60,0);
		mciSendCommand(MCIOpen.wDeviceID,MCI_PLAY,MCI_FROM|MCI_TO,(DWORD)&mciPlay);
	}
	Playing=true;
}

void NDX_CDMusic::PlayNotify(HWND hwnd,short Track, bool Continue)
{
	if(Track>NumTracks)return;
	MCI_PLAY_PARMS mciPlay;
	mciPlay.dwCallback=(DWORD)hwnd;
	mciPlay.dwFrom=MCI_MAKE_TMSF(Track,0,0,0);
	if(Continue)
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_PLAY,MCI_FROM|MCI_NOTIFY,(DWORD)&mciPlay);
	}else
	{
		mciPlay.dwTo=MCI_MAKE_TMSF(Track,TrackLength[Track-1]/60,TrackLength[Track-1]%60,0);
		mciSendCommand(MCIOpen.wDeviceID,MCI_PLAY,MCI_FROM|MCI_NOTIFY|MCI_TO,(DWORD)&mciPlay);
	}
	Playing=true;
}

void NDX_CDMusic::Stop()
{
	if(Playing)
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_STOP,MCI_FROM,NULL);
		Playing=false;
	}
}

bool NDX_CDMusic::Open()
{
	if(DeviceOpen)Close();
	MCI_SET_PARMS mciSet;
	MCIOpen.lpstrDeviceType=(LPCTSTR)MCI_DEVTYPE_CD_AUDIO;
	if(mciSendCommand(NULL,MCI_OPEN,MCI_OPEN_TYPE|MCI_OPEN_TYPE_ID,(DWORD)&MCIOpen))return false;
	mciSet.dwTimeFormat=MCI_FORMAT_TMSF;
	if(mciSendCommand(MCIOpen.wDeviceID,MCI_SET,MCI_SET_TIME_FORMAT,(DWORD)&mciSet))
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_CLOSE,0,NULL);
		return false;
	}
	DeviceOpen=true;
	return true;
}

bool NDX_CDMusic::Close()
{
	if(!DeviceOpen)return false;
	Stop();
	mciSendCommand(MCIOpen.wDeviceID,MCI_CLOSE,0,NULL);
	DeviceOpen=false;
	return true;
}

bool NDX_CDMusic::CheckID(MCIDEVICEID wDeviceID)
{
	return MCIOpen.wDeviceID==wDeviceID;
}

void NDX_CDMusic::Pause()
{
	if(Playing)
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_PAUSE,MCI_FROM,NULL);
	}
}

void NDX_CDMusic::Resume()
{
	MCI_PLAY_PARMS mciPlay;
	if(Playing)
	{
		mciSendCommand(MCIOpen.wDeviceID,MCI_PLAY,0,(DWORD)&mciPlay);
	}
}

