//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_SpriteControl.cpp: implementation of the NDX_SpriteControl class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_SpriteControl::NDX_SpriteControl()
{
	NumSprites=0;
	Sprites=(NDX_Sprite**)malloc(0);
}

NDX_SpriteControl::~NDX_SpriteControl()
{
	FREE(Sprites);
}

void NDX_SpriteControl::MoveAll(double delta)
{
	for(int n=0;n<NumSprites;n++)
	{
		Sprites[n]->Move(delta);
	}
}

void NDX_SpriteControl::DrawAll()
{
	for(int n=0;n<NumSprites;n++)
	{
		Sprites[n]->Draw();
	}
}

void NDX_SpriteControl::AddSprite(NDX_Sprite * Sprite)
{
	Sprites=(NDX_Sprite**)realloc(Sprites,sizeof(NDX_Sprite*)*(NumSprites+1));
	Sprites[NumSprites]=Sprite;
	NumSprites++;
}

void NDX_SpriteControl::RemoveSprite(NDX_Sprite * Sprite)
{
	for(int n=0;n<NumSprites;n++)
	{
		if(Sprites[n]==Sprite)
		{
			Sprites[n]=Sprites[--NumSprites];
			Sprites=(NDX_Sprite**)realloc(Sprites,sizeof(NDX_Sprite*)*NumSprites);
			break;
		}
	}
}

void NDX_SpriteControl::Message(void * lpData)
{
	for(int n=0;n<NumSprites;n++)
	{
		Sprites[n]->Message(lpData);
	}
}

void NDX_SpriteControl::Sort()
{
	bool done=false;
	while(!done)
	{
		done=true;
		for(int n=0;n<NumSprites-1;n++)
		{
			if(Sprites[n]->Zpos>Sprites[n+1]->Zpos)
			{
				NDX_Sprite *TempSprite=Sprites[n];
				Sprites[n]=Sprites[n+1];
				Sprites[n+1]=TempSprite;
				done=false;
			}
		}
	}
}

void NDX_SpriteControl::MoveAll(double delta, double max_delta)
{
	double d=delta;
	while(d>max_delta)
	{
		MoveAll(max_delta);
		d-=max_delta;
	}
	if(d>0)MoveAll(d);
}

void NDX_SpriteControl::CreateDirtyRects()
{
	for(int n=0;n<NumSprites;n++)
	{
		Sprites[n]->CreateDirtyRect();
	}
}
//
///EOF
