//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_AlphaMask.cpp: implementation of the NDX_AlphaMask class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_AlphaMask::NDX_AlphaMask()
{
	Alpha=NULL;
}

NDX_AlphaMask::~NDX_AlphaMask()
{
	FREE(Alpha);
}

void NDX_AlphaMask::Create(NDX_Surface *pSurface)
{
	Surface=pSurface;
	FREE(Alpha);
	Alpha=(unsigned char*)malloc(Surface->Height*Surface->Width);
	ZeroMemory(Alpha,Surface->Height*Surface->Width);
}

bool NDX_AlphaMask::LoadBMP(NF_FileBuffer FileBuffer, int Xpos, int Ypos)
{
	if(Alpha==NULL)return false;

	BITMAPFILEHEADER *bfh=(BITMAPFILEHEADER*)FileBuffer.FileBuffer;
	BITMAPINFOHEADER *bih=(BITMAPINFOHEADER*)(unsigned char*)((unsigned char*)FileBuffer.FileBuffer+sizeof(BITMAPFILEHEADER));
	RGBQUAD *BMPPalette=(RGBQUAD*)(unsigned char*)((unsigned char*)FileBuffer.FileBuffer+sizeof(BITMAPINFOHEADER)+sizeof(BITMAPFILEHEADER));
	if(*(unsigned char*)((unsigned char*)&bfh->bfType)!='B'||*(unsigned char*)((unsigned char*)&bfh->bfType+1)!='M')return false;
	if(bih->biBitCount!=8)return false;
	unsigned char *compData=FileBuffer.FileBuffer+bfh->bfOffBits;

	unsigned char LUT[256];
	for(int n=0;n<256;n++)
	{
		LUT[n]=(BMPPalette[n].rgbRed+BMPPalette[n].rgbGreen+BMPPalette[n].rgbBlue)/3;
	}

	if(bih->biCompression==0)
	{
		int adj=(4-(bih->biWidth-(bih->biWidth/4)*4));if(adj==4)adj=0;
		int ImagePitch=bih->biWidth+adj;
		for(int yp=0;yp<bih->biHeight;yp++)
		{
			unsigned char *d=Alpha+(bih->biHeight-yp-1+Ypos)*Surface->Width+Xpos;
			unsigned char *s=compData+ImagePitch*yp;
			for(int xp=0;xp<bih->biWidth;xp++)
			{
				*d++=LUT[*s++];
			}
		}
	}else
	{
		for(int yp=0;yp<bih->biHeight;yp++)
		{
			ZeroMemory(Alpha+(yp+Ypos)*Surface->Width+Xpos,bih->biWidth);
		}

		int pos=0;
		int x=0,y=0;
		ok:;
		if(compData[pos]>0)
		{
			memset(Alpha+(bih->biHeight-y+Ypos-1)*Surface->Width+x+Xpos,LUT[compData[pos+1]],compData[pos]);
			x+=compData[pos];
			pos+=2;
			goto ok;
		}
		pos++;
		if(compData[pos]==0)
		{
			y++;
			x=0;
			pos++;
			goto ok;
		}
		if(compData[pos]==2)
		{
			x+=compData[pos+1];
			y+=compData[pos+2];
			pos+=3;
			goto ok;
		}
		if(compData[pos]>2)
		{
			int le=compData[pos];
			pos++;
			for(int n=0;n<le;n++)
			{
				*(unsigned char*)(Alpha+(bih->biHeight-y+Ypos-1)*Surface->Width+x+Xpos)=LUT[compData[pos]];
				pos++;
				x++;
			}
			pos+=pos&1;
			goto ok;
		}
		free(compData);
	}
	return true;
}

bool NDX_AlphaMask::LoadBMP(FILE * fh, int Xpos, int Ypos, int FileSize)
{
	if(Alpha==NULL)return false;
	BITMAPINFOHEADER bih;
	BITMAPFILEHEADER bfh;
	RGBQUAD BMPPalette[256];
	int fpos=ftell(fh);
	fread(&bfh, sizeof(bfh),1,fh);
	if(*(char*)((char*)&bfh.bfType)!='B'||*(char*)((char*)&bfh.bfType+1)!='M')return false;
	fread(&bih, sizeof(bih),1,fh);
	if(bih.biBitCount!=8)return false;
	fread(&BMPPalette,sizeof(BMPPalette),1,fh);
	fseek(fh,fpos+bfh.bfOffBits,SEEK_SET);

	int datasize=FileSize-bfh.bfOffBits;
	unsigned char *compData=(LPBYTE)malloc(datasize);
	fread(compData,datasize,1,fh);

	unsigned char LUT[256];
	for(int n=0;n<256;n++)
	{
		LUT[n]=(BMPPalette[n].rgbRed+BMPPalette[n].rgbGreen+BMPPalette[n].rgbBlue)/3;
	}

	if(bih.biCompression==0)
	{
		int adj=(4-(bih.biWidth-(bih.biWidth/4)*4));if(adj==4)adj=0;
		int ImagePitch=bih.biWidth+adj;
		for(int yp=0;yp<bih.biHeight;yp++)
		{
			unsigned char *d=Alpha+(bih.biHeight-yp-1+Ypos)*Surface->Width+Xpos;
			unsigned char *s=compData+ImagePitch*yp;
			for(int xp=0;xp<bih.biWidth;xp++)
			{
				*d++=LUT[*s++];
			}
		}
	}else
	{
		for(int yp=0;yp<bih.biHeight;yp++)
		{
			ZeroMemory(Alpha+(yp+Ypos)*Surface->Width+Xpos,bih.biWidth);
		}

		int pos=0;
		int x=0,y=0;
		ok:;
		if(compData[pos]>0)
		{
			memset(Alpha+(bih.biHeight-y+Ypos-1)*Surface->Width+x+Xpos,LUT[compData[pos+1]],compData[pos]);
			x+=compData[pos];
			pos+=2;
			goto ok;
		}
		pos++;
		if(compData[pos]==0)
		{
			y++;
			x=0;
			pos++;
			goto ok;
		}
		if(compData[pos]==2)
		{
			x+=compData[pos+1];
			y+=compData[pos+2];
			pos+=3;
			goto ok;
		}
		if(compData[pos]>2)
		{
			int le=compData[pos];
			pos++;
			for(int n=0;n<le;n++)
			{
				*(unsigned char*)(Alpha+(bih.biHeight-y+Ypos-1)*Surface->Width+x+Xpos)=LUT[compData[pos]];
				pos++;
				x++;
			}
			pos+=pos&1;
			goto ok;
		}
		free(compData);
	}
	return true;
}

NDXERR NDX_AlphaMask::Blur(RECT area)
{
	if(Surface==NULL)return NDXERR_SURFACENC;
	if(Alpha==NULL)return NDXERR_ALPHANC;
	unsigned char *TempAlpha=(unsigned char*)malloc(Surface->Width*Surface->Height);
	memcpy(TempAlpha,Alpha,Surface->Width*Surface->Height);
	for(int y=area.top;y<area.bottom;y++)
	for(int x=area.left;x<area.right;x++)
	{
		DWORD Pixels=0;
		DWORD a=0;
		for(int y2=-1;y2<=1;y2++)
		for(int x2=-1;x2<=1;x2++)
		{
			if(x+x2>=area.left&&y+y2>=area.top&&x+x2<area.right&&y+y2<area.bottom)
			{
				Pixels++;
				a+=Alpha[(y+y2)*Surface->Width+x+x2];
			}
		}
		Pixels++;
		a+=Alpha[y*Surface->Width+x];
		Alpha[y*Surface->Width+x]=BYTE(a/Pixels);
	}
	free(TempAlpha);
	return NDXERR_OK;
}

NDXERR NDX_AlphaMask::AntiAlias(RECT area, DWORD ColorKey)
{
	int x,y;
	if(Surface==NULL)return NDXERR_SURFACENC;
	if(Alpha==NULL)return NDXERR_ALPHANC;
	Surface->Lock();
	unsigned char *TempAlpha=(unsigned char*)malloc(Surface->Width*Surface->Height);

	if(Surface->Screen->PixelFormat->BitCount==8)
	{
		for(y=area.top;y<area.bottom;y++)
		for(x=area.left;x<area.right;x++)
		{
			DWORD c=Surface->GetPixel_8(x,y);
			if(c!=ColorKey)
			{
				TempAlpha[y*Surface->Width+x]=255;
			}else
			{
				TempAlpha[y*Surface->Width+x]=0;
			}
		}
	}
	if(Surface->Screen->PixelFormat->BitCount==16)
	{
		for(y=area.top;y<area.bottom;y++)
		for(x=area.left;x<area.right;x++)
		{
			DWORD c=Surface->GetPixel_16(x,y);
			if(c!=ColorKey)
			{
				TempAlpha[y*Surface->Width+x]=255;
			}else
			{
				TempAlpha[y*Surface->Width+x]=0;
			}
		}
	}

	for(y=area.top;y<area.bottom;y++)
	for(x=area.left;x<area.right;x++)
	{
		DWORD Pixels=0;
		DWORD a=0;
		if(TempAlpha[y*Surface->Width+x]>0)
		{
			for(int y2=-1;y2<=1;y2++)
			for(int x2=-1;x2<=1;x2++)
			{
				if(x+x2>=area.left&&y+y2>=area.top&&x+x2<area.right&&y+y2<area.bottom)
				{
					Pixels++;
					a+=TempAlpha[(y+y2)*Surface->Width+x+x2];
				}
			}
			int i=a/Pixels;
			Alpha[y*Surface->Width+x]=i;
		}else Alpha[y*Surface->Width+x]=0;
	}
	Surface->Unlock();
	free(TempAlpha);
	return NDXERR_OK;
}

NDXERR NDX_AlphaMask::ColorIntensity(RECT area)
{
	if(Surface==NULL)return NDXERR_SURFACENC;
	if(Alpha==NULL)return NDXERR_ALPHANC;
	Surface->Lock();

	if(Surface->Screen->PixelFormat->BitCount==8)
	{
		for(int y=area.top;y<area.bottom;y++)
		for(int x=area.left;x<area.right;x++)
		{
			DWORD c=Surface->GetPixel_8(x,y);
			DWORD i=(Surface->Palette->Palette[c].peRed+Surface->Palette->Palette[c].peGreen+Surface->Palette->Palette[c].peBlue)/3;
			Alpha[y*Surface->Width+x]=BYTE(i);
		}
	}

	if(Surface->Screen->PixelFormat->BitCount==16)
	{
		for(int y=area.top;y<area.bottom;y++)
		for(int x=area.left;x<area.right;x++)
		{
			DWORD c=Surface->GetPixel_16(x,y);
			DWORD i=(Surface->Screen->PixelFormat->GetRed(c)+Surface->Screen->PixelFormat->GetGreen(c)+Surface->Screen->PixelFormat->GetBlue(c))/3;
			Alpha[y*Surface->Width+x]=BYTE(i);
		}
	}
	Surface->Unlock();
	return NDXERR_OK;
}

bool NDX_AlphaMask::LoadBMP(LPSTR filename, int Xpos, int Ypos)
{
	FILE *fh=fopen(filename,"rb");
	if(fh==NULL)return false;
	bool rval=LoadBMP(fh,Xpos,Ypos,NDX_FileSize(fh));
	fclose(fh);
	return rval;
}

//
///EOF
