//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Surface.cpp: implementation of the NDX_Surface class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Surface::NDX_Surface()
{
	Surface=NULL;
	Locked=false;
	LockedDC=false;
	TransP=false;
	RestoreCallBack=(NDX_SURFACERESTORECB)NULL;
	RestoreAppData=NULL;
	AlphaMask=NULL;
	Screen=NULL;
	Palette=NULL;
	hdc=NULL;
	Type=0;
}

NDX_Surface::~NDX_Surface()
{
	Release();
	if(Screen!=NULL)Screen->Surfaces->RemoveSurface(this);
}

void NDX_Surface::Release()
{
	RELEASE(Surface);
	DEL(AlphaMask);
	if(LockedDC)UnlockDC();
	if(Locked)Unlock();
}

void NDX_Surface::SetClip(LPRECT Rect)
{
	ClipRect=Rect;
}

NDXERR NDX_Surface::Create(NDX_Screen *ParentScreen, int SurfaceType, int SurfaceWidth, int SurfaceHeight)
{
	DDSURFACEDESC2 ddsd;
	Release();
	Screen=ParentScreen;
	DWORD TREEDEE=0;
	if(SurfaceType&NDXST_D3D)
	{
		TREEDEE=DDSCAPS_3DDEVICE;
	}
	SurfaceType&=0xff;
	Surface=NULL;
	Width=SurfaceWidth;Height=SurfaceHeight;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
	ddsd.dwHeight=Height;
	ddsd.dwWidth=Width;
	if(SurfaceType==NDXST_TEXTURE)
	{
		ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
		if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))return NDXERR_CREATESURFACE;
	}
	if(SurfaceType==NDXST_TEXTUREMANAGE)
	{
		ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
		ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE;
		if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))return NDXERR_CREATESURFACE;
	}
	if(SurfaceType==NDXST_SYSMEM)
	{
		ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN|DDSCAPS_SYSTEMMEMORY|TREEDEE;
		if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))return NDXERR_CREATESURFACE;
	}
	if(SurfaceType==NDXST_VIDMEM)
	{
		ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN|DDSCAPS_VIDEOMEMORY|TREEDEE;
		if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))return NDXERR_CREATESURFACE;
	}
	if(SurfaceType==NDXST_BESTFIT)
	{
		SurfaceType=NDXST_VIDMEM;
		ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN|DDSCAPS_VIDEOMEMORY|TREEDEE;
		if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))
		{
			ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN|DDSCAPS_SYSTEMMEMORY|TREEDEE;
			if(FAILED(Screen->lpDD->CreateSurface(&ddsd,&Surface,NULL)))return NDXERR_CREATESURFACE;
			SurfaceType=NDXST_SYSMEM;
		}
	}
	SetClip(&Screen->ClipRect);
	Type=SurfaceType;
	SetPalette(Screen->Palette);
	Screen->Surfaces->AddSurface(this);
	return NDXERR_OK;
}

NDXERR NDX_Surface::Lock()
{
	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	HRESULT rval=Surface->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);
	}
	if(FAILED(rval))return NDXERR_LOCK;
	Locked=true;
	lPitch=ddsd.lPitch;
	lpSurface=ddsd.lpSurface;
	return NDXERR_OK;
}

NDXERR NDX_Surface::Unlock()
{
	HRESULT rval=Surface->Unlock(NULL);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->Unlock(NULL);
	}
	if(FAILED(rval))return NDXERR_UNLOCK;
	Locked=false;
	return NDXERR_OK;
}

NDXERR NDX_Surface::LockDC()
{
	HRESULT rval=Surface->GetDC(&hdc);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->GetDC(&hdc);
	}
	if(FAILED(rval))return NDXERR_LOCKDC;
	LockedDC=true;
	return NDXERR_OK;
}

NDXERR NDX_Surface::UnlockDC()
{
	HRESULT rval=Surface->ReleaseDC(hdc);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->ReleaseDC(hdc);
	}
	if(FAILED(rval))return NDXERR_UNLOCKDC;
	LockedDC=false;
	return NDXERR_OK;
}

void NDX_Surface::SetColorKey(DWORD Color)
{
	if(Surface==NULL)return;
	DDCOLORKEY key;
	key.dwColorSpaceLowValue=Color;
	key.dwColorSpaceHighValue=Color;
	Surface->SetColorKey(DDCKEY_SRCBLT,&key);
	ColorKey=Color;
}

void NDX_Surface::Draw(NDX_Surface * dest, int x, int y, RECT area)
{
	if(x+(area.right-area.left)>ClipRect->right)
	{
		area.right-=x+(area.right-area.left)-ClipRect->right;
	}
	if(x<ClipRect->left)
	{
		area.left+=ClipRect->left-x;
		x=ClipRect->left;
	}
	if(y<ClipRect->top)
	{
		area.top+=ClipRect->top-y;
		y=ClipRect->top;
	}
	if(y+(area.bottom-area.top)>ClipRect->bottom)
	{
		area.bottom-=((area.bottom-area.top)+y)-ClipRect->bottom;
	}
	if(dest->Surface->BltFast(x,y,Surface,&area,DDBLTFAST_WAIT|(TransP ? DDBLTFAST_SRCCOLORKEY:DDBLTFAST_NOCOLORKEY))==DDERR_SURFACELOST)
	{
		Restore();
		dest->Restore();
		dest->Surface->BltFast(x,y,Surface,&area,DDBLTFAST_WAIT|(TransP ? DDBLTFAST_SRCCOLORKEY:DDBLTFAST_NOCOLORKEY));
	}
}

void NDX_Surface::SetRestoreCallBack(NDX_SURFACERESTORECB RCB, void *AppData)
{
	RestoreCallBack=RCB;
	RestoreAppData=AppData;
}

void NDX_Surface::Restore()
{
	if(Surface==NULL)return;
	if(Surface->IsLost()==DDERR_SURFACELOST)
	{
		Surface->Restore();
		if(RestoreCallBack!=NULL)
		{
			RestoreCallBack(this,RestoreAppData);
		}
	}
}

NDXERR NDX_Surface::FillRect(int x1, int y1, int x2, int y2, DWORD Color)
{
	RECT r={x1,y1,x2,y2};
	DDBLTFX ddbltfx;
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=Color;
	HRESULT rval=Surface->Blt(&r,NULL,&r,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->Blt(&r,NULL,&r,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
	}
	if(FAILED(rval))return NDXERR_BLTFAIL;
	return NDXERR_OK;
}

NDXERR NDX_Surface::Clear(DWORD Color)
{
	DDBLTFX ddbltfx;
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=Color;
	HRESULT rval=Surface->Blt(NULL,NULL,NULL,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
	if(rval==DDERR_SURFACELOST)
	{
		Restore();
		rval=Surface->Blt(NULL,NULL,NULL,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
	}
	if(FAILED(rval))return NDXERR_BLTFAIL;
	return NDXERR_OK;
}

NDXERR NDX_Surface::Text(LPSTR txt, int Xpos, int Ypos, DWORD Color, HFONT Font)
{
	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,TRANSPARENT);
	SetTextColor(hdc,Color);
	if(Font!=NULL)SelectObject(hdc,Font);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));
	if(!Lo)UnlockDC();
	return NDXERR_OK;
}

NDXERR NDX_Surface::Text(LPSTR txt, int Xpos, int Ypos, DWORD Color, DWORD BackColor, HFONT Font)
{
	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,OPAQUE);
	SetTextColor(hdc,Color);
	SetBkColor(hdc,BackColor);
	if(Font!=NULL)SelectObject(hdc,Font);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));
	if(!Lo)UnlockDC();
	return NDXERR_OK;
}

NDXERR NDX_Surface::CreateAlpha()
{
	DEL(AlphaMask);
	AlphaMask=new NDX_AlphaMask;
	AlphaMask->Create(this);
	return NDXERR_OK;
}

void NDX_Surface::DrawAlpha_16(NDX_Surface * dest, int xpos, int ypos, RECT area)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *aPtr;
	unsigned short *dPtr,*sPtr;
	int adddPos,addsPos,addaPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=dest->CalcOffset_16(xpos,ypos);//(unsigned short*)(unsigned char*)((unsigned char*)dest->lpSurface+ypos*dest->lPitch+xpos*2);
	sPtr=CalcOffset_16(area.left,area.top);//(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+area.top*lPitch+area.left*2);
	aPtr=(unsigned char*)AlphaMask->Alpha+area.top*Width+area.left;
	adddPos=dest->lPitch-nWidth*2;
	addsPos=lPitch-nWidth*2;
	addaPos=Width-nWidth;

	if(Screen->PixelFormat->PF==NDXPF_565)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				DWORD alpha=*aPtr++;
				if(alpha>0)
				{
					if(alpha==255)
					{
						*dPtr++=*sPtr++;
					}else
					{
						DWORD Source=*sPtr++;
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&63488);
						DWORD Mix1=DWORD((((((Source&63488)-b)*alpha)/256)&63488)+b);
						b=(Dest&2016);
						DWORD Mix2=DWORD((((((Source&2016)-b)*alpha)/256)&2016)+b);
						b=(Dest&31);
						DWORD Mix3=DWORD(((((Source&31)-b)*alpha)/256)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}
				}else
				{
					dPtr++;
					sPtr++;
				}
			}
			dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
			sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			aPtr+=addaPos;
		}
	}else if(Screen->PixelFormat->PF==NDXPF_555)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				DWORD alpha=*aPtr++;
				if(alpha>0)
				{
					if(alpha==255)
					{
						*dPtr++=*sPtr++;
					}else
					{
						DWORD Source=*sPtr++;
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&31744);
						DWORD Mix1=DWORD((((((Source&31744)-b)*alpha)/256)&31744)+b);
						b=(Dest&992);
						DWORD Mix2=DWORD((((((Source&992)-b)*alpha)/256)&992)+b);
						b=(Dest&31);
						DWORD Mix3=DWORD(((((Source&31)-b)*alpha)/256)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}
				}else
				{
					dPtr++;
					sPtr++;
				}
			}
			dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
			sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			aPtr+=addaPos;
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				DWORD alpha=*aPtr++;
				if(alpha>0)
				{
					if(alpha==255)
					{
						*dPtr++=*sPtr++;
					}else
					{
						DWORD Source=*sPtr++;
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&Screen->PixelFormat->RedMask);
						DWORD Mix1=((((((Source&Screen->PixelFormat->RedMask)-b)*alpha)/256)&Screen->PixelFormat->RedMask)+b);
						b=(Dest&Screen->PixelFormat->GreenMask);
						DWORD Mix2=((((((Source&Screen->PixelFormat->GreenMask)-b)*alpha)/256)&Screen->PixelFormat->GreenMask)+b);
						b=(Dest&Screen->PixelFormat->BlueMask);
						DWORD Mix3=((((((Source&Screen->PixelFormat->BlueMask)-b)*alpha)/256)&Screen->PixelFormat->BlueMask)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}
				}else
				{
					dPtr++;
					sPtr++;
				}
			}
			dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
			sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			aPtr+=addaPos;
		}
	}
}

void NDX_Surface::DrawAlpha_8(NDX_Surface * dest, int xpos, int ypos, RECT area)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *dPtr,*sPtr,*aPtr;
	int adddPos,addsPos,addaPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(LPBYTE)dest->lpSurface+ypos*dest->lPitch+xpos;
	sPtr=(LPBYTE)lpSurface+area.top*lPitch+area.left;
	aPtr=(LPBYTE)AlphaMask->Alpha+area.top*Width+area.left;
	adddPos=dest->lPitch-nWidth;
	addsPos=lPitch-nWidth;
	addaPos=Width-nWidth;

	for(int y=0;y<nHeight;y++)
	{
		for(int x=0;x<nWidth;x++)
		{
			DWORD alpha=*aPtr++;
			if(alpha>0)
			{
				alpha>>=3;
				if(alpha==31)
				{
					*dPtr++=*sPtr++;
				}else
				{
					unsigned short Source=Palette->ALU_ToRGB[(alpha<<8)+*sPtr++];
					unsigned short Dest=Palette->ALU_ToRGB[((alpha^31)<<8)+*dPtr];
					*dPtr++=Palette->ALU_ToIndex[Source+Dest];
				}
			}else
			{
				dPtr++;
				sPtr++;
			}
		}
		dPtr+=adddPos;
		sPtr+=addsPos;
		aPtr+=addaPos;
	}
}

void NDX_Surface::DrawAlpha(NDX_Surface * dest, int xpos, int ypos, RECT area)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			DrawAlpha_8(dest,xpos,ypos,area);
			break;
		case 16:
			DrawAlpha_16(dest,xpos,ypos,area);
			break;
	}
}

NDXERR NDX_Surface::LoadAlpha(NF_FileBuffer FileBuffer, int Xpos,int Ypos)
{
	if(AlphaMask==NULL)CreateAlpha();
	if(AlphaMask->LoadBMP(FileBuffer,Xpos,Ypos))return NDXERR_OK;else return NDXERR_BADFILE;
}

NDXERR NDX_Surface::LoadAlpha(FILE * fh, int Xpos,int Ypos, int FileSize)
{
	if(AlphaMask==NULL)CreateAlpha();
	if(AlphaMask->LoadBMP(fh,Xpos,Ypos,FileSize))return NDXERR_OK;else return NDXERR_BADFILE;
}

void NDX_Surface::DrawTranslucent(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			DrawTranslucent_8(dest,xpos,ypos,area,alpha);
			return;
		case 16:
			DrawTranslucent_16(dest,xpos,ypos,area,alpha);
			return;
	}
}

void NDX_Surface::DrawTranslucent_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *dPtr,*sPtr,*aPtr;
	int adddPos,addsPos,addaPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(LPBYTE)dest->lpSurface+ypos*dest->lPitch+xpos;
	sPtr=(LPBYTE)lpSurface+area.top*lPitch+area.left;
	aPtr=(LPBYTE)AlphaMask->Alpha+area.top*Width+area.left;
	adddPos=dest->lPitch-nWidth;
	addsPos=lPitch-nWidth;
	addaPos=Width-nWidth;

	DWORD alpha2=((alpha>>3)^31)<<8;
	alpha=(alpha>>3)<<8;

	if(TransP)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned char s=*sPtr++;
				if(s!=ColorKey)
				{
					unsigned short Source=Palette->ALU_ToRGB[alpha+s];
					unsigned short Dest=Palette->ALU_ToRGB[alpha2+*dPtr];
					*dPtr++=Palette->ALU_ToIndex[Source+Dest];
				}else dPtr++;
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned short Source=Palette->ALU_ToRGB[alpha+*sPtr++];
				unsigned short Dest=Palette->ALU_ToRGB[alpha2+*dPtr];
				*dPtr++=Palette->ALU_ToIndex[Source+Dest];
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}
}

void NDX_Surface::DrawTranslucent_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned short *dPtr,*sPtr;
	int adddPos,addsPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dest->lpSurface+ypos*dest->lPitch+xpos*2);
	sPtr=(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+area.top*lPitch+area.left*2);
	adddPos=dest->lPitch-nWidth*2;
	addsPos=lPitch-nWidth*2;

	DWORD alpha2=alpha^255;

	if(TransP)
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&63488);
						DWORD Mix1=((((((Source&63488)-b)*alpha)>>8)&63488)+b);
						b=(Dest&2016);
						DWORD Mix2=((((((Source&2016)-b)*alpha)>>8)&2016)+b);
						b=(Dest&31);
						DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&31744);
						DWORD Mix1=((((((Source&31744)-b)*alpha)>>8)&31744)+b);
						b=(Dest&992);
						DWORD Mix2=((((((Source&992)-b)*alpha)>>8)&992)+b);
						b=(Dest&31);
						DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);

					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Dest=*dPtr;
						DWORD b;
						b=(Dest&Screen->PixelFormat->RedMask);
						DWORD Mix1=((((((Source&Screen->PixelFormat->RedMask)-b)*alpha)>>8)&Screen->PixelFormat->RedMask)+b);
						b=(Dest&Screen->PixelFormat->GreenMask);
						DWORD Mix2=((((((Source&Screen->PixelFormat->GreenMask)-b)*alpha)>>8)&Screen->PixelFormat->GreenMask)+b);
						b=(Dest&Screen->PixelFormat->BlueMask);
						DWORD Mix3=((((((Source&Screen->PixelFormat->BlueMask)-b)*alpha)>>8)&Screen->PixelFormat->BlueMask)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);

					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}else
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Dest=*dPtr;
					DWORD b;
					b=(Dest&63488);
					DWORD Mix1=((((((Source&63488)-b)*alpha)>>8)&63488)+b);
					b=(Dest&2016);
					DWORD Mix2=((((((Source&2016)-b)*alpha)>>8)&2016)+b);
					b=(Dest&31);
					DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);

				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Dest=*dPtr;
					DWORD b;
					b=(Dest&31744);
					DWORD Mix1=((((((Source&31744)-b)*alpha)>>8)&31744)+b);
					b=(Dest&992);
					DWORD Mix2=((((((Source&992)-b)*alpha)>>8)&992)+b);
					b=(Dest&31);
					DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);

				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Dest=*dPtr;
					DWORD b;
					b=(Dest&Screen->PixelFormat->RedMask);
					DWORD Mix1=((((((Source&Screen->PixelFormat->RedMask)-b)*alpha)>>8)&Screen->PixelFormat->RedMask)+b);
					b=(Dest&Screen->PixelFormat->GreenMask);
					DWORD Mix2=((((((Source&Screen->PixelFormat->GreenMask)-b)*alpha)>>8)&Screen->PixelFormat->GreenMask)+b);
					b=(Dest&Screen->PixelFormat->BlueMask);
					DWORD Mix3=((((((Source&Screen->PixelFormat->BlueMask)-b)*alpha)>>8)&Screen->PixelFormat->BlueMask)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);

				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}
}

unsigned short Read16(FILE* fh)
{
	int	hi=fgetc(fh);
	int	lo=fgetc(fh);
	return lo+(hi<<8);
}

DWORD Read32(FILE* fh)
{
	DWORD b3=fgetc(fh);
	DWORD b2=fgetc(fh);
	DWORD b1=fgetc(fh);
	DWORD b0=fgetc(fh);
	return (b3<<24)+(b2<<16)+(b1<<8)+b0;
}

NDXERR NDX_Surface::DrawPSD_24_X(int Xpos, int Ypos, PSDInfo *ImageInfo)
{
	BITMAPINFO BitmapInfo;
	ZeroMemory(&BitmapInfo,sizeof(BitmapInfo));
	BitmapInfo.bmiHeader.biSize=sizeof(BitmapInfo.bmiHeader);
	BitmapInfo.bmiHeader.biWidth=ImageInfo->Width;
	BitmapInfo.bmiHeader.biHeight=-ImageInfo->Height;
	BitmapInfo.bmiHeader.biPlanes=1;
	BitmapInfo.bmiHeader.biBitCount=32;
	LockDC();
	StretchDIBits(hdc,Xpos,Ypos,ImageInfo->Width,ImageInfo->Height,0,0,ImageInfo->Width,ImageInfo->Height,ImageInfo->Pixels,&BitmapInfo,DIB_RGB_COLORS,SRCCOPY);
	UnlockDC();
	return NDXERR_OK;
}

NDXERR NDX_Surface::SetPalette(NDX_Palette * Pal)
{
	Palette=Pal;
	if(Palette==NULL)return NDXERR_SETPAL;
	if(Surface!=NULL&&Screen->PixelFormat->BitCount==8&&Palette->ddpal!=NULL)
	{
		HRESULT rval=Surface->SetPalette(Palette->ddpal);
		if(rval==DDERR_SURFACELOST)
		{
			Restore();
			rval=Surface->SetPalette(Palette->ddpal);
		}
		if(rval!=DD_OK)return NDXERR_SETPAL;
	}
	return NDXERR_OK;
}

void NDX_Surface::Draw(NDX_Surface * dest, RECT SourceRect, RECT DestRect)
{
	if(DestRect.left<ClipRect->left)
	{
		SourceRect.left+=(ClipRect->left-DestRect.left)*(SourceRect.right - SourceRect.left)/(DestRect.right - DestRect.left);
		DestRect.left=ClipRect->left;
	}
	if(DestRect.right>ClipRect->right)
	{
		SourceRect.right-=(DestRect.right-ClipRect->right)*(SourceRect.right - SourceRect.left)/(DestRect.right - DestRect.left);
		DestRect.right=ClipRect->right;
	}
	if(DestRect.top<ClipRect->top)
	{
		SourceRect.top+=(ClipRect->top-DestRect.top)*(SourceRect.bottom - SourceRect.top)/(DestRect.bottom - DestRect.top);
		DestRect.top=ClipRect->top;
	}
	if(DestRect.bottom>ClipRect->bottom)
	{
		SourceRect.bottom-=(DestRect.bottom-ClipRect->bottom)*(SourceRect.bottom - SourceRect.top)/(DestRect.bottom - DestRect.top);
		DestRect.bottom=ClipRect->bottom;
	}
	if(dest->Surface->Blt(&DestRect,Surface,&SourceRect,DDBLT_WAIT|(TransP ? DDBLT_KEYSRC:0),NULL)==DDERR_SURFACELOST)
	{
		Restore();
		dest->Restore();
		dest->Surface->Blt(&DestRect,Surface,&SourceRect,DDBLT_WAIT|(TransP ? DDBLT_KEYSRC:0),NULL);
	}
}

NDXERR NDX_Surface::LoadAlpha(LPSTR filename, int Xpos, int Ypos)
{
	FILE *fh=fopen(filename,"rb");
	if(fh==NULL)return NDXERR_BADFILE;
	NDXERR rval=LoadAlpha(fh,Xpos,Ypos,NDX_FileSize(fh));
	fclose(fh);
	return rval;
}

void NDX_Surface::SetColorKey(DWORD LowColor,DWORD HiColor)
{
	if(Surface==NULL)return;
	DDCOLORKEY key;
	key.dwColorSpaceLowValue=LowColor;
	key.dwColorSpaceHighValue=HiColor;
	Surface->SetColorKey(DDCKEY_SRCBLT,&key);
	ColorKey=LowColor;
}

void NDX_Surface::SelectAlpha(NDX_AlphaMask * a)
{
	AlphaMask=a;
}

NDXERR NDX_Surface::Text_OutLine(LPSTR txt, int Xpos, int Ypos, DWORD Color, DWORD OutLineColor, HFONT Font)
{
	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,TRANSPARENT);
	if(Font!=NULL)SelectObject(hdc,Font);
	SetTextColor(hdc,OutLineColor);
	TextOut(hdc,Xpos-1,Ypos,txt,strlen(txt));
	TextOut(hdc,Xpos+1,Ypos,txt,strlen(txt));
	TextOut(hdc,Xpos,Ypos-1,txt,strlen(txt));
	TextOut(hdc,Xpos,Ypos+1,txt,strlen(txt));
	SetTextColor(hdc,Color);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));
	if(!Lo)UnlockDC();
	return NDXERR_OK;
}

void NDX_Surface::DrawFadeToBlack(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			DrawFadeToBlack_8(dest,xpos,ypos,area,alpha);
			return;
		case 16:
			DrawFadeToBlack_16(dest,xpos,ypos,area,alpha);
			return;
	}
}

void NDX_Surface::DrawFadeToBlack_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *dPtr,*sPtr,*aPtr;
	int adddPos,addsPos,addaPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(LPBYTE)dest->lpSurface+ypos*dest->lPitch+xpos;
	sPtr=(LPBYTE)lpSurface+area.top*lPitch+area.left;
	aPtr=(LPBYTE)AlphaMask->Alpha+area.top*Width+area.left;
	adddPos=dest->lPitch-nWidth;
	addsPos=lPitch-nWidth;
	addaPos=Width-nWidth;
	alpha=(alpha>>3)<<8;

	if(TransP)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned char s=*sPtr++;
				if(s!=ColorKey)
				{
					unsigned short Source=Palette->ALU_ToRGB[alpha+s];
					*dPtr++=Palette->ALU_ToIndex[Source];
				}else dPtr++;
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned short Source=Palette->ALU_ToRGB[alpha+*sPtr++];
				*dPtr++=Palette->ALU_ToIndex[Source];
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}
}

void NDX_Surface::DrawFadeToBlack_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned short *dPtr,*sPtr;
	int adddPos,addsPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dest->lpSurface+ypos*dest->lPitch+xpos*2);
	sPtr=(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+area.top*lPitch+area.left*2);
	adddPos=dest->lPitch-nWidth*2;
	addsPos=lPitch-nWidth*2;

	DWORD alpha2=alpha^255;

	if(TransP)
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((Source&63488)*alpha)>>8)&63488);
						DWORD Mix2=((((Source&2016)*alpha)>>8)&2016);
						DWORD Mix3=(((Source&31)*alpha)>>8);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((Source&31744)*alpha)>>8)&31744);
						DWORD Mix2=((((Source&992)*alpha)>>8)&992);
						DWORD Mix3=(((Source&31)*alpha)>>8);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((Source&Screen->PixelFormat->RedMask)*alpha)>>8)&Screen->PixelFormat->RedMask);
						DWORD Mix2=((((Source&Screen->PixelFormat->GreenMask)*alpha)>>8)&Screen->PixelFormat->GreenMask);
						DWORD Mix3=((((Source&Screen->PixelFormat->BlueMask)*alpha)>>8)&Screen->PixelFormat->BlueMask);
						*dPtr++=WORD(Mix1|Mix2|Mix3);

					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}else
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((Source&63488)*alpha)>>8)&63488);
					DWORD Mix2=((((Source&2016)*alpha)>>8)&2016);
					DWORD Mix3=(((Source&31)*alpha)>>8);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((Source&31744)*alpha)>>8)&31744);
					DWORD Mix2=((((Source&992)*alpha)>>8)&992);
					DWORD Mix3=(((Source&31)*alpha)>>8);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((Source&Screen->PixelFormat->RedMask)*alpha)>>8)&Screen->PixelFormat->RedMask);
					DWORD Mix2=((((Source&Screen->PixelFormat->GreenMask)*alpha)>>8)&Screen->PixelFormat->GreenMask);
					DWORD Mix3=((((Source&Screen->PixelFormat->BlueMask)*alpha)>>8)&Screen->PixelFormat->BlueMask);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}
}

void NDX_Surface::DrawColorMix(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD Color, DWORD alpha)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			DrawColorMix_8(dest,xpos,ypos,area,Color,alpha);
			return;
		case 16:
			DrawColorMix_16(dest,xpos,ypos,area,Color,alpha);
			return;
	}
}

void NDX_Surface::DrawColorMix_8(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD Color,DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *dPtr,*sPtr,*aPtr;
	int adddPos,addsPos,addaPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(LPBYTE)dest->lpSurface+ypos*dest->lPitch+xpos;
	sPtr=(LPBYTE)lpSurface+area.top*lPitch+area.left;
	aPtr=(LPBYTE)AlphaMask->Alpha+area.top*Width+area.left;
	adddPos=dest->lPitch-nWidth;
	addsPos=lPitch-nWidth;
	addaPos=Width-nWidth;

	DWORD alpha2=((alpha>>3)^31)<<8;
	alpha=(alpha>>3)<<8;
	unsigned short Dest=Palette->ALU_ToRGB[alpha2+Color];

	if(TransP)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned char s=*sPtr++;
				if(s!=ColorKey)
				{
					unsigned short Source=Palette->ALU_ToRGB[alpha+s];
					*dPtr++=Palette->ALU_ToIndex[Source+Dest];
				}else dPtr++;
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned short Source=Palette->ALU_ToRGB[alpha+*sPtr++];
				*dPtr++=Palette->ALU_ToIndex[Source+Dest];
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
			aPtr+=addaPos;
		}
	}
}

void NDX_Surface::DrawColorMix_16(NDX_Surface * dest, int xpos, int ypos, RECT area, DWORD Color,DWORD alpha)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned short *dPtr,*sPtr;
	int adddPos,addsPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dest->lpSurface+ypos*dest->lPitch+xpos*2);
	sPtr=(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+area.top*lPitch+area.left*2);
	adddPos=dest->lPitch-nWidth*2;
	addsPos=lPitch-nWidth*2;

	if(TransP)
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			DWORD r=(Color&63488);
			DWORD g=(Color&2016);
			DWORD b=(Color&31);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((((Source&63488)-r)*alpha)>>8)&63488)+r);
						DWORD Mix2=((((((Source&2016)-g)*alpha)>>8)&2016)+g);
						DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			DWORD r=(Color&31744);
			DWORD g=(Color&992);
			DWORD b=(Color&31);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((((Source&31744)-r)*alpha)>>8)&31744)+r);
						DWORD Mix2=((((((Source&992)-g)*alpha)>>8)&992)+g);
						DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			DWORD r=(Color&Screen->PixelFormat->RedMask);
			DWORD g=(Color&Screen->PixelFormat->GreenMask);
			DWORD b=(Color&Screen->PixelFormat->BlueMask);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					if(Source!=ColorKey)
					{
						DWORD Mix1=((((((Source&Screen->PixelFormat->RedMask)-r)*alpha)>>8)&Screen->PixelFormat->RedMask)+r);
						DWORD Mix2=((((((Source&Screen->PixelFormat->GreenMask)-g)*alpha)>>8)&Screen->PixelFormat->GreenMask)+g);
						DWORD Mix3=((((((Source&Screen->PixelFormat->BlueMask)-b)*alpha)>>8)&Screen->PixelFormat->BlueMask)+b);
						*dPtr++=WORD(Mix1|Mix2|Mix3);
					}else
					{
						dPtr++;
					}
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}else
	{
		if(Screen->PixelFormat->PF==NDXPF_565)
		{
			DWORD r=(Color&63488);
			DWORD g=(Color&2016);
			DWORD b=(Color&31);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((((Source&63488)-r)*alpha)>>8)&63488)+r);
					DWORD Mix2=((((((Source&2016)-g)*alpha)>>8)&2016)+g);
					DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else if(Screen->PixelFormat->PF==NDXPF_555)
		{
			DWORD r=(Color&31744);
			DWORD g=(Color&992);
			DWORD b=(Color&31);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((((Source&31744)-r)*alpha)>>8)&31744)+r);
					DWORD Mix2=((((((Source&992)-g)*alpha)>>8)&992)+g);
					DWORD Mix3=(((((Source&31)-b)*alpha)>>8)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}else
		{
			DWORD r=(Color&Screen->PixelFormat->RedMask);
			DWORD g=(Color&Screen->PixelFormat->GreenMask);
			DWORD b=(Color&Screen->PixelFormat->BlueMask);
			for(int y=0;y<nHeight;y++)
			{
				for(int x=0;x<nWidth;x++)
				{
					DWORD Source=*sPtr++;
					DWORD Mix1=((((((Source&Screen->PixelFormat->RedMask)-r)*alpha)>>8)&Screen->PixelFormat->RedMask)+r);
					DWORD Mix2=((((((Source&Screen->PixelFormat->GreenMask)-g)*alpha)>>8)&Screen->PixelFormat->GreenMask)+g);
					DWORD Mix3=((((((Source&Screen->PixelFormat->BlueMask)-b)*alpha)>>8)&Screen->PixelFormat->BlueMask)+b);
					*dPtr++=WORD(Mix1|Mix2|Mix3);
				}
				dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
				sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
			}
		}
	}
}
// Rotozoom ****

void NDX_Surface::Scanrightside(int x1,int x2,int ytop,int lineheight,char side,int TexWidth,int TexHeight)
{
	int x,px,py,xadd,pxadd,pyadd,y;
	if(++lineheight<1)lineheight=1;
	xadd=((x2-x1)<<16)/lineheight;
	if(side==1)
	{
		px=0;
		py=0;
		pxadd=(TexWidth<<16)/lineheight;
		pyadd=0;
	}
	if(side==2)
	{
		px=(TexWidth-0)<<16;
		py=0;
		pxadd=0;
		pyadd=(TexHeight<<16)/lineheight;
	}
	if(side==3)
	{
		px=(TexWidth-0)<<16;
		py=(TexHeight-0)<<16;
		pxadd=(-TexWidth<<16)/lineheight;
		pyadd=0;
	}
	if(side==4)
	{
		px=0;
		py=(TexHeight-0)<<16;
		pxadd=0;
		pyadd=(-TexHeight<<16)/lineheight;
	}
	x=x1<<16;
	for(y=0;y<=lineheight;y++)
	{
		int yp=ytop+y;
		if(yp>=ClipRect->top&&yp<ClipRect->bottom)
		{
			Screen->righttable[yp].x=x;
			Screen->righttable[yp].px=px;
			Screen->righttable[yp].py=py;
		}
		x=x+xadd;
		px=px+pxadd;
		py=py+pyadd;
	}
}

void NDX_Surface::Scanleftside(int x1,int x2,int ytop,int lineheight,char side,int TexWidth,int TexHeight)
{
	int x,px,py,xadd,pxadd,pyadd,y;
	if(++lineheight<1)lineheight=1;
	xadd=((x2-x1)<<16)/lineheight;
	if(side==1)
	{
		px=(TexWidth-0)<<16;
		py=0;
		pxadd=(-TexWidth<<16)/lineheight;
		pyadd=0;
	}
	if(side==2)
	{
		px=(TexWidth-0)<<16;
		py=(TexHeight-0)<<16;
		pxadd=0;
		pyadd=(-TexHeight<<16)/lineheight;
	}
	if(side==3)
	{
		px=0;
		py=(TexHeight-0)<<16;
		pxadd=(TexWidth<<16)/lineheight;
		pyadd=0;
	}
	if(side==4)
	{
		px=0;
		py=0;
		pxadd=0;
		pyadd=(TexHeight<<16)/lineheight;
	}
	x=x1<<16;
	for(y=0;y<=lineheight;y++)
	{
		int yp=ytop+y;
		if(yp>=ClipRect->top&&yp<ClipRect->bottom)
		{
			Screen->lefttable[yp].x=x;
			Screen->lefttable[yp].px=px;
			Screen->lefttable[yp].py=py;
		}
		x=x+xadd;
		px=px+pxadd;
		py=py+pyadd;
	}
}

void NDX_Surface::TextureMap(NDX_Surface *dest, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, RECT area)
{
	if(Screen->TaxMapTableHeight<ClipRect->bottom)
	{
		FREE(Screen->lefttable);
		FREE(Screen->righttable);
		Screen->TaxMapTableHeight=ClipRect->bottom;
		Screen->lefttable=(NDX_Screen::TexMapTable*)malloc(sizeof(NDX_Screen::TexMapTable)*Screen->TaxMapTableHeight);
		Screen->righttable=(NDX_Screen::TexMapTable*)malloc(sizeof(NDX_Screen::TexMapTable)*Screen->TaxMapTableHeight);
	}
	int TexWidth=area.right-area.left;
	int TexHeight=area.bottom-area.top;

	int miny=y1;
	int maxy=y1;
	if(y2<miny)miny=y2;
	if(y2>maxy)maxy=y2;
	if(y3<miny)miny=y3;
	if(y3>maxy)maxy=y3;
	if(y4<miny)miny=y4;
	if(y4>maxy)maxy=y4;

	if(miny>=maxy)return;
	if(maxy<ClipRect->top)return;
	if(miny>=ClipRect->bottom)return;
	if(miny<ClipRect->top)miny=ClipRect->top;
	if(maxy>ClipRect->bottom)maxy=ClipRect->bottom;
	if(maxy-miny<1)return;

	if(y2<y1){Scanleftside(x2,x1,y2,y1-y2,1,TexWidth,TexHeight);}
	else{Scanrightside(x1,x2,y1,y2-y1,1,TexWidth,TexHeight);}

	if(y3<y2){Scanleftside (x3,x2,y3,y2-y3,2,TexWidth,TexHeight);}
	else{Scanrightside (x2,x3,y2,y3-y2,2,TexWidth,TexHeight);}

	if(y4<y3){Scanleftside (x4,x3,y4,y3-y4,3,TexWidth,TexHeight);}
	else{Scanrightside (x3,x4,y3,y4-y3,3,TexWidth,TexHeight);}

	if(y1<y4){Scanleftside (x1,x4,y1,y4-y1,4,TexWidth,TexHeight);}
	else{Scanrightside (x4,x1,y4,y1-y4,4,TexWidth,TexHeight);}

	int polyx1,polyx2,y,linewidth,pxadd,pyadd;
	int texX,texY;

	if(Screen->PixelFormat->BitCount==16)
	{
		if(TransP)
		{
			for(y=miny;y<=maxy;y++)
			{
				polyx1=Screen->lefttable[y].x>>16;
				polyx2=Screen->righttable[y].x>>16;
				linewidth=polyx2-polyx1;
				if(linewidth<1)linewidth=1;
				pxadd=((Screen->righttable[y].px)-(Screen->lefttable[y].px))/linewidth;
				pyadd=((Screen->righttable[y].py)-(Screen->lefttable[y].py))/linewidth;

				texX=Screen->lefttable[y].px;
				texY=Screen->lefttable[y].py;

				if(polyx1<ClipRect->left)
				{
					texX+=pxadd*(ClipRect->left-polyx1);
					texY+=pyadd*(ClipRect->left-polyx1);
					polyx1=ClipRect->left;
				}
				if(polyx2>ClipRect->right-0){polyx2=ClipRect->right-0;}

				texX+=area.left<<16;
				texY+=area.top<<16;
				unsigned short *dst=(unsigned short*)(char*)((char*)dest->lpSurface+y*dest->lPitch+polyx1*2);

				for(int x=polyx1+1;x<polyx2;x++)
				{
					texX+=pxadd;
					texY+=pyadd;
					unsigned short c=*(unsigned short*)(char*)((char*)lpSurface+(texY>>16)*lPitch+(texX>>16)*2);
					if(c!=ColorKey)*dst++=c;else dst++;
				}
			}
		}else
		{
			for(y=miny;y<=maxy;y++)
			{
				polyx1=Screen->lefttable[y].x>>16;
				polyx2=Screen->righttable[y].x>>16;
				linewidth=polyx2-polyx1;
				if(linewidth<1)linewidth=1;
				pxadd=((Screen->righttable[y].px)-(Screen->lefttable[y].px))/linewidth;
				pyadd=((Screen->righttable[y].py)-(Screen->lefttable[y].py))/linewidth;

				texX=Screen->lefttable[y].px;
				texY=Screen->lefttable[y].py;

				if(polyx1<ClipRect->left)
				{
					texX+=pxadd*(ClipRect->left-polyx1);
					texY+=pyadd*(ClipRect->left-polyx1);
					polyx1=ClipRect->left;
				}
				if(polyx2>ClipRect->right-0){polyx2=ClipRect->right-0;}

				texX+=area.left<<16;
				texY+=area.top<<16;
				unsigned short *dst=(unsigned short*)(char*)((char*)dest->lpSurface+y*dest->lPitch+polyx1*2);
				for(int x=polyx1+1;x<polyx2;x++)
				{
					texX+=pxadd;
					texY+=pyadd;
					*dst++=*(unsigned short*)(char*)((char*)lpSurface+(texY>>16)*lPitch+(texX>>16)*2);
				}
			}
		}
	}else if(Screen->PixelFormat->BitCount==8)
	{
		if(TransP)
		{
			for(y=miny;y<=maxy;y++)
			{
				polyx1=Screen->lefttable[y].x>>16;
				polyx2=Screen->righttable[y].x>>16;
				linewidth=polyx2-polyx1;
				if(linewidth<1)linewidth=1;
				pxadd=((Screen->righttable[y].px)-(Screen->lefttable[y].px))/linewidth;
				pyadd=((Screen->righttable[y].py)-(Screen->lefttable[y].py))/linewidth;

				texX=Screen->lefttable[y].px;
				texY=Screen->lefttable[y].py;

				if(polyx1<ClipRect->left)
				{
					texX+=pxadd*(ClipRect->left-polyx1);
					texY+=pyadd*(ClipRect->left-polyx1);
					polyx1=ClipRect->left;
				}
				if(polyx2>ClipRect->right-0){polyx2=ClipRect->right-0;}

				texX+=area.left<<16;
				texY+=area.top<<16;
				unsigned char *dst=(unsigned char*)((unsigned char*)dest->lpSurface+y*dest->lPitch+polyx1);

				for(int x=polyx1+1;x<polyx2;x++)
				{
					texX+=pxadd;
					texY+=pyadd;
					unsigned char c=*(unsigned char*)((unsigned char*)lpSurface+(texY>>16)*lPitch+(texX>>16));
					if(c!=ColorKey)*dst++=c;else dst++;
				}
			}
		}else
		{
			for(y=miny;y<=maxy;y++)
			{
				polyx1=Screen->lefttable[y].x>>16;
				polyx2=Screen->righttable[y].x>>16;
				linewidth=polyx2-polyx1;
				if(linewidth<1)linewidth=1;
				pxadd=((Screen->righttable[y].px)-(Screen->lefttable[y].px))/linewidth;
				pyadd=((Screen->righttable[y].py)-(Screen->lefttable[y].py))/linewidth;

				texX=Screen->lefttable[y].px;
				texY=Screen->lefttable[y].py;

				if(polyx1<ClipRect->left)
				{
					texX+=pxadd*(ClipRect->left-polyx1);
					texY+=pyadd*(ClipRect->left-polyx1);
					polyx1=ClipRect->left;
				}
				if(polyx2>ClipRect->right-0){polyx2=ClipRect->right-0;}

				texX+=area.left<<16;
				texY+=area.top<<16;
				unsigned char *dst=(unsigned char*)((unsigned char*)dest->lpSurface+y*dest->lPitch+polyx1);

				for(int x=polyx1+1;x<polyx2;x++)
				{
					texX+=pxadd;
					texY+=pyadd;
					*dst++=*(unsigned char*)((unsigned char*)lpSurface+(texY>>16)*lPitch+(texX>>16));
				}
			}
		}
	}
}

void NDX_Surface::DrawRotoZoom(NDX_Surface * dest, int midX, int midY, double angle, double scale,RECT area)
{
	double SinA,CosA;
	int HalfWidth=int(double((area.right-area.left)*scale/2));
	int HalfHeight=int(double((area.bottom-area.top)*scale/2));
	SinA=sin(-angle);
	CosA=cos(-angle);
    int x1=(int)(CosA*-HalfWidth-SinA*-HalfHeight);
    int y1=(int)(SinA*-HalfWidth+CosA*-HalfHeight);
    int x2=(int)(CosA*HalfWidth-SinA*-HalfHeight);
    int y2=(int)(SinA*HalfWidth+CosA*-HalfHeight);
    int x3=(int)(CosA*HalfWidth-SinA*HalfHeight);
    int y3=(int)(SinA*HalfWidth+CosA*HalfHeight);
    int x4=(int)(CosA*-HalfWidth-SinA*HalfHeight);
    int y4=(int)(SinA*-HalfWidth+CosA*HalfHeight);
	TextureMap(dest,x1+midX,y1+midY,x2+midX,y2+midY,x3+midX,y3+midY,x4+midX,y4+midY,area);
}

void NDX_Surface::DrawPaste(NDX_Surface * dest, int x, int y, RECT area)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			DrawPaste_8(dest,x,y,area);
			return;
		case 16:
			DrawPaste_16(dest,x,y,area);
			return;
	}
}

void NDX_Surface::DrawPaste_8(NDX_Surface * dest, int xpos, int ypos, RECT area)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned char *dPtr,*sPtr;
	int addsPos,adddPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(LPBYTE)dest->lpSurface+ypos*dest->lPitch+xpos;
	sPtr=(LPBYTE)lpSurface+area.top*lPitch+area.left;
	adddPos=dest->lPitch-nWidth;
	addsPos=lPitch-nWidth;

	if(TransP)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned char s=*sPtr++;
				if(s!=ColorKey)
				{
					*dPtr++=s;
				}else dPtr++;
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				*dPtr++=*sPtr++;
			}
			dPtr+=adddPos;
			sPtr+=addsPos;
		}
	}
}

void NDX_Surface::DrawPaste_16(NDX_Surface * dest, int xpos, int ypos, RECT area)
{
	int nHeight=area.bottom-area.top,nWidth=area.right-area.left;
	unsigned short *dPtr,*sPtr;
	int adddPos,addsPos;

    if(xpos<ClipRect->left)
	{
		nWidth-=ClipRect->left-xpos;
		area.left+=ClipRect->left-xpos;
		xpos=ClipRect->left;
	}
    if(xpos+nWidth>ClipRect->right)
	{
		nWidth=ClipRect->right-xpos;
	}
	if(ypos<ClipRect->top)
	{
		nHeight-=ClipRect->top-ypos;
		area.top+=ClipRect->top-ypos;
		ypos=ClipRect->top;
	}
	if(ypos+nHeight>ClipRect->bottom)
	{
		nHeight=ClipRect->bottom-ypos;
	}

	dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dest->lpSurface+ypos*dest->lPitch+xpos*2);
	sPtr=(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+area.top*lPitch+area.left*2);
	adddPos=dest->lPitch-nWidth*2;
	addsPos=lPitch-nWidth*2;

	if(TransP)
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				unsigned short s=*sPtr++;
				if(s!=ColorKey)
				{
					*dPtr++=s;
				}else dPtr++;
			}
			dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
			sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
		}
	}else
	{
		for(int y=0;y<nHeight;y++)
		{
			for(int x=0;x<nWidth;x++)
			{
				*dPtr++=*sPtr++;
			}
			dPtr=(unsigned short*)(unsigned char*)((unsigned char*)dPtr+adddPos);
			sPtr=(unsigned short*)(unsigned char*)((unsigned char*)sPtr+addsPos);
		}
	}
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen * ParentScreen, int type, FILE *fh, int Xpos, int Ypos, bool Remap,int FileSize)
{
	if(fh==NULL)return NDXERR_BADFILE;
	unsigned char *FileBuffer=(unsigned char*)malloc(FileSize);
	fread(FileBuffer,FileSize,1,fh);
	NDXERR rval=LoadBMP_HANDLER(ParentScreen,type,FileBuffer,Xpos,Ypos,Remap);
	free(FileBuffer);
	return rval;
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen * ParentScreen, int type, LPSTR FileName, int Xpos, int Ypos, bool Remap)
{
	FILE *fh=fopen(FileName,"rb");
	if(fh==NULL)return NDXERR_BADFILE;
	int FileSize=NDX_FileSize(fh);
	NDXERR rval=LoadBMP(ParentScreen,type,fh,Xpos,Ypos,Remap,FileSize);
	fclose(fh);
	return rval;
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen * ParentScreen, int type, NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool Remap)
{
	NDXERR rval=LoadBMP_HANDLER(ParentScreen,type,FileBuffer.FileBuffer,Xpos,Ypos,Remap);
	free(FileBuffer.FileBuffer);
	return rval;
}

NDXERR NDX_Surface::LoadBMP_HANDLER(NDX_Screen * ParentScreen, int type, unsigned char* FileBuffer, int Xpos, int Ypos, bool Remap)
{
	NDXERR rval;
	BITMAPFILEHEADER *bfh=(BITMAPFILEHEADER*)FileBuffer;
	BITMAPINFOHEADER *bih=(BITMAPINFOHEADER*)(unsigned char*)((unsigned char*)FileBuffer+sizeof(BITMAPFILEHEADER));
	RGBQUAD *BMPPalette=(RGBQUAD*)(unsigned char*)((unsigned char*)FileBuffer+sizeof(BITMAPINFOHEADER)+sizeof(BITMAPFILEHEADER));

	if(*(unsigned char*)((unsigned char*)&bfh->bfType)!='B'||*(unsigned char*)((unsigned char*)&bfh->bfType+1)!='M')return NDXERR_BADBMP;
	if(bih->biBitCount!=8&&bih->biBitCount!=24)return NDXERR_BADBMP;

	if(Surface==NULL&&ParentScreen!=NULL)Create(ParentScreen,type,bih->biWidth+Xpos,bih->biHeight+Ypos);

	if(Xpos+bih->biWidth>Width||Ypos+bih->biHeight>Height||Xpos<0||Ypos<0)
	{
		NDX_Surface *TempSurf=new NDX_Surface;
		TempSurf->Create(ParentScreen,NDXST_SYSMEM,bih->biWidth,bih->biHeight);
		rval=TempSurf->LoadBMP_LOADER(FileBuffer,bfh,bih,BMPPalette,0,0,Remap);
		if(rval==NDXERR_OK)
		{
			RECT tr={0,0,Width,Height};
			TempSurf->SetClip(&tr);
			TempSurf->Draw(this,Xpos,Ypos);
		}
		delete TempSurf;
		return rval;
	}

	rval=LoadBMP_LOADER(FileBuffer,bfh,bih,BMPPalette,Xpos,Ypos,Remap);

	return rval;
}

NDXERR NDX_Surface::LoadBMP_LOADER(unsigned char* FileBuffer, BITMAPFILEHEADER * bfh, BITMAPINFOHEADER * bih, RGBQUAD *BMPPalette, int Xpos, int Ypos, bool Remap)
{
	switch(Screen->PixelFormat->BitCount)
	{
		case 8:
			switch(bih->biBitCount)
			{
				case 8:
					switch(bih->biCompression)
					{
						case 0:
							if(Palette!=NULL&&Remap)LoadBMP_8_8_Remap(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							if(Palette==NULL||!Remap)LoadBMP_8_8(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							break;
						case 1:
							if(Palette!=NULL&&Remap)LoadBMP_RLE_8_Remap(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							if(Palette==NULL||!Remap)LoadBMP_RLE_8(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							break;
					}
					break;
				case 24:
					LoadBMP_24_X(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih);
					break;
			}
			break;
		case 16:
			switch(bih->biBitCount)
			{
				case 8:
					switch(bih->biCompression)
					{
						case 0:
							LoadBMP_8_16(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							break;
						case 1:
							LoadBMP_RLE_16(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih,BMPPalette);
							break;
					}
					break;
				case 24:
					LoadBMP_24_X(FileBuffer+bfh->bfOffBits,Xpos,Ypos,bih);
					break;
			}
			break;
	}
	return NDXERR_OK;
}

void NDX_Surface::LoadBMP_24_X(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih)
{
	BITMAPINFO BitmapInfo;
	ZeroMemory(&BitmapInfo,sizeof(BitmapInfo));
	BitmapInfo.bmiHeader=*bih;
	LockDC();
	StretchDIBits(hdc,Xpos,Ypos,bih->biWidth,bih->biHeight,0,0,bih->biWidth,bih->biHeight,data,&BitmapInfo,DIB_RGB_COLORS,SRCCOPY);
	UnlockDC();
}

void NDX_Surface::LoadBMP_8_16(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	int adj=(4-(bih->biWidth-(bih->biWidth/4)*4));if(adj==4)adj=0;
	int ImagePitch=bih->biWidth+adj;
	unsigned short *dptr;
	unsigned char *sptr;
	unsigned short LookUp[256];
	for(int n=0;n<256;n++)
	{
		LookUp[n]=WORD(Screen->PixelFormat->Rgb(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue));
	}
	Lock();
	for(int y=0;y<bih->biHeight;y++)
	{
		dptr=(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+(Ypos+bih->biHeight-y-1)*lPitch);
		sptr=(unsigned char*)((unsigned char*)data+ImagePitch*y);
		for(int x=0;x<bih->biWidth;x++)
		{
			dptr[x]=LookUp[sptr[x]];
		}
	}
	Unlock();
}

void NDX_Surface::LoadBMP_RLE_16(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	unsigned char *compData=(LPBYTE)data;
	FillRect(Xpos,Ypos,Xpos+bih->biWidth,Ypos+bih->biHeight,Screen->PixelFormat->Rgb(BMPPalette[0].rgbRed,BMPPalette[0].rgbGreen,BMPPalette[0].rgbBlue));
	Lock();
	int pos=0;
	int x=0,y=0;
	unsigned short LookUp[256];
	for(int n=0;n<256;n++)
	{
		LookUp[n]=WORD(Screen->PixelFormat->Rgb(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue));
	}
	ok:;
	if(compData[pos]>0)
	{
		memsetw((unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos)*2),LookUp[compData[pos+1]],compData[pos]);
		x+=compData[pos];
		pos+=2;
		goto ok;
	}
	pos++;
	if(compData[pos]==0)
	{
		y++;
		x=0;
		pos++;
		goto ok;
	}
	if(compData[pos]==2)
	{
		x+=compData[pos+1];
		y+=compData[pos+2];
		pos+=3;
		goto ok;
	}
	if(compData[pos]>2)
	{
		int le=compData[pos];
		pos++;
		for(int n=0;n<le;n++)
		{
			*(unsigned short*)(unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos)*2)=LookUp[compData[pos]];
			pos++;
			x++;
		}
		pos+=pos&1;
		goto ok;
	}
	Unlock();
}

void NDX_Surface::LoadBMP_8_8(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	int adj=(4-(bih->biWidth-(bih->biWidth/4)*4));if(adj==4)adj=0;
	int ImagePitch=bih->biWidth+adj;
	unsigned char *dptr;
	unsigned char *sptr;
	Lock();
	for(int y=0;y<bih->biHeight;y++)
	{
		dptr=(unsigned char*)((unsigned char*)lpSurface+(Ypos+bih->biHeight-y-1)*lPitch+Xpos);
		sptr=(unsigned char*)((unsigned char*)data+ImagePitch*y);
		memcpy(dptr,sptr,bih->biWidth);
	}
	Unlock();
}

void NDX_Surface::LoadBMP_8_8_Remap(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	int adj=(4-(bih->biWidth-(bih->biWidth/4)*4));if(adj==4)adj=0;
	int ImagePitch=bih->biWidth+adj;
	unsigned char *dptr;
	unsigned char *sptr;
	unsigned char LookUp[256];
	int Width=bih->biWidth;
	for(int n=0;n<256;n++)
	{
		LookUp[n]=Palette->RGBToIndex(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue);
	}
	Lock();
	for(int y=0;y<bih->biHeight;y++)
	{
		dptr=(unsigned char*)((unsigned char*)lpSurface+(Ypos+bih->biHeight-y-1)*lPitch+Xpos);
		sptr=(unsigned char*)((unsigned char*)data+ImagePitch*y);
		for(int x=0;x<bih->biWidth;x++)
		{
			dptr[x]=LookUp[sptr[x]];
		}
	}
	Unlock();
}

void NDX_Surface::LoadBMP_RLE_8_Remap(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	unsigned char *compData=(LPBYTE)data;
	FillRect(Xpos,Ypos,Xpos+bih->biWidth,Ypos+bih->biHeight,Palette->RGBToIndex(BMPPalette[0].rgbRed,BMPPalette[0].rgbGreen,BMPPalette[0].rgbBlue));
	Lock();
	int pos=0;
	int x=0,y=0,le;
	unsigned char LookUp[256];
	for(int n=0;n<256;n++)
	{
		LookUp[n]=Palette->RGBToIndex(BMPPalette[n].rgbRed,BMPPalette[n].rgbGreen,BMPPalette[n].rgbBlue);
	}
	ok:;
	if(compData[pos]>0)
	{
		le=compData[pos];
		memset((unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos)),LookUp[compData[pos+1]],le);
		x+=le;
		pos+=2;
		goto ok;
	}
	pos++;
	if(compData[pos]==0)
	{
		y++;
		x=0;
		pos++;
		goto ok;
	}
	if(compData[pos]==2)
	{
		x+=compData[pos+1];
		y+=compData[pos+2];
		pos+=3;
		goto ok;
	}
	if(compData[pos]>2)
	{
		le=compData[pos];
		pos++;
		for(int n=0;n<le;n++)
		{
			*(unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos))=LookUp[compData[pos]];
			pos++;
			x++;
		}
		pos+=pos&1;
		goto ok;
	}
	Unlock();
}

void NDX_Surface::LoadBMP_RLE_8(void *data, int Xpos, int Ypos, BITMAPINFOHEADER * bih, RGBQUAD * BMPPalette)
{
	unsigned char *compData=(LPBYTE)data;
	FillRect(Xpos,Ypos,Xpos+bih->biWidth,Ypos+bih->biHeight,0);
	Lock();
	int pos=0;
	int x=0,y=0;
	ok:;
	if(compData[pos]>0)
	{
		memset((unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos)),compData[pos+1],compData[pos]);
		x+=compData[pos];
		pos+=2;
		goto ok;
	}
	pos++;
	if(compData[pos]==0)
	{
		y++;
		x=0;
		pos++;
		goto ok;
	}
	if(compData[pos]==2)
	{
		x+=compData[pos+1];
		y+=compData[pos+2];
		pos+=3;
		goto ok;
	}
	if(compData[pos]>2)
	{
		int le=compData[pos];
		pos++;
		for(int n=0;n<le;n++)
		{
			*(unsigned char*)((unsigned char*)lpSurface+(bih->biHeight-y+Ypos-1)*lPitch+(x+Xpos))=compData[pos];
			pos++;
			x++;
		}
		pos+=pos&1;
		goto ok;
	}
	Unlock();
}

NDXERR NDX_Surface::LoadPSD(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, bool UseAlpha)
{
	return LoadPSD(ParentScreen,type,FileBuffer,0,0,UseAlpha);
}

NDXERR NDX_Surface::LoadPSD(NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool UseAlpha)
{
	return LoadPSD(NULL,0,FileBuffer,Xpos,Ypos,UseAlpha);
}

NDXERR NDX_Surface::LoadPSD(FILE *fh, int Xpos, int Ypos, bool UseAlpha, int FileSize)
{
	return LoadPSD(NULL,0,fh,Xpos,Ypos,UseAlpha,FileSize);
}


NDXERR NDX_Surface::LoadBMP(FILE *fh, int Xpos, int Ypos, bool Remap, int FileSize)
{
	return LoadBMP(NULL,0,fh,Xpos,Ypos,Remap,FileSize);
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen *ParentScreen, int type, FILE *fh, bool Remap, int FileSize)
{
	return LoadBMP(ParentScreen,type,fh,0,0,Remap,FileSize);
}

NDXERR NDX_Surface::LoadBMP(LPSTR filename, int Xpos, int Ypos, bool Remap)
{
	return LoadBMP(NULL,0,filename,Xpos,Ypos,Remap);
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen *ParentScreen, int type, LPSTR filename, bool Remap)
{
	return LoadBMP(ParentScreen,type,filename,0,0,Remap);
}

NDXERR NDX_Surface::LoadBMP(NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool Remap)
{
	return LoadBMP(NULL,0,FileBuffer,Xpos,Ypos,Remap);
}

NDXERR NDX_Surface::LoadBMP(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, bool Remap)
{
	return LoadBMP(ParentScreen,type,FileBuffer,0,0,Remap);
}

unsigned short NDX_Surface::PSD_Read16(PSDInfo *ImageInfo)
{
	DWORD hi=*ImageInfo->DataPtr++;
	DWORD lo=*ImageInfo->DataPtr++;
	return WORD(lo+(hi<<8));
}

DWORD NDX_Surface::PSD_Read32(PSDInfo *ImageInfo)
{
	DWORD b3=*ImageInfo->DataPtr++;
	DWORD b2=*ImageInfo->DataPtr++;
	DWORD b1=*ImageInfo->DataPtr++;
	DWORD b0=*ImageInfo->DataPtr++;
	return (b3<<24)+(b2<<16)+(b1<<8)+b0;
}

NDXERR NDX_Surface::LoadPSD(NDX_Screen *ParentScreen, int type, LPSTR FileName, bool UseAlpha)
{
	FILE *fh=fopen(FileName,"rb");
	if(fh==NULL)return NDXERR_BADFILE;
	NF_FileBuffer FB;
	FB.Size=NDX_FileSize(fh);
	FB.FileBuffer=(unsigned char*)malloc(FB.Size);
	fread(FB.FileBuffer,FB.Size,1,fh);
	NDXERR rval=LoadPSD(ParentScreen,type,FB,0,0,UseAlpha);
	fclose(fh);
	return rval;
}

NDXERR NDX_Surface::LoadPSD(NDX_Screen *ParentScreen, int type, FILE *fh, bool UseAlpha, int FileSize)
{
	NF_FileBuffer FB;
	FB.Size=FileSize;
	FB.FileBuffer=(unsigned char*)malloc(FB.Size);
	fread(FB.FileBuffer,FB.Size,1,fh);
	NDXERR rval=LoadPSD(ParentScreen,type,FB,0,0,UseAlpha);
	return rval;
}

NDXERR NDX_Surface::LoadPSD(LPSTR FileName, int Xpos, int Ypos, bool UseAlpha)
{
	FILE *fh=fopen(FileName,"rb");
	if(fh==NULL)return NDXERR_BADFILE;
	NF_FileBuffer FB;
	FB.Size=NDX_FileSize(fh);
	FB.FileBuffer=(unsigned char*)malloc(FB.Size);
	fread(FB.FileBuffer,FB.Size,1,fh);
	NDXERR rval=LoadPSD(NULL,0,FB,Xpos,Ypos,UseAlpha);
	fclose(fh);
	return rval;
}

NDXERR NDX_Surface::LoadPSD(NDX_Screen *ParentScreen, int type, FILE *fh, int Xpos, int Ypos, bool UseAlpha,int FileSize)
{
	NF_FileBuffer FB;
	FB.Size=FileSize;
	FB.FileBuffer=(unsigned char*)malloc(FileSize);
	fread(FB.FileBuffer,FileSize,1,fh);
	NDXERR rval=LoadPSD(ParentScreen,type,FB,Xpos,Ypos,UseAlpha);
	free(FB.FileBuffer);
	return rval;
}

// Husk at free(FileBuffer.FileBuffer) f�r return!!!
NDXERR NDX_Surface::LoadPSD(NDX_Screen *ParentScreen, int type, NF_FileBuffer FileBuffer, int Xpos, int Ypos, bool UseAlpha)
{
	PSDInfo ImageInfo;
	ImageInfo.DataPtr=FileBuffer.FileBuffer;
	if(PSD_Read32(&ImageInfo)!=0x38425053){free(FileBuffer.FileBuffer);return NDXERR_NOTPSD;}
	if(PSD_Read16(&ImageInfo)!=1){free(FileBuffer.FileBuffer);return NDXERR_NOTPSD;}
	PSD_Read32(&ImageInfo);
	PSD_Read16(&ImageInfo);
	ImageInfo.ChannelCount=PSD_Read16(&ImageInfo);
	if(ImageInfo.ChannelCount>4){free(FileBuffer.FileBuffer);return NDXERR_NOTPSD;}
	ImageInfo.Height=PSD_Read32(&ImageInfo);
	ImageInfo.Width=PSD_Read32(&ImageInfo);
	if(PSD_Read16(&ImageInfo)!=8){free(FileBuffer.FileBuffer);return NDXERR_NOTPSD;}
	
	// Make sure the color mode is RGB.
	// Valid options are:
	//   0: Bitmap
	//   1: Grayscale
	//   2: Indexed color
	//   3: RGB color
	//   4: CMYK color
	//   7: Multichannel
	//   8: Duotone
	//   9: Lab color
	if(PSD_Read16(&ImageInfo)!=3){free(FileBuffer.FileBuffer);return NDXERR_NOTRGBPSD;}

	// Skip the Mode Data.  (It's the palette for indexed color; other info for other modes.)
	int	ModeDataCount=PSD_Read32(&ImageInfo);
	if(ModeDataCount)ImageInfo.DataPtr+=ModeDataCount;//fseek(fh,ModeDataCount,SEEK_CUR);

	// Skip the image resources.  (resolution, pen tool paths, etc)
	int	ResourceDataCount=PSD_Read32(&ImageInfo);
	if(ResourceDataCount)ImageInfo.DataPtr+=ResourceDataCount;//fseek(fh,ResourceDataCount,SEEK_CUR);

	// Skip the reserved data.
	int	ReservedDataCount=PSD_Read32(&ImageInfo);
	if(ReservedDataCount)ImageInfo.DataPtr+=ReservedDataCount;//fseek(fh,ReservedDataCount,SEEK_CUR);

	// Find out if the data is compressed.
	// Known values:
	//   0: no compression
	//   1: RLE compressed
	ImageInfo.Compression=PSD_Read16(&ImageInfo);
	if(ImageInfo.Compression>1){free(FileBuffer.FileBuffer);return NDXERR_NOTPSD;}

	if(Surface==NULL&&ParentScreen!=NULL)Create(ParentScreen,type,ImageInfo.Width,ImageInfo.Height);

	ImageInfo.Pixels=(PSDInfo::Pixel*)malloc(4*ImageInfo.Height*ImageInfo.Width);
	UnpackPSD(&ImageInfo);
	DrawPSD_24_X(Xpos,Ypos,&ImageInfo);

	if(UseAlpha)
	{
		if(AlphaMask==NULL)CreateAlpha();
		RECT area={Xpos,Ypos,Xpos+ImageInfo.Width,Ypos+ImageInfo.Height};
		if(area.top<0)area.top=0;
		if(area.left<0)area.left=0;
		if(area.right>Width)area.right=Width;
		if(area.bottom>Height)area.bottom=Height;
		for(int x=area.left;x<area.right;x++)
		for(int y=area.top;y<area.bottom;y++)
		{
			AlphaMask->Alpha[y*Width+x]=ImageInfo.Pixels[(x-area.left)+(y-area.top)*ImageInfo.Width].Channel[3];
		}
	}
	free(ImageInfo.Pixels);
	free(FileBuffer.FileBuffer);
	return NDXERR_OK;
}

NDXERR NDX_Surface::UnpackPSD(PSDInfo * ImageInfo)
{
	int Default[4]={0,0,0,255};
	int chn[4]={2,1,0,3};
	int PixelCount=ImageInfo->Width*ImageInfo->Height;
	if(ImageInfo->Compression)
	{
		ImageInfo->DataPtr+=ImageInfo->Height*ImageInfo->ChannelCount*2;
		for(int c=0;c<4;c++)
		{
			int pn=0;
			int channel=chn[c];
			if(channel>=ImageInfo->ChannelCount)
			{
				for(pn=0;pn<PixelCount;pn++)
				{
					ImageInfo->Pixels[pn].Channel[channel]=Default[channel];
				}
			}else
			{
				int	count=0;
				while(count<PixelCount)
				{
					int	len=*ImageInfo->DataPtr++;
					if(len==128)
					{
					} else if(len<128)
					{
						len++;
						count+=len;
						while(len)
						{
							ImageInfo->Pixels[pn].Channel[channel]=*ImageInfo->DataPtr++;pn++;
							len--;
						}
					}else if(len>128)
					{
						len^=0x0FF;
						len+=2;
						unsigned char val=*ImageInfo->DataPtr++;
						count+=len;
						while(len)
						{
							ImageInfo->Pixels[pn].Channel[channel]=val;pn++;
							len--;
						}
					}
				}
			}
		}

	}else
	{
		for(int c=0;c<4;c++)
		{
			int channel=chn[c];
			if (channel>ImageInfo->ChannelCount)
			{
				for(int pn=0;pn<PixelCount;pn++)
				{
					ImageInfo->Pixels[pn].Channel[channel]=Default[channel];
				}
			} else {
				for(int n=0;n<PixelCount;n++)
				{
					ImageInfo->Pixels[n].Channel[channel]=*ImageInfo->DataPtr++;
				}
			}
		}
	}
	return NDXERR_OK;
}


NDXERR NDX_Surface::FormattedText(int Xpos,int Ypos,DWORD Color,HFONT Font,LPSTR format,...)
{
	va_list ap;
	char txt[2048];

	va_start(ap,format);
	vsprintf(txt,format,ap);
	va_end(ap);

	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,TRANSPARENT);
	SetTextColor(hdc,Color);
	if(Font!=NULL)SelectObject(hdc,Font);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));
	if(!Lo)UnlockDC();
	return NDXERR_OK;
}

NDXERR NDX_Surface::FormattedText_OutLine(int Xpos,int Ypos,DWORD Color,DWORD OutLineColor,HFONT Font,LPSTR format,...)
{
	va_list ap;
	char txt[2048];

	va_start(ap,format);
	vsprintf(txt,format,ap);
	va_end(ap);

	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,TRANSPARENT);
	if(Font!=NULL)SelectObject(hdc,Font);

	SetTextColor(hdc,OutLineColor);
	TextOut(hdc,Xpos-1,Ypos,txt,strlen(txt));
	TextOut(hdc,Xpos+1,Ypos,txt,strlen(txt));
	TextOut(hdc,Xpos,Ypos-1,txt,strlen(txt));
	TextOut(hdc,Xpos,Ypos+1,txt,strlen(txt));
	SetTextColor(hdc,Color);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));

	if(!Lo)UnlockDC();
	return NDXERR_OK;
}

NDXERR NDX_Surface::FormattedText(int Xpos,int Ypos,DWORD Color,DWORD BackColor,HFONT Font,LPSTR format,...)
{
	va_list ap;
	char txt[2048];

	va_start(ap,format);
	vsprintf(txt,format,ap);
	va_end(ap);

	bool Lo=bool(LockedDC);
	if(!Lo)LockDC();
	SetBkMode(hdc,OPAQUE);
	SetTextColor(hdc,Color);
	SetBkColor(hdc,BackColor);
	if(Font!=NULL)SelectObject(hdc,Font);
	TextOut(hdc,Xpos,Ypos,txt,strlen(txt));
	if(!Lo)UnlockDC();
	return NDXERR_OK;
}


//
///EOF
