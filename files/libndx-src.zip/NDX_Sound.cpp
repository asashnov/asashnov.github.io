//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Sound.cpp: implementation of the NDX_Sound class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Sound::NDX_Sound()
{
	lpDS=NULL;
}

NDX_Sound::~NDX_Sound()
{
	RELEASE(lpDS);
}

NDXERR NDX_Sound::Create(HWND hwnd)
{
	if(DirectSoundCreate(NULL,&lpDS,NULL)!=DS_OK)
	{
		lpDS=NULL;
		return NDXERR_DSOUNDCREATE;
	}
	if(lpDS->SetCooperativeLevel(hwnd,DSSCL_NORMAL)!=DS_OK)
	{
		RELEASE(lpDS);
		return NDXERR_DSOUNDSETCOOP;
	}
	return NDXERR_OK;
}

//
///EOF
