//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Palette.cpp: implementation of the NDX_Palette class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Palette::NDX_Palette()
{
	ddpal=NULL;
	Palette=NULL;
	ALU_ToRGB=NULL;
	ALU_ToIndex=NULL;
	LookUp=NULL;
	hpal=NULL;
}

NDX_Palette::~NDX_Palette()
{
	RELEASE(ddpal);
	FREE(Palette);
	FREE(ALU_ToRGB);
	FREE(ALU_ToIndex);
	FREE(LookUp);
	DELOBJ(hpal);
}

NDXERR NDX_Palette::Init(NDX_Screen *ParentScreen, bool _Allow256)
{
	Screen=ParentScreen;
	RELEASE(ddpal);
	FREE(Palette);
	DELOBJ(hpal);
	Palette=(LPPALETTEENTRY)malloc(sizeof(PALETTEENTRY)*256);
	ZeroMemory(Palette,sizeof(PALETTEENTRY)*256);
	if(_Allow256)Allow256=DDPCAPS_ALLOW256;else Allow256=0;
	if(FAILED(Screen->lpDD->CreatePalette(DDPCAPS_8BIT|Allow256,Palette,&ddpal,NULL)))return NDXERR_CPAL;
/*
		LOGPALETTE LogPalette;
		LogPalette.palVersion=0x300;
		LogPalette.palNumEntries=1;
		hpal=CreatePalette(&LogPalette);
		if(hpal==NULL)return NDXERR_CPAL;
		if(SetPaletteEntries(hpal,0,256,Palette)==0)return NDXERR_CPAL;
*/
	return NDXERR_OK;
}

NDXERR NDX_Palette::SetPalette()
{
	NDXERR rval;
	if(Screen->Primary->Surface!=NULL)
	{
		rval=Screen->Primary->SetPalette(this);
		if(rval!=NDXERR_OK)return rval;
	}
	if(Screen->Back->Surface!=NULL)
	{
		rval=Screen->Back->SetPalette(this);
		if(rval!=NDXERR_OK)return rval;
	}
	return NDXERR_OK;
}

void NDX_Palette::SetColor(int Index, DWORD Red, DWORD Green, DWORD Blue)
{
	Palette[Index].peRed=BYTE(Red);
	Palette[Index].peGreen=BYTE(Green);
	Palette[Index].peBlue=BYTE(Blue);
}

DWORD NDX_Palette::IndexToPixelFormat(int Index)
{
	return Screen->PixelFormat->Rgb(Palette[Index].peRed,Palette[Index].peGreen,Palette[Index].peBlue);
}

DWORD NDX_Palette::IndexToRGB(int Index)
{
	return RGB(Palette[Index].peRed,Palette[Index].peGreen,Palette[Index].peBlue);
}

int NDX_Palette::PixelFormatToIndex(DWORD Color)
{
	int Red=Screen->PixelFormat->GetRed(Color);
	int Green=Screen->PixelFormat->GetGreen(Color);
	int Blue=Screen->PixelFormat->GetBlue(Color);
	int cdif=768;
	int fc=0;
	for(int c=0;c<256;c++)
	{
	   int dif=abs(Red-Palette[c].peRed)+abs(Green-Palette[c].peGreen)+abs(Blue-Palette[c].peBlue);
	   if(dif==0)return c;
	   if(dif<cdif)
	   {
		  cdif=dif;
		  fc=c;
	   }
	}
	return fc;
}

int NDX_Palette::RGBToIndex(DWORD Red, DWORD Green, DWORD Blue)
{
	int cdif=768;
	int fc=0;
	for(int c=0;c<256;c++)
	{
	   int dif=abs(Red-Palette[c].peRed)+abs(Green-Palette[c].peGreen)+abs(Blue-Palette[c].peBlue);
	   if(dif==0)return c;
	   if(dif<cdif)
	   {
		  cdif=dif;
		  fc=c;
	   }
	}
	return fc;
}

void NDX_Palette::LoadACTPalette(NF_FileBuffer FileBuffer)
{
	unsigned char *TempPal=FileBuffer.FileBuffer;
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=TempPal[n*3+0];
		Palette[n].peGreen=TempPal[n*3+1];
		Palette[n].peBlue=TempPal[n*3+2];
	}
}

void NDX_Palette::LoadACTPalette(FILE * fh)
{
	unsigned char TempPal[256][3];
	fread(&TempPal,768,1,fh);
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=TempPal[n][0];
		Palette[n].peGreen=TempPal[n][1];
		Palette[n].peBlue=TempPal[n][2];
	}
}

void NDX_Palette::LoadACTPalette(LPSTR filename)
{
	FILE *fh;
	fh=fopen(filename,"rb");
	LoadACTPalette(fh);
	fclose(fh);
}

void NDX_Palette::LoadBMPPalette(NF_FileBuffer FileBuffer)
{
	RGBQUAD *BMPPalette=(RGBQUAD*)(char*)((char*)FileBuffer.FileBuffer+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=BMPPalette[n].rgbRed;
		Palette[n].peGreen=BMPPalette[n].rgbGreen;
		Palette[n].peBlue=BMPPalette[n].rgbBlue;
	}
}

void NDX_Palette::LoadBMPPalette(FILE * fh)
{
	RGBQUAD BMPPalette[256];
	fseek(fh,sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER),SEEK_CUR);
	fread(&BMPPalette,1024,1,fh);
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=BMPPalette[n].rgbRed;
		Palette[n].peGreen=BMPPalette[n].rgbGreen;
		Palette[n].peBlue=BMPPalette[n].rgbBlue;
	}
}

void NDX_Palette::LoadBMPPalette(LPSTR filename)
{
	FILE *fh=fopen(filename,"rb");
	LoadBMPPalette(fh);
	fclose(fh);
}

void NDX_Palette::LoadPCXPalette(NF_FileBuffer FileBuffer)
{
	unsigned char *TempPal=FileBuffer.FileBuffer+FileBuffer.Size-768;
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=TempPal[n*3+0];
		Palette[n].peGreen=TempPal[n*3+1];
		Palette[n].peBlue=TempPal[n*3+2];
	}
}

void NDX_Palette::LoadPCXPalette(FILE * fh,int FileSize)
{
	fseek(fh,FileSize-768,SEEK_CUR);
	unsigned char TempPal[256][3];
	fread(&TempPal,768,1,fh);
	for(int n=0;n<256;n++)
	{
		Palette[n].peRed=TempPal[n][0];
		Palette[n].peGreen=TempPal[n][1];
		Palette[n].peBlue=TempPal[n][2];
	}
}

void NDX_Palette::LoadPCXPalette(LPSTR filename)
{
    FILE *fh;
    fh=fopen(filename,"rb");
    LoadPCXPalette(fh,NDX_FileSize(fh));
    fclose(fh);
}

NDXERR NDX_Palette::CreateAlphaLookUp()
{
	if(ddpal==NULL||Palette==NULL)return NDXERR_NCPAL;
	FREE(ALU_ToRGB);
	FREE(ALU_ToIndex);
	ALU_ToRGB=(unsigned short*)malloc(sizeof(unsigned short)*32*256);
	ALU_ToIndex=(unsigned char*)malloc(sizeof(unsigned char)*32*32*32);
	for(int n=0;n<256;n++)
	{
		for(int a=0;a<32;a++)
		{
			ALU_ToRGB[(a<<8)+n]=(((Palette[n].peRed*a/31)>>3)<<10)|(((Palette[n].peGreen*a/31)>>3)<<5)|((Palette[n].peBlue*a/31)>>3);
		}
	}
	for(int r=0;r<32;r++)
	for(int g=0;g<32;g++)
	for(int b=0;b<32;b++)
	{
		ALU_ToIndex[(r<<10)|(g<<5)|b]=RGBToIndex(r<<3,g<<3,b<<3);
	}
	return NDXERR_OK;
}

NDXERR NDX_Palette::UpdateColors()
{
	if(ddpal==NULL||Palette==NULL)return NDXERR_NCPAL;
	if(ddpal->SetEntries(0,0,256,Palette)!=DD_OK)return NDXERR_SETPAL;
	if(hpal!=NULL)if(SetPaletteEntries(hpal,0,256,Palette)==0)return NDXERR_SETPAL;
	return NDXERR_OK;
}

NDXERR NDX_Palette::UpdateColors(int Intensity)
{
	if(ddpal==NULL||Palette==NULL)return NDXERR_NCPAL;
	PALETTEENTRY TempPalette[256];
	for(int n=0;n<256;n++)
	{
		int Red=Palette[n].peRed*Intensity/255;
		if(Red>255)Red=255;
		TempPalette[n].peRed=Red;
		int Green=Palette[n].peGreen*Intensity/255;
		if(Green>255)Green=255;
		TempPalette[n].peGreen=Green;
		int Blue=Palette[n].peBlue*Intensity/255;
		if(Blue>255)Blue=255;
		TempPalette[n].peBlue=Blue;
	}
	if(ddpal->SetEntries(0,0,256,TempPalette)!=DD_OK)return NDXERR_SETPAL;
	if(hpal!=NULL)if(SetPaletteEntries(hpal,0,256,Palette)==0)return NDXERR_SETPAL;
	return NDXERR_OK;
}

NDXERR NDX_Palette::FadeOut(int Delay)
{
	if(ddpal==NULL||Palette==NULL)return NDXERR_NCPAL;
	for(int n=255;n>=0;n--)
	{
		UpdateColors(n);
		Sleep(Delay);
	}
	return NDXERR_OK;
}

NDXERR NDX_Palette::FadeIn(int Delay)
{
	if(ddpal==NULL||Palette==NULL)return NDXERR_NCPAL;
	for(int n=0;n<256;n++)
	{
		UpdateColors(n);
		Sleep(Delay);
	}
	return NDXERR_OK;
}

NDXERR NDX_Palette::CreateLUT()
{
	if(Screen->PixelFormat->BitCount>8)
	{
		if(LookUp==NULL)LookUp=(DWORD*)malloc(sizeof(DWORD)*256);
		for(int n=0;n<256;n++)
		{
			LookUp[n]=IndexToPixelFormat(n);
		}
	}
	return NDXERR_OK;
}

//
///EOF