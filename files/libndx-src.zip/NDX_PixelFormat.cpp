//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_PixelFormat.cpp: implementation of the NDX_PixelFormat class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int NDX_PixelFormat::FindBase(DWORD Mask)
{
	for(int n=0;n<32;n++)
	{
		if((Mask>>n)&1)return n;
	}
	return 0;
}

int NDX_PixelFormat::FindBitCount(DWORD Mask)
{
	int BitCount=0;
	for(int n=0;n<32;n++)
	{
		if((Mask>>n)&1)BitCount++;
	}
	return BitCount;
}

NDX_PixelFormat::NDX_PixelFormat()
{
	BitCount=0;
}

NDX_PixelFormat::~NDX_PixelFormat()
{

}

void NDX_PixelFormat::Create(NDX_Surface * Surface)
{
	DDPIXELFORMAT ddpf;
	ZeroMemory(&ddpf,sizeof(ddpf));
	ddpf.dwSize=sizeof(ddpf);
	Surface->Surface->GetPixelFormat(&ddpf);
	BitCount=ddpf.dwRGBBitCount;
	if(BitCount>8)
	{
		RedMask=ddpf.dwRBitMask;
		GreenMask=ddpf.dwGBitMask;
		BlueMask=ddpf.dwBBitMask;
		RedBase=FindBase(RedMask);
		GreenBase=FindBase(GreenMask);
		BlueBase=FindBase(BlueMask);
		RedMissingBits=8-FindBitCount(RedMask);
		GreenMissingBits=8-FindBitCount(GreenMask);
		BlueMissingBits=8-FindBitCount(BlueMask);
		PF=NDXPF_UNKNOWN;
		if(RedMask==31744&&GreenMask==992&&BlueMask==31)PF=NDXPF_555;
		if(RedMask==63488&&GreenMask==2016&&BlueMask==31)PF=NDXPF_565;
		if(RedMask==16711680&&GreenMask==65280&&BlueMask==255)PF=NDXPF_RGB;
	}}

    //
    ///EOF
