//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Video.cpp: implementation of the NDX_Video class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool NDX_Video::OpenMMStream(const char * pszFileName, IDirectDraw *pDD, IMultiMediaStream **ppMMStream)
{
    IAMMultiMediaStream *pAMStream;
    CoCreateInstance(CLSID_AMMultiMediaStream, NULL, CLSCTX_INPROC_SERVER,IID_IAMMultiMediaStream, (void **)&pAMStream);
    pAMStream->Initialize(STREAMTYPE_READ, 0, NULL);
    pAMStream->AddMediaStream(pDD, &MSPID_PrimaryVideo, 0, NULL);
    pAMStream->AddMediaStream(NULL, &MSPID_PrimaryAudio, AMMSF_ADDDEFAULTRENDERER, NULL);
    WCHAR wPath[MAX_PATH];
    MultiByteToWideChar(CP_ACP,0,pszFileName,-1,wPath,sizeof(wPath)/sizeof(wPath[0]));
    pAMStream->OpenFile(wPath, 0);
    *ppMMStream=pAMStream;
	return true;
}

void NDX_Video::StreamMedia(NDX_Surface *dest,LPSTR filename,RECT dstarea)
{
	OpenMedia(dest->Screen,filename);
	do
	{
		UpdateMedia();
		if(Playing)DrawMedia(dest,dstarea);
	}while(Playing);
}

void NDX_Video::OpenMedia(NDX_Screen *ParentScreen,LPSTR filename)
{
	CloseMedia();
	ParentScreen->lpDD->QueryInterface(IID_IDirectDraw,(void**)&lpDD);
	if(OpenMMStream(filename,lpDD,&pMMStream))
	{
		pMMStream->GetMediaStream(MSPID_PrimaryVideo, &pPrimaryVidStream);
		pPrimaryVidStream->QueryInterface(IID_IDirectDrawMediaStream,(void **)&pDDStream);
 		pDDStream->CreateSample(NULL,NULL,0,&pSample);
		pSample->GetSurface(&pSurface,&rect);
		pSurface->QueryInterface(IID_IDirectDrawSurface4,(void**)&pSurface4);
		if(pSurface4==NULL)goto Exit;
		MediaOpen=true;
	}
	else
	{
		Exit:;
		CloseMedia();
	}
}

void NDX_Video::CloseMedia()
{
	RELEASE(pPrimaryVidStream);
	RELEASE(pDDStream);
	RELEASE(pSample);
	RELEASE(pSurface);
	RELEASE(pSurface4);
	RELEASE(pMMStream);
	RELEASE(lpDD);
	MediaOpen=false;
	Playing=false;
}

NDX_Video::NDX_Video()
{
	pPrimaryVidStream=NULL;
	pDDStream=NULL;
	pSample=NULL;
	pSurface=NULL;
	pSurface4=NULL;
	pMMStream=NULL;
	lpDD=NULL;
	MediaOpen=false;
	Playing=false;
	CoInitialize(NULL);
}

NDX_Video::~NDX_Video()
{
	CloseMedia();
	CoUninitialize();
}

void NDX_Video::UpdateMedia()
{
	if(!MediaOpen)return;
	if(pSample->Update(0,NULL,NULL,0)!=S_OK)Playing=false;
}

void NDX_Video::DrawMedia(NDX_Surface *dest,RECT destarea)
{
	if(!MediaOpen)return;
	if(dest->Screen->PixelFormat->BitCount!=8)
	{
		dest->Surface->Blt(&destarea, pSurface4, &rect, DDBLT_WAIT, NULL);
		return;
	}
	HDC src;
	pSurface->GetDC(&src);
	dest->LockDC();
	StretchBlt(dest->hdc,destarea.left,destarea.top,destarea.right,destarea.bottom,src,rect.left,rect.top,rect.right,rect.bottom,SRCCOPY);
	dest->UnlockDC();
	pSurface->ReleaseDC(src);
}

void NDX_Video::Start()
{
	if(!MediaOpen)return;
	pMMStream->Seek(0);
	pMMStream->SetState(STREAMSTATE_RUN);
	Playing=true;
}

void NDX_Video::Stop()
{
	if(!MediaOpen)return;
	pMMStream->SetState(STREAMSTATE_STOP);
	Playing=false;
}

//
///EOF
