//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Sample.cpp: implementation of the NDX_Sample class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Sample::NDX_Sample()
{
	lpDSBuf=NULL;
	DataBuffer=NULL;
	Sound=NULL;
}

NDX_Sample::~NDX_Sample()
{
	if(lpDSBuf!=NULL)
	{
		for(int n=0;n<bufCount;n++)
		{
			lpDSBuf[n]->Release();
		}
		free(lpDSBuf);
	}
	FREE(DataBuffer);
}

bool NDX_UnpackWAVChunk(void * pRiffBytes, LPWAVEFORMATEX *lpwfmx,LPBYTE *lpChunkData,DWORD *lpCkSize)
{
	DWORD *dwChunkBitsPtr; // Current data reference
	DWORD *dwChunkTailPtr; // Pointer to end of chunk
	DWORD dwChunkID; // Four-byte chunk id
	DWORD dwType; // Form type
	DWORD dwLength; // Size of data in chunk
	// Initialize lpwfmx pointer
	if(lpwfmx) *lpwfmx=NULL;
	// Initialize data pointer
	if(lpChunkData) *lpChunkData=NULL;
	// Initialize ckSize pointer
	if(lpCkSize) *lpCkSize=NULL;
	// Reference the WAVE in memory pointer
	dwChunkBitsPtr=(DWORD*)pRiffBytes;
	// Unpack chunk id
	dwChunkID=*dwChunkBitsPtr++;
	// Unpack size field
	dwLength=*dwChunkBitsPtr++;
	// Unpack form type
	dwType=*dwChunkBitsPtr++;
	// Check for RIFF id
	if(dwChunkID!=mmioFOURCC('R','I','F','F'))return false;
	// Check for WAVE id (Remember : IFF files can be any type)
	if(dwType!=mmioFOURCC('W','A','V','E'))return false;
	// Set chunk tail pointer
	dwChunkTailPtr=(DWORD*)((BYTE*)dwChunkBitsPtr+dwLength-4);
	// Eternal loop (Well, almost:)
	while(true)
	{
		// Unpack the form type
		dwType=*dwChunkBitsPtr++;
		// Unpack the size
		dwLength=*dwChunkBitsPtr++;
		// Check for data or format block
		switch(dwType)
		{
			case mmioFOURCC('f','m','t',' '):
				if(lpwfmx&&!*lpwfmx)
				{
					// Is it wave?
					if(dwLength<sizeof(WAVEFORMAT))return false;
					// Process it
					*lpwfmx=(LPWAVEFORMATEX)dwChunkBitsPtr;
					if((!lpChunkData||*lpChunkData) && (!lpCkSize||*lpCkSize))return true;
				}
				break;
			case mmioFOURCC('d','a','t','a'):
				if((lpChunkData&&!*lpChunkData) || (lpCkSize&&!*lpCkSize))
				{
					if(lpChunkData) *lpChunkData=(LPBYTE)dwChunkBitsPtr;
					if(lpCkSize) *lpCkSize=dwLength;
					if(!lpwfmx||*lpwfmx)return true;
				}
				break;
		}
		dwChunkBitsPtr=(DWORD*)((BYTE*)dwChunkBitsPtr+((dwLength+1)&~1));
		if(dwChunkBitsPtr>=dwChunkTailPtr)break;
	}
	return true;
}

NDXERR NDX_Sample::LoadWAV(NDX_Sound *Parent, unsigned char * RawData, int NumBuffers, int FileSize)
{
	Sound=Parent;
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	FREE(DataBuffer);
	DataBuffer=(unsigned char*)malloc(FileSize);
	memcpy(DataBuffer,RawData,FileSize);
	DSBUFFERDESC dsbd;
	bufCount=NumBuffers;
	if(bufCount<1)bufCount=1;
	if(Sound->lpDS==NULL)return NDXERR_CREATESB;
	if(lpDSBuf!=NULL)
	{
		for(int n=0;n<bufCount;n++)
		{
			lpDSBuf[n]->Release();
		}
		free(lpDSBuf);
	}
	lpDSBuf=(LPDIRECTSOUNDBUFFER*)malloc(sizeof(LPDIRECTSOUNDBUFFER)*bufCount);
	if(!NDX_UnpackWAVChunk(DataBuffer,&lpwfmx,&lpWAVData,&dwWAVSize))return NDXERR_SAMPLEUNP;
	ZeroMemory(&dsbd,sizeof(DSBUFFERDESC));
	dsbd.lpwfxFormat=lpwfmx;
	dsbd.dwBufferBytes=dwWAVSize;
	dsbd.dwSize=sizeof(dsbd);
	dsbd.dwFlags=DSBCAPS_STATIC;
	if(Sound->lpDS->CreateSoundBuffer(&dsbd,&lpDSBuf[0],NULL)==DS_OK)
	{
		if(!WriteWAVData(lpDSBuf[0]))
		{
			lpDSBuf[0]->Release();
			return NDXERR_WRITEWAVDATA;
		}
	}else return NDXERR_CREATESB;
	for(int i=1;i<bufCount;i++)
	{
		if(Sound->lpDS->DuplicateSoundBuffer(lpDSBuf[0],lpDSBuf+i)!=DS_OK)return NDXERR_CREATESB;
	}
	return NDXERR_OK;
}

NDXERR NDX_Sample::LoadWAV(NDX_Sound *Parent, NF_FileBuffer FileBuffer, int NumBuffers)
{
	int FileSize=FileBuffer.Size;
	Sound=Parent;
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	unsigned char *RawData=(unsigned char*)FileBuffer.FileBuffer;
	if(RawData==NULL)return NDXERR_OUTOFMEM;
	NDXERR rval=LoadWAV(Parent,RawData,NumBuffers,FileSize);
	free(RawData);
	if(rval!=NDXERR_OK)return rval;
	return NDXERR_OK;
}

NDXERR NDX_Sample::LoadWAV(NDX_Sound *Parent, FILE * fh, int NumBuffers, int FileSize)
{
	Sound=Parent;
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	unsigned char *RawData=(unsigned char*)malloc(FileSize);
	if(RawData==NULL)return NDXERR_OUTOFMEM;
	fread(RawData,FileSize,1,fh);
	NDXERR rval=LoadWAV(Parent,RawData,NumBuffers,FileSize);
	free(RawData);
	if(rval!=NDXERR_OK)return rval;
	return NDXERR_OK;
}

NDXERR NDX_Sample::LoadWAV(NDX_Sound *Parent, LPSTR filename, int NumBuffers)
{
	Sound=Parent;
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	FILE *fh=fopen(filename,"rb");
	if(!fh)return NDXERR_BADFILE;
	NDXERR rval=LoadWAV(Parent,fh,NumBuffers,NDX_FileSize(fh));
	if(rval!=NDXERR_OK)return rval;
	fclose(fh);
	return NDXERR_OK;
}

int NDX_Sample::GetAvailBuf()
{
	DWORD Status;
	for(int n=0;n<bufCount;n++)
	{
		lpDSBuf[n]->GetStatus(&Status);
		if(Status==DSBSTATUS_BUFFERLOST)
		{
			lpDSBuf[n]->Restore();
			WriteWAVData(lpDSBuf[n]);
		}
		if(!Status&DSBSTATUS_PLAYING)
		{
			return n;
		}
	}
	return -1;
}

NDXERR NDX_Sample::Play(int Volume, int *Handle)
{
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	int BufferNumber=GetAvailBuf();
	if(BufferNumber<0)return NDXERR_NOAVAILBUF;
	LPDIRECTSOUNDBUFFER lpDSBuffer=lpDSBuf[BufferNumber];
	lpDSBuffer->SetVolume(Volume);  // ��� ������������� �������� � � ���� �� ��� ������-�� �� ��� �� ���� ������ ���������.
	if(lpDSBuffer->Play(0,0,0)!=DS_OK)return NDXERR_CANTPLAY;
	if(Handle!=NULL)*Handle=BufferNumber;
	return NDXERR_OK;
}


NDXERR NDX_Sample::Play_Finish(int Volume)
{
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	int BufferNumber=GetAvailBuf();
	if(BufferNumber<0)return NDXERR_NOAVAILBUF;
	LPDIRECTSOUNDBUFFER lpDSBuffer=lpDSBuf[BufferNumber];
	if(lpDSBuffer->SetVolume(Volume)!=DS_OK)return NDXERR_SETVOLUME;
	if(lpDSBuffer->Play(0,0,0)!=DS_OK)return NDXERR_CANTPLAY;
	while(IsPlaying(BufferNumber)){};
	return NDXERR_OK;
}

bool NDX_Sample::WriteWAVData(LPDIRECTSOUNDBUFFER lpDSB)
{
	if(lpDSB&&lpWAVData&&dwWAVSize)
	{
		LPVOID lpAudioPtr1,lpAudioPtr2;
		DWORD dwAudioBytes1,dwAudioBytes2;
		if(lpDSB->Lock(0,dwWAVSize,&lpAudioPtr1,&dwAudioBytes1,&lpAudioPtr2,&dwAudioBytes2,0)==DS_OK)
		{
			CopyMemory(lpAudioPtr1,lpWAVData,dwAudioBytes1);
			if(dwAudioBytes2!=0)CopyMemory(lpAudioPtr2,lpWAVData+dwAudioBytes1,dwAudioBytes2);
			lpDSB->Unlock(lpAudioPtr1,dwAudioBytes1,lpAudioPtr2,dwAudioBytes2);
			return true;
		}
	}
	return false;
}

bool NDX_Sample::IsPlaying(int Handle)
{
	if(Sound->lpDS==NULL)return false;
	DWORD Status;
	lpDSBuf[Handle]->GetStatus(&Status);
	if(Status&DSBSTATUS_PLAYING)return true;
	return false;
}

NDXERR NDX_Sample::Stop(int Handle)
{
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	lpDSBuf[Handle]->Stop();
	return NDXERR_OK;
}

NDXERR NDX_Sample::Loop(int Volume, int * Handle)
{
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	int BufferNumber=GetAvailBuf();
	if(BufferNumber<0)return NDXERR_NOAVAILBUF;
	LPDIRECTSOUNDBUFFER lpDSBuffer=lpDSBuf[BufferNumber];
	if(lpDSBuffer->SetVolume(Volume)!=DS_OK)return NDXERR_SETVOLUME;
	if(lpDSBuffer->Play(0,0,DSBPLAY_LOOPING)!=DS_OK)return NDXERR_CANTPLAY;
	if(Handle!=NULL)*Handle=BufferNumber;
	return NDXERR_OK;
}

NDXERR NDX_Sample::StopAll()
{
	if(Sound->lpDS==NULL)return NDXERR_DDSOUNDNC;
	for(int n=0;n<bufCount;n++)
	{
		lpDSBuf[n]->Stop();
	}
	return NDXERR_OK;
}

void NDX_Sample::SetVolume(int Handle, int Volume)
{
	if(Sound->lpDS==NULL)return;
	lpDSBuf[Handle]->SetVolume(Volume);
}

//
///EOF
