//////////////////////////////////////////////////////////////////////////
//
// THE
//     ##   ## ##   ## ##  ## #####
//    #### ## ##   ## ##  ## ##
//   ## #### ##   ## #####  #####
//  ##   ## ##   ## ##  ## ##
// ##   ##  #####  ##  ## #####
//                              LIBRARY
//
//
//////////////////////////////////////////////////////////////////////////
// NDX_Log.cpp: implementation of the NDX_Log class.
//
//////////////////////////////////////////////////////////////////////

// Included for Borland Builder C++
#include <vcl.h>
#include <NukeDX.h>

#pragma hdrstop

#include <time.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NDX_Log::NDX_Log()
{
	FileName=NULL;
	bUseBuffer=false;
	BufferSize=0;
	BufferedText=0;
	Buffer=NULL;
}

NDX_Log::~NDX_Log()
{
	Close();
}

void NDX_Log::Create(LPSTR fn)
{
	FREE(FileName);
	FileName=(LPSTR)malloc(strlen(fn)+1);
	strcpy(FileName,fn);
	FILE *fh=fopen(FileName,"w");
	fclose(fh);
}

void NDX_Log::WriteString(char * format,...)
{
	if(FileName==NULL)return;
	va_list ap;
	char s[2048];
	if(format==NULL)return;
	va_start(ap,format);
	vsprintf(s,format,ap);
	va_end(ap);

	int slen=strlen(s);

	if(bUseBuffer&&BufferedText+slen>=BufferSize)FlushBuffer();
	if(bUseBuffer&&slen<BufferSize)
	{
		strcat(Buffer,s);
		BufferedText+=slen;
	}
	else
	{
		FILE *fh=fopen(FileName,"r+");
		fseek(fh,0,SEEK_END);
		fprintf(fh,s);
		fclose(fh);
	}
}

void NDX_Log::UseBuffer(bool OnOff,int Size)
{
	bUseBuffer=OnOff;
	BufferedText=0;
	if(OnOff)
	{
		if(Size<1)Size=1;
		Buffer=(LPSTR)malloc(Size);
		Buffer[0]=0;
		BufferSize=Size;
	}
	else
	{
		FREE(Buffer);
		BufferSize=0;
	}
}

void NDX_Log::FlushBuffer()
{
	if(FileName==NULL)return;
	FILE *fh=fopen(FileName,"r+");
	fseek(fh,0,SEEK_END);
	fprintf(fh,Buffer);
	fclose(fh);
	Buffer[0]=0;
	BufferedText=0;
}

void NDX_Log::Close()
{
	if(BufferedText>0)FlushBuffer();
	FREE(FileName);
	FREE(Buffer);
}

void NDX_Log::WriteTime(char * format)
{
    // Gate
	if(FileName==NULL)return;
	if(format==NULL)return;

    // Vars and Assignment
    char caBuffer[1048];
    time_t ltime;
    struct tm *today;

//    /* Set time zone from TZ environment variable. If TZ is not set,
//     * the operating system is queried to obtain the default value
//     * for the variable.      */
//    _tzset();

    time( &ltime );

    // Use time structure to build a customized time string.
    today = localtime( &ltime );

    // Use strftime to build a customized time string.
    strftime( caBuffer, sizeof ( caBuffer ), format, today );

    // Now, write it. (:
    WriteString(caBuffer);
}

