//---------------------------------------------------------------------------
#ifndef CLevelH
#define CLevelH

#include <vcl.h>
#pragma hdrstop

#include <NukeDX.h>

extern RECT area;

typedef struct tagLEVELFILEHEADER
{
long int datOffSet;
long int objOffSet;
char bFixedLen, bFixedHgt;
int ItemLen,ItemHgt,HorisItems;
int LevLen, LevHgt;
int KolObj;
char ItemFile[128], ObjectFile[128];
unsigned char encoding,reserv;     //encoding=1  - RLE coding
}LEVELFILEHEADER;

typedef struct tagLEVFILEOBJECT   //������ � ����� ������ ( .lev )
{
DWORD type,param;
int posx,posy;
}LEVFILEOBJECT;

class CLevel
{

public:
    CLevel();
    ~CLevel();

    int KolObj;
    LEVFILEOBJECT *Obj;

    BOOL Load(const char *name);
    void Draw(NDX_Surface * dest, int x, int y, RECT area);
    int GetTile(int x, int y);

    int GetLevLen() {return LevLen;}
    int GetLevHgt() {return LevHgt;}

    int GetTileLen() {return TileLen;}
    int GetTileHgt() {return TileHgt;}

private:
    char* data;
    NDX_Surface TileSurf;
    int TileLen, TileHgt, HorisTile;
    int LevLen, LevHgt;

};

//---------------------------------------------------------------------------
#endif
