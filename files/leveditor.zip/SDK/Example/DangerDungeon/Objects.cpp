//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <NukeDX.h>

#include "Objects.h"

extern NDX_Surface gfxArt;
extern NDX_Screen *NdxScreen;

// ���������� ������� ��������

void Game_Object::Draw()
{
    Frames.Draw(NdxScreen->Back,x ,y, fase );
}


__fastcall GO_Level::GO_Level(char *name)
{
    type=GO_LEVEL;
    if( Level.Load(name) != true )
        MessageBox( Application->Handle, "Erorr load level.", "Level", MB_OK );

}

void GO_Level::Draw()
{
    static RECT area=Rect(0,0,320,240);
    // ����� ������� ���������� ������
    Level.Draw(NdxScreen->Back,x,y,area);
}

void Game_Object::Create(LEVFILEOBJECT *levobj)
{
    x=levobj->posx;
    y=levobj->posy;
    fase=0;
}


GO_Player::GO_Player()
{
    type=GO_PLAYER;
    Frames.AddFrames( &gfxArt, 0,48,  16,16,  3,2 );
}

GO_Enemy1::GO_Enemy1()
{
    type=GO_ENEMY1;
    Frames.AddFrames( &gfxArt, 0,80,  16,16,  3,1 );
}




//---------------------------------------------------------------------------

#pragma package(smart_init)
