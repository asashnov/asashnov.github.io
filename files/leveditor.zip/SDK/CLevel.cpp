//---------------------------------------------------------------------------
#include <vcl.h>

#include <NukeDX.h>
#pragma hdrstop

#include "CLevel.h"

extern NDX_Screen *NdxScreen;

CLevel::CLevel()
{
    data=NULL;
    Obj=NULL;
	KolObj=0;
}

CLevel::~CLevel()
{
    DEL(data);
    DEL(Obj);
}

BOOL CLevel::Load(const char *name)
{
	FILE *fp;
    LEVELFILEHEADER LH;

    fp=fopen(name,"rb");
	if(fp == NULL) return FALSE;

	fread(&LH, sizeof(LEVELFILEHEADER), 1, fp);

    LPSTR tf=LH.ItemFile;

    NDXERR err;
    err=TileSurf.LoadBMP(NdxScreen,NDXST_BESTFIT,tf,true);
	TileSurf.SetColorKey(0);
	TileSurf.SetTransP(true);

    if( err ) return false;

    TileLen=LH.ItemLen;
    TileHgt=LH.ItemHgt;
    HorisTile=LH.HorisItems;

    LevLen=LH.LevLen;
    LevHgt=LH.LevHgt;


	if(data)delete data;
    data=new char[LevLen*LevHgt];
    if(data==NULL)return false;

    fread(data,sizeof(char),LevLen*LevHgt, fp);

// �������� ��������
    KolObj=LH.KolObj;
    if(KolObj)
        {
        Obj=new LEVFILEOBJECT[KolObj];//LEVFILEOBJECT;
        if(Obj==NULL)return false;
        fread(Obj,sizeof(LEVFILEOBJECT),KolObj,fp);
        }

    fclose(fp);
    return true;
}

void CLevel::Draw(NDX_Surface * destsurf, int x, int y, RECT area)
{
int ox=x%TileLen;   //�������� � ������
int oy=y%TileHgt;
int tile_x=x/TileLen;	// ������ ����
int tile_y=y/TileHgt;
int portlen=(area.right-area.left)/TileLen+1;	// ������� ������ ������� � ����
int porthgt=(area.bottom-area.top)/TileHgt+1;


RECT src, dst;


for( int n=0; n<portlen; n++ )
for( int m=0; m<porthgt; m++ )
{

    int tilex=tile_x+n;
    int tiley=tile_y+m;

    if(tilex<0 || tilex>=LevLen || tiley<0 || tiley>=LevHgt) continue;

    int tile=*(data+tiley*LevLen+tilex);

    // ���� Tile 0 - ������ �������, �� ��� ����� ����������
    if(!tile)continue;

    src.left=TileLen*( tile%HorisTile);
    src.top =TileHgt*(tile/HorisTile);
    src.right=src.left+TileLen;
    src.bottom=src.top+TileHgt;

    dst.left=n*TileLen-ox;
    dst.top =m*TileHgt-oy;
    dst.right=dst.left+TileLen;
    dst.bottom=dst.top+TileHgt;


// ��������� �����, ����������� �� ������� area RECT
/*    if(dst.left < area.left)
    {
        dst.left+=ox;
        src.left+=ox;
    }

    if(dst.top < area.top)
    {
        dst.top+=oy;
        src.top+=oy;
    }

    if( (dst.left+TileLen)>area.right )
    src.right=src.left+ox;

    if( (dst.top+TileHgt)>area.bottom )
    src.bottom=src.top+(dst.top+TileHgt)-area.bottom;
*/
    TileSurf.Draw(destsurf,src,dst);

}//end for
}
//--------------------------------------------------------------------------
int CLevel::GetTile(int pixel_x, int pixel_y)
{
    if( pixel_x<0 || pixel_y<0 ) return -1;

	int x=pixel_x/TileLen;
	int y=pixel_y/TileHgt;

	if(x>=0 && x<LevLen && y>=0 && y<LevHgt)
		return *(data+y*LevLen+x);
	else
		return -1; //���� ��� ������

}


//---------------------------------------------------------------------------
