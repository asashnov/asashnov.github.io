//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CSPIN.h"
#include <ActnList.hpp>
#include <ImgList.hpp>
#include "Trayicon.h"
#include <Buttons.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TImageList *ImageList1;
    TActionList *ActionList1;
    TCheckBox *CheckBox1;
    TCSpinEdit *CSpinEdit1;
    TLabel *Label2;
    TTrayIcon *TrayIcon1;
    TAction *RecordAction;
    TAction *StopAction;
    TSpeedButton *SpeedButton1;
    TSpeedButton *SpeedButton2;
    TMemo *Memo1;
    TPopupMenu *PopupMenu1;
    TMenuItem *Starthear1;
    TMenuItem *About1;
    TMenuItem *Exit1;
    TAction *DirSelect;
    TSpeedButton *SpeedButton3;
    TLabel *Label1;
    TLabel *Label3;
    TAction *SelForm;
    TMenuItem *SelectFormat1;
    TMenuItem *N1;
    TMenuItem *Selectdirectory1;
    void __fastcall RecordActionExecute(TObject *Sender);
    void __fastcall StopActionExecute(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall About1Click(TObject *Sender);
    void __fastcall FormPaint(TObject *Sender);
    void __fastcall TrayIcon1Click(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall DirSelectExecute(TObject *Sender);
    void __fastcall SelFormExecute(TObject *Sender);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
private:
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
