//===============================================
//
//	Sample from Choco Snow Creation Site 
//			DirectX Games Programming
//	http://solcities.co.uk/pc/dkcsc
//
//	Written by Mr.Snow: dkcsc@yahoo.com
//		04.08.99
//
//	Contains of "Basics of DirectDraw" Topic
//
//===============================================

#define NAME "SampleApp"
#define TITLE "SampleApp"

#include <windows.h>
#include <ddraw.h>

#pragma comment (lib,"dxguid.lib")
#pragma comment (lib,"ddraw.lib")

typedef struct
{
	LPDIRECTDRAW2			Interface;
	LPDIRECTDRAWSURFACE3	PrimSurf;
	LPDIRECTDRAWSURFACE3	BackSurf;
} DDrawS;

LPDIRECTDRAWSURFACE3	bitmap;

DDrawS ddraw;
HWND hWnd;

#include "res\\resource.h"
#include "ddraws.h"

bool bActive = false;
int x=0, y=0, but = 1;
//==================================================
//
//
//
//==================================================
static void DestroyApp()
{
	if( ddraw.Interface != NULL )
	{
		if( ddraw.BackSurf != NULL )
		{
			ddraw.BackSurf->Release();
			ddraw.BackSurf = NULL;
		};
		if( ddraw.PrimSurf != NULL )
		{
			ddraw.PrimSurf->Release();
			ddraw.PrimSurf = NULL;
		};
		ddraw.Interface->Release();
		ddraw.Interface = NULL;
	};
	PostQuitMessage (0);
};
//==================================================
//
//
//
//==================================================
extern bool DrawScreen (void)
{
	ClearScreen();


	if(but==1)
	{
		RECT sr = {0, 0, 320, 276};
		RECT dr = {x, y, x+320, y+276};
		ddraw.BackSurf->Blt(&dr, bitmap, &sr, DDBLT_WAIT, 0);
	}
	else
		BltSurfXY (x, y, bitmap, ddraw.BackSurf);

	ddraw.PrimSurf->Flip (0, DDFLIP_WAIT);
	return TRUE;
};

//==================================================
//
//
//
//==================================================

LRESULT CALLBACK WindowProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_ACTIVATE:
		bActive = LOWORD(wParam);
		break;

	case WM_DESTROY:
		DestroyApp ();
	    break;
	case WM_RBUTTONDOWN:
		if(but == 0)
			but = 1;
		else but = 0;
		break;
	case WM_MOUSEMOVE:
		x=LOWORD(lParam);
		y=HIWORD(lParam);
		break;
	case WM_SETCURSOR:
		SetCursor (NULL);
		return TRUE;
		break; 
	};

	return DefWindowProc(hWnd, message, wParam, lParam);
};

//==================================================
//
//
//
//==================================================

bool WindowInit (HINSTANCE hThisInst, int nCmdShow)
{
	WNDCLASS		    wcl;
		
	wcl.hInstance = hThisInst;
	wcl.lpszClassName = NAME;
	wcl.lpfnWndProc = WindowProc;
	wcl.style = CS_HREDRAW | CS_VREDRAW;

	wcl.hIcon = LoadIcon (hThisInst, "ICONA");
	wcl.hCursor = LoadCursor (hThisInst, IDC_ARROW);
	wcl.lpszMenuName = NULL;

	wcl.cbClsExtra = 0;
	wcl.cbWndExtra = 0;
	wcl.hbrBackground = 0;

	RegisterClass (&wcl);

	hWnd = CreateWindowEx (
		WS_EX_TOPMOST,
		NAME,
		TITLE,
		WS_POPUP,
		0, 0, 
		640, 480,
		NULL,
		NULL,
		hThisInst,
		NULL);

	if (!hWnd) return FALSE;
	
	return TRUE;
};

//==================================================
//
//
//
//==================================================

bool AppInit (HINSTANCE hThisInst, int nCmdShow)
{
	if(!WindowInit (hThisInst, nCmdShow)) return false;
	
//========================================================================
//	Creating the DirectDraw2 Object
//========================================================================
	DDSURFACEDESC	desc;

	ZeroMemory (&desc, sizeof (desc));
	desc.dwSize = sizeof (desc);
	desc.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	desc.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	desc.dwBackBufferCount = 1;

	DDSCAPS		ddscaps;
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;

	LPDIRECTDRAW		DD_t;
	LPDIRECTDRAWSURFACE	DD_st;

	DirectDrawCreate (0, &DD_t, 0);
	DD_t->QueryInterface (IID_IDirectDraw2, (void **)&ddraw.Interface);

	DD_t->Release();
	DD_t=0;


	ddraw.Interface->SetCooperativeLevel (hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
	ddraw.Interface->SetDisplayMode (640, 480, 16, 0, 0);
//========================================================================
//	Creating PrimSurf, BackSurf
//========================================================================
	ddraw.Interface->CreateSurface (&desc, &DD_st, NULL);
	DD_st->QueryInterface (IID_IDirectDrawSurface3, (void **)&ddraw.PrimSurf);
	ddraw.PrimSurf->GetAttachedSurface (&ddscaps, &ddraw.BackSurf);
	
	DD_st->Release();
	DD_st=0;

	bitmap = LoadBmp ("bmp.bmp", 0,0);
	SetColorKey(bitmap, NULL);

	ShowWindow (hWnd, nCmdShow);
	UpdateWindow (hWnd);

	return TRUE;
};

//==================================================
//
//
//
//==================================================

int WINAPI WinMain (HINSTANCE hThisInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	
	if (!AppInit (hThisInst, nCmdShow)) return FALSE;

	while (1)
	{
		if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage( &msg, NULL, 0, 0))	break;
			TranslateMessage(&msg); 
			DispatchMessage(&msg);
		}
		else 
		{
			if(bActive == true)
			{
				DrawScreen ();
			};
	};	};

	return msg.wParam;
};

//==================================================
//
//
//
//==================================================

