//===============================================
//
//	Sample from Choco Snow Creation Site 
//			DirectX Games Programming
//	http://solcities.co.uk/pc/dkcsc
//
//	Written by Mr.Snow: dkcsc@yahoo.com
//		04.08.99
//
//	Contains of "Basics of DirectDraw" Topic
//
//===============================================


extern "C" IDirectDrawSurface3 * LoadBmp (LPCSTR szBitmap, int dx, int dy);
extern "C" HRESULT CopyBmp (IDirectDrawSurface3 *pdds, HBITMAP hbm, int x, int y, int dx, int dy);
extern "C" DWORD ConvertRGB (IDirectDrawSurface3 *pdds, COLORREF rgb);
extern "C" HRESULT SetColorKey (IDirectDrawSurface3 *pdds, COLORREF rgb);
extern "C" BOOL ClearSurface (IDirectDrawSurface3 *clrsurf, COLORREF rgb);
extern "C" BOOL ClearScreen ();
extern "C" BOOL BltSurfXY (int x, int y, IDirectDrawSurface3 *surf, IDirectDrawSurface3 *dd_t);

//========================================================================
//
//	LoadBmp (IDirectDraw2 *, LPCSTR, int, int)
//		-load the named bitmap
//		-create new surface
//		-copy loaded image to surface
//		-return surface if all was O'k
//
//========================================================================

extern "C" IDirectDrawSurface3 * LoadBmp (LPCSTR szBitmap, int dx, int dy)
{
	HBITMAP             hbm;
	BITMAP              bm;
	DDSURFACEDESC       ddsd;
	LPDIRECTDRAWSURFACE3 pdds;

	hbm = (HBITMAP)LoadImage(GetModuleHandle(NULL), szBitmap, IMAGE_BITMAP, dx, dy, LR_CREATEDIBSECTION);
	if (hbm == NULL) hbm = (HBITMAP)LoadImage(NULL, szBitmap, IMAGE_BITMAP, dx, dy, LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if (hbm == NULL) return NULL;

	GetObject(hbm, sizeof(bm), &bm);

	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth = bm.bmWidth;
	ddsd.dwHeight = bm.bmHeight;

	LPDIRECTDRAWSURFACE lpDDSTemp;
	if (ddraw.Interface->CreateSurface(&ddsd, &lpDDSTemp, NULL) != DD_OK)
	{
		OutputDebugString("CreateSurf failed");
		return NULL;
	};
	if (lpDDSTemp->QueryInterface(IID_IDirectDrawSurface3,(void**)&pdds) != DD_OK)
	{
		OutputDebugString("QueryInterface failed");
		return NULL;
	};
	lpDDSTemp->Release();

	CopyBmp(pdds, hbm, 0, 0, 0, 0);
	DeleteObject(hbm);
	return pdds;
};

//========================================================================
//
//	ReLoadBmp (IDirectDraw2 *, LPCSTR)
//		-ReLoad the named bitmap
//		-copy loaded image to surface
//		-return surface if all was O'k
//
//	use this function after restoring the surface
//
//========================================================================


//========================================================================
//
//	CopyBmp (IDirectDrawSurface3 *, HBITMAP, int, int, int, int)
//		-copy the named image to neede surface
//		-return result of copy
//
//========================================================================

extern "C" HRESULT CopyBmp (IDirectDrawSurface3 *pdds, HBITMAP hbm, int x, int y, int dx, int dy)
{
	HDC                 hdcImage;
	HDC                 hdc;
	BITMAP              bm;
	DDSURFACEDESC       ddsd;
	HRESULT             hr;

	if (hbm == NULL || pdds == NULL) return E_FAIL;
	pdds->Restore();

	hdcImage = CreateCompatibleDC(NULL);
	if (!hdcImage)
	{
		OutputDebugString("createcompatible dc failed\n");
	};
	SelectObject(hdcImage, hbm);

	GetObject(hbm, sizeof(bm), &bm);
	dx = dx == 0 ? bm.bmWidth  : dx;
	dy = dy == 0 ? bm.bmHeight : dy;

	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
	pdds->GetSurfaceDesc(&ddsd);

	if ((hr = pdds->GetDC(&hdc)) == DD_OK)
	{
		StretchBlt(hdc, 0, 0, ddsd.dwWidth, ddsd.dwHeight, hdcImage, x, y, dx, dy, SRCCOPY);
		pdds->ReleaseDC(hdc);
	};

	DeleteDC(hdcImage);

	return hr;
};

//========================================================================
//
//	ConvertRGB (IDirectDrawSurface3 *, COLORREF)
//		-Convert RGB color value to pysical
//		-return pysical value of RGB color
//
//========================================================================

extern "C" DWORD ConvertRGB (IDirectDrawSurface3 *pdds, COLORREF rgb)
{
	COLORREF rgbT;
	HDC hdc;
	DWORD dw = CLR_INVALID;
	DDSURFACEDESC ddsd;
	HRESULT hres;

	if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
	{
		rgbT = GetPixel(hdc, 0, 0);
		SetPixel(hdc, 0, 0, rgb);
		pdds->ReleaseDC(hdc);
	};

	ddsd.dwSize = sizeof(ddsd);
	while ((hres = pdds->Lock(NULL, &ddsd, 0, NULL)) == DDERR_WASSTILLDRAWING);

	if (hres == DD_OK)
	{
		dw  = *(DWORD *)ddsd.lpSurface;
		dw &= (1 << ddsd.ddpfPixelFormat.dwRGBBitCount)-1;
		pdds->Unlock(NULL);
	};

	if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
	{
		SetPixel(hdc, 0, 0, rgbT);
		pdds->ReleaseDC(hdc);
	};

	return dw;
};

//========================================================================
//
//	SetColorKey (IDirectDrawSurface3 *, COLORREF)
//		-set the requested "transparent" color
//		-return result of setting
//
//========================================================================

extern "C" HRESULT SetColorKey (IDirectDrawSurface3 *pdds, COLORREF rgb)
{
	DDCOLORKEY		ddck;

	ddck.dwColorSpaceLowValue  = ConvertRGB (pdds, rgb);
	ddck.dwColorSpaceHighValue = ddck.dwColorSpaceLowValue;
	return pdds->SetColorKey (DDCKEY_SRCBLT, &ddck);
};

//========================================================================
//
//	ClearSurface (IDirectDrawSurface3 *, COLORREF)
//		-cler needed surface by COLORREF color
//		-return true if all was O'k
//
//========================================================================

extern "C" BOOL ClearSurface (IDirectDrawSurface3 *clrsurf, COLORREF rgb)
{
	DDBLTFX bltfx;

	memset(&bltfx,0,sizeof(bltfx));
	bltfx.dwSize = sizeof(bltfx);
	bltfx.dwFillColor = ConvertRGB (clrsurf, rgb);
	clrsurf->Blt(0, 0, 0, DDBLT_COLORFILL | DDBLT_WAIT, &bltfx);
	return true;
};

//========================================================================
//
//	ClearScreen (DDrawS *)
//		-clear App screen by black color
//		-return true if all O'k
//
//========================================================================

extern "C" BOOL ClearScreen ()
{
	if(!ClearSurface (ddraw.BackSurf, 0)) return false;
	return true;
};

extern "C" BOOL BltSurfXY (int x, int y, IDirectDrawSurface3 *surf, IDirectDrawSurface3 *dd_t)
{
	int maxX = 640;
	int maxY = 480;

	DDSURFACEDESC desc2;
	ZeroMemory (&desc2, sizeof(desc2));
	desc2.dwSize = sizeof(desc2);
	surf->GetSurfaceDesc (&desc2);
	RECT srect = {0, 0, desc2.dwWidth, desc2.dwHeight};


	if(x >= maxX) return false;
	if(y >= maxY) return false;
	if(x+srect.right <= 0) return false;
	if(y+srect.bottom <= 0) return false;

	if(x<=0)
	{	
		srect.left = -x;
		x=0;
	};
	if(y<=0)
	{
		srect.top = -y;
		y=0;
	};

	if(x>(maxX-srect.right)) 
		srect.right = maxX - x;

	if(y>(maxY-srect.bottom))
		srect.bottom = maxY - y;

	DWORD flags = DDBLTFAST_WAIT | DDBLTFAST_SRCCOLORKEY;
	dd_t->BltFast(x, y, bitmap, &srect, flags);
	return true;
};
