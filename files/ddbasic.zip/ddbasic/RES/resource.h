//===============================================
//
//	Sample from Choco Snow Creation DirectX
//===============================================
//
//	Sample from Choco Snow Creation Site 
//			DirectX Games Programming
//	http://solcities.co.uk/pc/dkcsc
//
//	Written by Mr.Snow: dkcsc@yahoo.com
//		04.08.99
//
//	Contains of "Basics of DirectDraw" Topic
//
//===============================================

