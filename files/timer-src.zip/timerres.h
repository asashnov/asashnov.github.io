/* Weditres generated include file. Do NOT edit */
#define	IDD_MAINDIALOG	100
#define	ID_MIN_EDIT	101
#define	ID_HOUR_EDIT	102
#define	ID_START_BUT	103
#define	ID_STOP_BUT	104
#define	ID_MIN_UPDOWN	105
#define	ID_HOUR_UPDOWN	106
#define	ID_PROGRESSBAR	107
#define	IDM_PAGESETUP	260
#define	IDM_EXIT	300
#define	IDM_ABOUT	500
#define	IDMAINMENU	600
#define	IDAPPLICON	710
#define	IDAPPLCURSOR	810
#define	IDS_FILEMENU	2000
#define	IDS_HELPMENU	2010
