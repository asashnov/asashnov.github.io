/*@@ Wedit generated application. Written Fri Jun 07 00:16:11 2002
 @@header: c:\temp\timer\timerres.h
 @@resources: c:\temp\timer\timer.rc
 Do not edit outside the indicated areas */
static char *_CMSID = "$CmsFile: TIMER $ $Date:2002.9.5.18.25.39  $";
/*<---------------------------------------------------------------------->*/
/*<---------------------------------------------------------------------->*/
#include <windows.h>
#include <mmsystem.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <stdio.h>
#include "timerres.h"
/* --- The following code comes from c:\lcc\lib\wizard\dlgbased.tpl. */
/*<---------------------------------------------------------------------->*/


int TotalSeconds;
BOOL bShowSecondsDots;

UINT hTimer;  // Timer id

/*
Template for a dialog based application. The main procedure for this
template is the DialogFunc below. Modify it to suit your needs.
*/
/* prototype for the dialog box function. */
static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
/*
Win main just registers a class of the same type that the dialog class, and
then calls DialogBox. Then it exits. The return value is the return value of
the dialog procedure.
*/

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;

	InitCommonControls();

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = DefDlgProc;
	wc.cbWndExtra = DLGWINDOWEXTRA;
	wc.hInstance = hinst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wc.lpszClassName = "timer";
	RegisterClass(&wc);

	return DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

}

/*
You should add your initialization code here. This function will be called
when the dialog box receives the WM_INITDIALOG message.
*/
static int InitializeApp(HWND hDlg,WPARAM wParam, LPARAM lParam)
{
	return 1;
}


int PlayMidi(HWND hDlg, char *name)
{
char buffer[256];

	sprintf(buffer, "open \"%s\" type sequencer alias MUSIC", name);

	if (mciSendString("close all", NULL, 0, NULL) != 0)
	{
		return(FALSE);
	}

	if (mciSendString(buffer, NULL, 0, NULL) != 0)
	{
		return(FALSE);
	}

	if (mciSendString("play MUSIC from 0 notify", NULL, 0, hDlg) != 0)
	{
		return(FALSE);
	}
    return 1;
}



void SetTimeText(HWND hwndDlg)
{

	// ��������� �������� ���� �� �����
	int ts,Hour,Min,Sec;
	char r,buf[20];

	ts = TotalSeconds;
	Hour=ts/3600;

    ts-=Hour*3600;
	Min=ts/60;
    ts-=Min*60;

	Sec=ts;

	// ���������� ������� ����������� (����� ����� ��� ���)
	r=(bShowSecondsDots)? ':' : ' ';

	// ��������� ������
	sprintf(buf,"Timer: %02d%c%02d%c%02d  ",Hour,r,Min,r,Sec);

	// ������������� ��������� ����� � �������
	SetWindowText(hwndDlg,buf);
}


void StartButtonClick(HWND hwndDlg)
{
	char buf[6];
	int char_count;
	int minutes;
	int hours;

	// get Minutes edit text
	char_count = GetDlgItemText(hwndDlg,ID_MIN_EDIT, buf, 3);

	if( char_count == 0 )
	{
		minutes = 0;
	}
	else
		sscanf(buf,"%d",&minutes);

	if( minutes < 0 || minutes > 59 )
	{
		MessageBox(hwndDlg,"Minutes value error!","Timer",MB_OK);
		return;
	}


	// get Hours edit text
	char_count = GetDlgItemText(hwndDlg,ID_HOUR_EDIT, buf, 3);

	if( char_count == 0 )
	{
		hours = 0;
	}
	else
		sscanf(buf,"%d",&hours);

	if( hours < 0 || hours > 59 )
	{
		MessageBox(hwndDlg,"Hours value error!","Timer",MB_OK);
		return;
	}

	if( minutes == 0 && hours == 0 )
	{
		MessageBox(hwndDlg,"You need enter minutes and/or hours value befor pressing start","Timer",MB_OK);
		return;
	}


	TotalSeconds = ( hours*60 + minutes ) *60;

	// set range of progress bar
	SendMessage(GetDlgItem(hwndDlg, ID_PROGRESSBAR), PBM_SETRANGE, 0, MAKELPARAM(0,TotalSeconds));

	// set current position is 0
	SendMessage(GetDlgItem(hwndDlg, ID_PROGRESSBAR), PBM_SETPOS, 0, 0);

	// start timer
	hTimer = SetTimer(hwndDlg, 1, 500, NULL);
}

void StopButtonClick(HWND hwndDlg)
{
	// Stop timer
	KillTimer(hwndDlg, 1);

	SetWindowText(hwndDlg,"Timer: stoped");
}

/*
This is the main function for the dialog. It handles all messages. Do what your
application needs to do here.
*/
static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HWND hwndScrollBar;
	int nScrollCode;
	int value;
	int direction;
	char buf[16];
	int char_count;

	switch (msg) {
	/* This message means the dialog is started but not yet visible.
	   Do All initializations here
        */
	case WM_INITDIALOG:
		InitializeApp(hwndDlg,wParam,lParam);
		return TRUE;
	/* By default, IDOK means close this dialog returning 1, IDCANCEL means
           close this dialog returning zero
        */
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
			case IDOK:
				EndDialog(hwndDlg,1);
				return 1;
			case IDCANCEL:
				EndDialog(hwndDlg,0);
				return 1;
			case ID_START_BUT:
				StartButtonClick(hwndDlg);
				return 1;
			case ID_STOP_BUT:
				StopButtonClick(hwndDlg);
				return 1;
		}
		break;

	case WM_TIMER:
		// timer tick every 1/2 of seconds
		bShowSecondsDots = !bShowSecondsDots;

		if( bShowSecondsDots )
			TotalSeconds--;

		// if time out- alarm
		if( TotalSeconds < 0 )
			{
				// if just time out
				if( TotalSeconds == -1 && bShowSecondsDots )
					{
						// show messagebox
						MessageBox(hwndDlg,"Time out","Timer",MB_OK | MB_ICONWARNING | MB_TOPMOST );
						StopButtonClick(hwndDlg);
						return 1;
					}

				// do alarm signal
				if ( bShowSecondsDots )
    				{
						SetWindowText(hwndDlg,"DIN-DIN");
						PlayMidi(hwndDlg, "r8.mid");
        				MessageBeep(MB_OK);
    				}
    			else
    				{
    					PlayMidi(hwndDlg, "r3.mid");
    					SetWindowText(hwndDlg,"Time out!");
    				}
			}
		// else just show time
		else
			{
				// refresh time information on application title
				SetTimeText(hwndDlg);
				// increate position of progress bar one time per second
				if( bShowSecondsDots )
					SendMessage(GetDlgItem(hwndDlg, ID_PROGRESSBAR), PBM_DELTAPOS, 1, 0);
			}
		return 1;

	// Change minutes and hours values from scrollbars
	case WM_VSCROLL:
		nScrollCode = (int) LOWORD(wParam);
		hwndScrollBar = (HWND) lParam;
		direction = 0;
		value = 0;

		if( nScrollCode == SB_LINEUP )
			direction = 1;

		if( nScrollCode == SB_LINEDOWN )
			direction = -1;

		if( !direction ) return 1;

		// minutes scroll bar
		if( hwndScrollBar  == GetDlgItem(hwndDlg, ID_MIN_UPDOWN))
			{
				char_count = GetDlgItemText(hwndDlg,ID_MIN_EDIT, buf, 3);

				if( char_count == 0 )
					value = 0;
				else
					sscanf(buf,"%d",&value);

				value+=direction;

				if( value >= 0 && value <= 59 )
					{
						sprintf(buf,"%d",value);
						SetDlgItemText(hwndDlg,ID_MIN_EDIT, buf);
					}
			}


		// hours scroll bar
		if( hwndScrollBar == GetDlgItem(hwndDlg, ID_HOUR_UPDOWN))
			{

				char_count = GetDlgItemText(hwndDlg,ID_HOUR_EDIT, buf, 3);

				if( char_count == 0 )
					value = 0;
				else
					sscanf(buf,"%d",&value);

				value+=direction;

				if( value >= 0 && value <= 24 )
					{
						sprintf(buf,"%d",value);
						SetDlgItemText(hwndDlg,ID_HOUR_EDIT, buf);
					}
			}

		return 1;

        /* By default, WM_CLOSE is equivalent to CANCEL */
	case WM_CLOSE:
		EndDialog(hwndDlg,0);
		return TRUE;
	}
	return FALSE;
}
