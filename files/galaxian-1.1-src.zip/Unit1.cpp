//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

#include "debug.h"

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
  FRunApp = True;
  FActive = False;
  lpDD = NULL;
  lpDI=NULL;
  lpDS=NULL;
  lpDIDKeys=NULL;
  lpDIDMouse=NULL;

initdebug("");
}
//---------------------------------------------------------------------------
void UpdateFrame();
//---------------------------------------------------------------------------
MESSAGE void TForm1::MyMove(TMessage &Message)
{
DWORD	lastTickCount;
DWORD	thisTickCount;
  do
  {
    if(FActive)
    {
        thisTickCount = GetTickCount();
        if( thisTickCount - lastTickCount > 40 )
            {
            lastTickCount = thisTickCount;
            UpdateFrame();
            }

        Application->ProcessMessages();
    }
  }
  while(FRunApp == True);
}

// ���������� �����
void TForm1::UpdateFrame()
{
    if( showLevel )
    {
        // ����� ������ ������
        ShowLevel();
        showLevel--;
    }
    else
    if( gameOver )
    {
        // ����� ������� GAMEOVER
        GameOver();
        gameOver--;
        if( !gameOver )
            {
                FRunApp = False;
                FActive = False;
                Close();
            }
    }
    else
    if( youwinDelay )
    {
        // ����� ������� ������
        Youwin();
        if( !--youwinDelay )
            {
                FRunApp = False;
                FActive = False;
                Close();
            }
    }
    else
    {
        UpdateGame();
        CheckForHits();
        DrawGame();
    }

}

void __fastcall TForm1::FormDestroy(TObject *Sender)
{

debugout("Main: FormDestroy");

  if(lpDD != NULL)
  {
    RELEASE(lpGameArt);
    RELEASE(lpFrontBuffer);
    RELEASE(lpDDPal);
    RELEASE(lpDD);
  }

  RELEASE(lpDIDKeys);
  RELEASE(lpDIDMouse);
  RELEASE(lpDI);

  // ����������� DSound
  if(lpDS)
  {
    for(int n=0; n<NUM_DS_BUFFERS; n++)
        RELEASE(lpDSBuffer[n]);
    RELEASE(lpDS);
  }
  StopMidi();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  switch (Key)
  {
    case VK_RETURN:
        if( FActive == True) break;
        if( !InitApp() )
        {
        Application->MessageBox("Game Init Failed","Error",MB_OK);
        }
        else
        {
        Cursor=crNone;
        BorderStyle=bsNone;
        WindowState=wsMaximized;        
        GameInit();     // ����� ����
        FActive = True;
        PostMessage(Handle, WM_INFOSTART, 0, 0);
        }
        break;
    case VK_ESCAPE:
    case VK_F12:
      FRunApp = False;
      FActive = False;
      Close();
      break;
  }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormActivate(TObject *Sender)
{
    if(lpDD != NULL ) // �.�. DDraw ���������������
        FActive=true;
debugout("Main:   FActive=true");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDeactivate(TObject *Sender)
{
    FActive=false;
debugout("Main:   FActive=false");
}
//---------------------------------------------------------------------------

