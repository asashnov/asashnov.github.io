//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <mmsystem.h>
#include <ddraw.h>
#include <dinput.h>
#include <dsound.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
#define WM_INFOSTART WM_USER

#define NUM_DS_BUFFERS 20

#define RELEASE(x) if(x!=NULL){x->Release();x=NULL;}


extern int showLevel;
extern int gameOver;
extern int youwinDelay;

extern LPDIRECTDRAW            lpDD;
extern LPDIRECTDRAWSURFACE     lpFrontBuffer;
extern LPDIRECTDRAWSURFACE     lpBackBuffer;
extern LPDIRECTDRAWSURFACE     lpGameArt;
extern LPDIRECTDRAWPALETTE     lpDDPal;

extern LPDIRECTINPUT lpDI;
extern LPDIRECTINPUTDEVICE lpDIDKeys;
extern LPDIRECTINPUTDEVICE lpDIDMouse;

extern LPDIRECTSOUND lpDS;
extern LPDIRECTSOUNDBUFFER lpDSBuffer[NUM_DS_BUFFERS];


// ���������
extern BOOL InitApp();
extern void InitLevel();
extern void GameInit();
extern void UpdateGame();
extern void CheckForHits();
extern void DrawGame();
extern void ShowLevel();
extern void GameOver();
extern void Youwin();
extern void StopMidi();

class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall FormDeactivate(TObject *Sender);
private:	// User declarations
        MESSAGE void MyMove(TMessage &Message);
        void UpdateFrame();
public:		// User declarations
        BOOL FActive;        // is application active?
        BOOL FRunApp;
        __fastcall TForm1(TComponent* Owner);
BEGIN_MESSAGE_MAP
  MESSAGE_HANDLER(WM_INFOSTART, TMessage, MyMove);
END_MESSAGE_MAP(TForm);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
