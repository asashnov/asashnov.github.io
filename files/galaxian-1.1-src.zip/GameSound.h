//---------------------------------------------------------------------------

#ifndef GameSoundH
#define GameSoundH

#include <mmsystem.h>
#include <dsound.h>

typedef struct _tagwavfiledata
{
    char *data;
    DWORD size;
    WAVEFORMAT form;

}GAMEWAFILE;

void LoadWav(GAMEWAFILE *,char *);

void PlayWav(GAMEWAFILE *, int objx=-300);

int PlayMidi(char *name);
void StopMidi();



//---------------------------------------------------------------------------
#endif

