//---------------------------------------------------------------------------

#ifndef AuthH
#define AuthH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TAuthForm : public TForm
{
__published:	// IDE-managed Components
    TEdit *Edit1;
    TLabel *Label1;
    TLabel *Label2;
    TEdit *Edit2;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
private:	// User declarations
public:		// User declarations
    __fastcall TAuthForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAuthForm *AuthForm;
//---------------------------------------------------------------------------
#endif
