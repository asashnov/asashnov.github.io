//---------------------------------------------------------------------------

#ifndef base64H
#define base64H


char *BASE64_GetDecodedData(char *src);
WORD BASE64_GetLastLength();


//---------------------------------------------------------------------------
#endif
