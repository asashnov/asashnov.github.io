//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("Mailer.res");
USEFORM("Unit1.cpp", MainForm);
USEFORM("Settings.cpp", SettingForm);
USEFORM("NewLetter.cpp", NewForm);
USEUNIT("TMailFolder.cpp");
USEFORM("About.cpp", AboutForm);
USEFORM("Auth.cpp", AuthForm);
USEUNIT("Recode.cpp");
USEUNIT("base64.cpp");
USEFORM("SaveError.cpp", SaveErrorForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->CreateForm(__classid(TMainForm), &MainForm);
         Application->CreateForm(__classid(TSettingForm), &SettingForm);
         Application->CreateForm(__classid(TNewForm), &NewForm);
         Application->CreateForm(__classid(TAboutForm), &AboutForm);
         Application->CreateForm(__classid(TAuthForm), &AuthForm);
         Application->CreateForm(__classid(TSaveErrorForm), &SaveErrorForm);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
