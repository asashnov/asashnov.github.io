//---------------------------------------------------------------------------

#include <vcl.h>
#include <inifiles.hpp>
#pragma hdrstop

#include "TMailFolder.h"
#include "Settings.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSettingForm *SettingForm;
//---------------------------------------------------------------------------
__fastcall TSettingForm::TSettingForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

/*
    ����������� ������������ ����������, �����
    ������ �� ����� �������� ������� � ini-�����

*/
String My_crypt(String s)
{
char result[50];
char *p;
int n;

    if(s=="")return "";

    p=s.c_str();
    for(n=0;n<s.Length();n++)
        *(result+n)=*(p+n) ^ 160;  // ��������� xor

    *(result+n)=0;  // ����� ������
    return result;
}

void __fastcall TSettingForm::Button2Click(TObject *Sender)
{
    FormShow(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TSettingForm::Button1Click(TObject *Sender)
{
    // ���������� �������� � ini �����
TIniFile *ini;
   ini = new TIniFile(
        ChangeFileExt( Application->ExeName, ".INI" ) );

   ini->WriteString ( "General", "YourName", Edit6->Text );
   ini->WriteString ( "General", "ReturnPath", Edit7->Text );

   ini->WriteString ( "SendMail", "SMTP", Edit1->Text );
   ini->WriteString ( "SendMail", "User", Edit10->Text );
   ini->WriteString ( "SendMail", "Port", Edit9->Text );
   ini->WriteInteger( "SendMail", "Encode", ComboBox1->ItemIndex );
   ini->WriteBool   ( "SendMail","Cooperative",CheckBox1->Checked);

   ini->WriteString ( "GetMail", "POP", Edit2->Text );
   ini->WriteString ( "GetMail", "Port", Edit5->Text );
   ini->WriteString ( "GetMail", "Timeout", Edit8->Text );
   ini->WriteString ( "GetMail", "User", Edit3->Text );
   ini->WriteString ( "GetMail", "Passwd", My_crypt(Edit4->Text) );

// ����������� ini ����
   delete ini;

   MainForm->ActionSendAll->Enabled=!CheckBox1->Checked;

}
//---------------------------------------------------------------------------
void __fastcall TSettingForm::FormShow(TObject *Sender)
{
TIniFile *ini;
   ini = new TIniFile(
        ChangeFileExt( Application->ExeName, ".INI" ) );

   Edit6->Text = ini->ReadString( "General", "YourName", "" );
   Edit7->Text = ini->ReadString( "General", "ReturnPath", "" );

   Edit1->Text = ini->ReadString( "SendMail", "SMTP", "" );
   Edit10->Text = ini->ReadString( "SendMail", "User", "" );
   Edit9->Text = ini->ReadString( "SendMail", "Port", "25" );
   ComboBox1->ItemIndex = ini->ReadInteger( "SendMail", "Encode", 0 );
   CheckBox1->Checked=ini->ReadBool( "SendMail","Cooperative",false);

   Edit2->Text = ini->ReadString( "GetMail", "POP", "" );
   Edit5->Text = ini->ReadString( "GetMail", "Port", "110" );
   Edit8->Text = ini->ReadString( "GetMail", "Timeout", "1800000" );
   Edit3->Text = ini->ReadString( "GetMail", "User", "" );
   Edit4->Text = My_crypt(ini->ReadString( "GetMail", "Passwd",""));


// ����������� ini ����
   delete ini;

   MainForm->ActionSendAll->Enabled=!CheckBox1->Checked;
}
//---------------------------------------------------------------------------



