//---------------------------------------------------------------------------

#ifndef SettingsH
#define SettingsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSettingForm : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TGroupBox *GroupBox2;
    TLabel *Label1;
    TLabel *Label2;
    TEdit *Edit2;
    TLabel *Label3;
    TEdit *Edit3;
    TLabel *Label4;
    TEdit *Edit1;
    TGroupBox *GroupBox3;
    TLabel *Label6;
    TEdit *Edit6;
    TLabel *Label7;
    TEdit *Edit7;
    TEdit *Edit4;
    TLabel *Label5;
    TLabel *Label8;
    TEdit *Edit5;
    TEdit *Edit8;
    TLabel *Label9;
    TEdit *Edit9;
    TLabel *Label10;
    TEdit *Edit10;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    TLabel *Label11;
    TComboBox *ComboBox1;
    TCheckBox *CheckBox1;
    TLabel *Label12;
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TSettingForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSettingForm *SettingForm;
//---------------------------------------------------------------------------
#endif
