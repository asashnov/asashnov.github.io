//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ActnList.hpp>
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <NMpop3.hpp>
#include <NMsmtp.hpp>
#include <Psock.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
#include <StdActns.hpp>
//---------------------------------------------------------------------------

class TMailFolder;

class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TActionList *ActionList1;
    TMainMenu *MainMenu1;
    TAction *ActionSendAll;
    TAction *ActionGetNewList;
    TAction *ActionNewLetter;
    TAction *ActionReply;
    TAction *ActionGetNewAllMail;
    TMenuItem *ActionNewLetter1;
    TMenuItem *Letter1;
    TMenuItem *ActionReply1;
    TMenuItem *MailBox1;
    TMenuItem *ActionGetNewList1;
    TMenuItem *ActionGetAllMail1;
    TMenuItem *SendAllMail1;
    TAction *ActionExit;
    TMenuItem *N1;
    TMenuItem *Exit1;
    TAction *ActionAbout;
    TMenuItem *Help1;
    TMenuItem *Index1;
    TMenuItem *N2;
    TMenuItem *About1;
    TAction *ActionSettings;
    TMenuItem *N3;
    TMenuItem *Settings1;
    TStatusBar *StatusBar1;
    TMemo *Memo1;
    TTreeView *TreeView1;
    TNMPOP3 *NMPOP31;
    TNMSMTP *NMSMTP1;
    TListView *ListView1;
    TAction *ActionDelete;
    TMenuItem *Delete1;
    TAction *ActionSave;
    TSaveDialog *SaveDialog1;
    TMenuItem *ActionSave1;
    TPopupMenu *LetterPopupMenu;
    TMenuItem *N4;
    TMenuItem *N5;
    TMenuItem *N6;
    TAction *ActionSendComment;
    TMenuItem *N7;
    TAction *ActionCp1251;
    TAction *ActionKoi8r;
    TAction *ActionCp866;
    TAction *ActionIso;
    TMenuItem *EncodeMenu;
    TMenuItem *WindowsCp12511;
    TMenuItem *Koi8R1;
    TMenuItem *ISOISO885951;
    TMenuItem *DosCp8661;
    TMenuItem *WindowsCp12512;
    TMenuItem *N8;
    TMenuItem *Koi8R2;
    TMenuItem *ISOISO885952;
    TMenuItem *DosCp8662;
    TAction *ActionRegister;
    TSplitter *Splitter1;
    TSplitter *Splitter2;
    THelpContents *HelpContents1;
    TButton *Button1;
    TButton *Button2;
    TAction *ActionEditLetter;
    void __fastcall ActionSettingsExecute(TObject *Sender);
    void __fastcall ActionNewLetterExecute(TObject *Sender);
    void __fastcall TreeView1Change(TObject *Sender, TTreeNode *Node);
    void __fastcall ActionGetNewListExecute(TObject *Sender);
    void __fastcall NMPOP31PacketRecvd(TObject *Sender);
    void __fastcall NMPOP31RetrieveEnd(TObject *Sender);
    void __fastcall NMPOP31RetrieveStart(TObject *Sender);
    void __fastcall NMPOP31Status(TComponent *Sender, AnsiString Status);
    void __fastcall NMPOP31Success(TObject *Sender);
    void __fastcall NMPOP31ConnectionRequired(bool &Handled);
    void __fastcall NMPOP31Connect(TObject *Sender);
    void __fastcall NMPOP31ConnectionFailed(TObject *Sender);
    void __fastcall NMPOP31List(int Msg, int Size);
    void __fastcall ActionGetNewAllMailExecute(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall ListView1Change(TObject *Sender, TListItem *Item,
          TItemChange Change);
    void __fastcall ActionSendAllExecute(TObject *Sender);
    void __fastcall NMSMTP1ConnectionRequired(bool &Handled);
    void __fastcall NMSMTP1Connect(TObject *Sender);
    void __fastcall NMSMTP1ConnectionFailed(TObject *Sender);
    void __fastcall NMSMTP1EncodeEnd(AnsiString Filename);
    void __fastcall NMSMTP1EncodeStart(AnsiString Filename);
    void __fastcall NMSMTP1Failure(TObject *Sender);
    void __fastcall NMSMTP1HostResolved(TComponent *Sender);
    void __fastcall NMSMTP1InvalidHost(bool &Handled);
    void __fastcall NMSMTP1MailListReturn(AnsiString MailAddress);
    void __fastcall NMSMTP1PacketSent(TObject *Sender);
    void __fastcall NMSMTP1RecipientNotFound(AnsiString Recipient);
    void __fastcall NMSMTP1SendStart(TObject *Sender);
    void __fastcall NMSMTP1Status(TComponent *Sender, AnsiString Status);
    void __fastcall NMSMTP1Success(TObject *Sender);
    void __fastcall ActionDeleteExecute(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall ListView1DblClick(TObject *Sender);
    void __fastcall ActionSaveExecute(TObject *Sender);
    void __fastcall ActionExitExecute(TObject *Sender);
    void __fastcall ActionReplyExecute(TObject *Sender);
    void __fastcall ActionAboutExecute(TObject *Sender);
    void __fastcall NMPOP31Disconnect(TObject *Sender);
    void __fastcall NMPOP31AuthenticationFailed(bool &Handled);
    void __fastcall NMPOP31AuthenticationNeeded(bool &Handled);
    void __fastcall ActionSendCommentExecute(TObject *Sender);
    void __fastcall ActionCp1251Execute(TObject *Sender);
    void __fastcall ActionKoi8rExecute(TObject *Sender);
    void __fastcall ActionCp866Execute(TObject *Sender);
    void __fastcall ActionIsoExecute(TObject *Sender);
    void __fastcall NMPOP31HostResolved(TComponent *Sender);
    void __fastcall NMPOP31InvalidHost(bool &Handled);
    void __fastcall NMPOP31Failure(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall ActionEditLetterExecute(TObject *Sender);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
private:
    void ShowLetters(TMailFolder * mf);
    bool GetMailMessage_my(int i);
    bool SendMailMessage_my(int i);
    bool isMessageExist(String Id, TMailFolder * mf);
    bool SaveLetterAsText(TLetter * l, FILE * fp);
    void SetEncodeType(BYTE en);	// User declarations
public:		// User declarations
    __fastcall TMainForm(TComponent* Owner);
    void GetPopServerConnection();
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
