//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SaveError.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSaveErrorForm *SaveErrorForm;
//---------------------------------------------------------------------------
__fastcall TSaveErrorForm::TSaveErrorForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
