//---------------------------------------------------------------------------

#ifndef SaveErrorH
#define SaveErrorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TSaveErrorForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TGroupBox *GroupBox1;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TRadioButton *RadioButton3;
    TLabel *Label3;
    TLabel *Label4;
private:	// User declarations
public:		// User declarations
    __fastcall TSaveErrorForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSaveErrorForm *SaveErrorForm;
//---------------------------------------------------------------------------
#endif
