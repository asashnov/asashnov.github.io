Test file's naming:

100..199	arguments with simple numbers: 1,2,3,0x01,0xa1
200..299	args with LABELS and $: $, LOOP
300..399	args with ariphmetic: 1+2, 1-0xa, LABEL+5, $+CONST-5
