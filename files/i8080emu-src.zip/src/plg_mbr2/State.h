//---------------------------------------------------------------------------

#ifndef StateH
#define StateH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TMbrStateForm : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
        __fastcall TMbrStateForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMbrStateForm *MbrStateForm;
//---------------------------------------------------------------------------
#endif
