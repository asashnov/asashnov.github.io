//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "State.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMbrStateForm *MbrStateForm;
//---------------------------------------------------------------------------
__fastcall TMbrStateForm::TMbrStateForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
