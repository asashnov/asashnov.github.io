#ifndef K580_TYPES_H
#define K580_TYPES_H

typedef   signed  char SBYTE;
typedef unsigned  char  BYTE;

typedef   signed short SWORD;
typedef unsigned short  WORD;

typedef   signed  int SDWORD;
typedef unsigned  int  DWORD;

#endif
