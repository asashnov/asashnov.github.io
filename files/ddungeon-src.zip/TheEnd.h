//---------------------------------------------------------------------------

#ifndef TheEndH
#define TheEndH
//---------------------------------------------------------------------------
#endif

BOOL TheEnd_Init();
BOOL TheEnd_Update(double td);
void TheEnd_Draw();

